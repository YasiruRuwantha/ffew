<?php
/**
 *------------------------------------------------------------------------------
 * @package       T3 Framework for Joomla!
 *------------------------------------------------------------------------------
 * @copyright     Copyright (C) 2004-2013 JoomlArt.com. All Rights Reserved.
 * @license       GNU General Public License version 2 or later; see LICENSE.txt
 * @authors       JoomlArt, JoomlaBamboo, (contribute to this project at github
 *                & Google group to become co-author)
 * @Google group: https://groups.google.com/forum/#!forum/t3fw
 * @Link:         http://t3-framework.org
 *------------------------------------------------------------------------------
 */

defined('_JEXEC') or die;
?>

<?php if ($this->countModules('full-width')) : ?>
    <!-- full-width -->
    <div class="wrap full-width clearfix<?php $this->_c('full-width') ?>">
        <jdoc:include type="modules" name="<?php $this->_p('full-width') ?>" style="T3Xhtml" />
    </div>
    <!-- //full-width -->
<?php endif ?>
