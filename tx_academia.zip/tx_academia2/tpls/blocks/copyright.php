<?php
/**
 * @package   T3 Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>
<section class="t3-copyright">
	<div class="container">
		<div class="row">
			<div class="<?php echo $this->getParam('t3-rmvlogo', 1) ? 'col-md-8' : 'col-md-12' ?> copyright <?php $this->_c('footer') ?>">
				<jdoc:include type="modules" name="<?php $this->_p('footer') ?>" />



				<div class="module">
					<p class="pull-left">
						<?php
						$copyright_text = $this->params->get('copyright_text', 'Copyright &#xA9; 2016 Academia Responsive Educational Template for Joomla with Quix. All Rights Reserved.');

						if (!empty($copyright_text)) {
							echo $copyright_text;
						}
						?>
					</p>

					<p class="pull-right">

						<?php if ($this->getParam('display_design_by', 1)): ?>
							Designed by <a href="https://www.themexpert.com/" title="Visit ThemeXpert!">ThemeXpert</a>
						<?php endif; ?>

					</p>
				</div>



			</div>

			<?php if ($this->getParam('t3-rmvlogo', 1)): ?>
				<div class="col-md-4 poweredby text-hide">
					<a class="t3-logo t3-logo-color text-uppercase" href="http://t3-framework.org" title="<?php echo JText::_('T3_POWER_BY_TEXT') ?>"
					   target="_blank" <?php echo method_exists('T3', 'isHome') && T3::isHome() ? '' : 'rel="nofollow"' ?>><?php echo JText::_('T3_POWER_BY_HTML') ?></a>
				</div>
			<?php endif; ?>

		</div>
	</div>
</section>