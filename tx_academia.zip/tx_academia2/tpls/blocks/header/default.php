<?php
/**
 * @package   T3 Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// get params
$sitename  = $this->params->get('sitename');
$slogan    = $this->params->get('slogan', '');
$logotype  = $this->params->get('logotype', 'text');
$theme  	 = $this->params->get('theme', '');
// var_dump($theme);die;
if($theme){
	$logo_name = "images/logo/logo-$theme.png";
	$logoimage = $logotype == 'image' ? $this->params->get('logoimage', T3Path::getUrl($logo_name, '', true)) : '';
	$logo_name = "images/logo/logo-$theme-sm.png";
	$logoimgsm = ($logotype == 'image' && $this->params->get('enable_logoimage_sm', 0)) ? $this->params->get('logoimage_sm', T3Path::getUrl($logo_name, '', true)) : false;
}else{
	$logoimage = $logotype == 'image' ? $this->params->get('logoimage', T3Path::getUrl('images/logo.png', '', true)) : '';
	$logoimgsm = ($logotype == 'image' && $this->params->get('enable_logoimage_sm', 0)) ? $this->params->get('logoimage_sm', T3Path::getUrl('images/logo-sm.png', '', true)) : false;
}

if (!$sitename) {
	$sitename = JFactory::getConfig()->get('sitename');
}
?>

<!-- HEADER -->
<header id="t3-header" class="t3-header header-default">
    <div class="container">
        <div class="row">
            <!-- LOGO -->
            <div class="col-xs-12 col-sm-4 logo">
			    <?php include ('header-parts/brand.php'); ?>
            </div>
            <!-- //LOGO -->
            <div class="col-xs-12 col-sm-8 header-info">

			    <?php if ($this->countModules('languageswitcherload')) : ?>
                    <div class="wrapper-languageswitcherload clearfix">
                        <jdoc:include type="modules" name="<?php $this->_p('languageswitcherload') ?>" style="raw" />
                    </div>
			    <?php endif ?>
			    <?php if ($this->countModules('languageswitcherload')) : ?>
                    <div class="wrapper-position-0 clearfix">
                        <jdoc:include type="modules" name="<?php $this->_p('position-0') ?>" style="raw" />
                    </div>
			    <?php endif ?>
            </div>

        </div>
    </div>
	<?php $this->loadBlock('mainnav') ?>
</header>
<!-- //HEADER -->
