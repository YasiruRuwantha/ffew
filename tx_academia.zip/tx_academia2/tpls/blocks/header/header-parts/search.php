<?php
/**
 * @package   T3 Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

?>


<div class="head-search">

<?php
  // Including fallback code for the placeholder attribute in the search field.
  JHtml::_('jquery.framework');

  $document = JFactory::getDocument();
  $app = JFactory::getApplication();
  $AcTemplate = JFactory::getApplication()->getTemplate();
  $document->addStyleSheet( JURI::base(true).'/templates/'.$AcTemplate. '/css/search-component.css');
  $document->addStyleSheet( JURI::base(true).'/templates/'.$AcTemplate. '/css/search-default.css');
  $document->addScript( JURI::base(true).'/templates/'.$AcTemplate. '/js/search-classie.js');
  $document->addScript( JURI::base(true).'/templates/'.$AcTemplate. '/js/search-uisearch.js');

  ?>
  <div id="sb-search" class="sb-search expanding-search">
    <?php if($app->input->get('t3action') != 'layout') : ?>
      <form action="<?php echo JRoute::_('index.php'); ?>" method="post">
    <?php endif; ?>

      <input class="sb-search-input" placeholder="<?php echo JText::_('TX_SEARCH')?>" type="text" value="" name="searchword" id="mod-search-searchword">
      <input class="sb-search-submit" type="submit" value="">
      <span class="sb-icon-search"></span>

    <?php if($app->input->get('t3action') != 'layout') : ?>
      <input type="hidden" name="task" value="search" />
      <input type="hidden" name="option" value="com_search" />
      <input type="hidden" name="Itemid" value="<?php echo $this->params->get('searchmenuitemid')?>" />
    </form>
    <?php endif; ?>
  </div>


  <script>
  	new UISearch( document.getElementById( 'sb-search' ) );
  </script>

</div>
