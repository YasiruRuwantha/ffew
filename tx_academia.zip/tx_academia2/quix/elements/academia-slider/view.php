<?php
// HTML class
$classes = classNames( "qx-element qx-element-{$type} home-main-slide {$field['class']}",$visibilityClasses, [
  "wow {$field['animation']}" => $field['animation']
]);
$total = count($field['sliders']);
$width = (100 / $total);
// print_r($field);die;
if($field['autoplay']){
  $interval = $field['interval'];
}else{
  $interval = 0;
}
$list_indicator = '';
$show_list_indicator = $field['list_indicator'];
?>
<div id="<?php echo $id;?>" class="home-slideshow">
  <div class="<?php echo $classes?>">
    <div  class="mod-txbt3slider mod-txbt3slider-wrapperhome-main-slide">
      <div id="<?php echo $id;?>-slider" class=" carousel slide carousel-fade" data-ride="carousel" data-interval="<?php echo $interval; ?>">
        <div class="carousel-inner">
          <?php foreach($field['sliders'] as $key=>$item):?>
            <div class="item<?php echo ($key == 0 ? ' active' : '');?>">
              <div class="item-wrapper row">
                <div class="col-md-7">
                  <div class="img" data-animation="animated fadeInLeft">
                      <img src="<?php echo $item['image'];?>" alt="<?php echo $item['title'];?>" class="img-responsive" />
                  </div>
                </div>
                <div class="col-md-5">
                  <div class="jumbotron">
                    <?php if($item['title']):?>
                    <h2 class="heading" data-animation="animated fadeInRight">
                        <?php echo $item['title'];?>
                    </h2>
                    <?php endif;?>
                    <?php if($item['content']):?>
                    <p class="intro lead" data-animation="animated fadeInRight">
                        <?php echo $item['content'];?>
                    </p>
                    <?php endif;?>

                    <?php if($item['button_enabled']):?>
                    
                    <a class="btn btn-rounded btn-primary btn-lg btn-special" href="<?php echo $item['button']['url'] ?>" <?php echo ( $item['button']['target'] ) ? ' target="_blank"' : '' ?>><?php echo $item['button']['text']?></a>
                  <?php endif;?>

                  </div>
                </div>
              </div>
            </div>
            <?php
            $list_indicator .= '<li data-target="#'.$id.'-slider" data-slide-to="'.$key.'" class="'.($key == 0 ? 'active' : '').'" style="width: '.$width.'%;">
                <span class="title ">'.$item['title'].'</span>
            </li>';
             ?>
          <?php endforeach;?>
        </div>

        <ul class="carousel-indicators">
          <?php echo $list_indicator; ?>
        </ul>

        <a data-slide="prev" role="button" href="#<?php echo $id;?>-slider" class="left carousel-control"><i class="fa fa-angle-left"></i></a>
        <a data-slide="next" role="button" href="#<?php echo $id;?>-slider" class="right carousel-control"><i class="fa fa-angle-right"></i></a>

      </div>
    </div>
  </div>
</div>
<!-- qx-element-btslider -->