#<?php echo $id;?>{
  <?php //Css::fonts($field['body_font']); ?>
  <?php //Css::prop('color', $field['body_color']);?>
}
#<?php echo $id;?> .qx-slide h3{
 <?php //Css::fonts($field['header_font']); ?> 
}

#<?php echo $id;?> .slick-prev:before, 
#<?php echo $id;?> .slick-next:before{
 <?php //Css::prop('color', $field['body_color']);?> 
}

.mod-txbt3slider .carousel-indicators {
    bottom: auto;
    clear: both;
    display: block;
    height: 40px;
    left: auto;
    margin: 0;
    position: relative;
    text-align: left;
    width: 100%;
    z-index: 9;
}
.mod-txbt3slider .carousel-indicators li {
    border-right: 1px solid;
    border-bottom: 0;
    border-radius: 0;
    color: #505656;
    cursor: pointer;
    display: block;
    float: left;
    font-size: 12px;
    font-weight: 300;
    height: 39px;
    margin: 0;
    padding: 0 0 0 80px;
    position: relative;
    text-indent: 0;
    vertical-align: middle;
}
.mod-txbt3slider .carousel-control {
    background: none;
    display: none;
    font-size: 56px;
}
.mod-txbt3slider:hover .carousel-control {
    display: block;
}
.mod-txbt3slider .carousel-control .fa {
    position: absolute;
    top: 50%;
    margin-top: -28px;
}
