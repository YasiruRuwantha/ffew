<?php
  $classes = classNames( "qx-element qx-element-{$type} {$field['class']}", $visibilityClasses, [
    "wow {$field['animation']}" => $field['animation']
  ] );
?>

<div id="<?php echo $id;?>" class="<?php echo $classes?>">
  <h3 class="module-title">
    <?php if($field['pretitle']): ?>
      <?php echo $field['pretitle']; ?>
    <?php endif;?>
    <span> <?php echo $field['title']; ?></span>      
  </h3>
</div>
<!-- qx-element-academia-header -->