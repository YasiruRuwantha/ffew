<?php 
##############
# Responsive #
##############

// Title
Css::typography("#$id .module-title", $field['pretitle_font']);
Css::typography("#$id .module-title span", $field['title_font']);

?>

#<?php echo $id;?> .module-title{
  <?php Css::prop('color', $field['pretitle_color']);?>
}
#<?php echo $id;?> .module-title span{
  <?php Css::prop('color', $field['title_color']);?>
}