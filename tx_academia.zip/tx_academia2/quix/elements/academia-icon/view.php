<?php
  $classes = classNames( "qx-element qx-element-{$type} {$field['class']}", $visibilityClasses, [
  ]);

  // New icon system. Since @1.7
  $icon = get_icon($field);
?>
<div id="<?php echo $id; ?>" class="module-social-media-count <?php echo $classes; ?>">
<!--  <i class="--><?php //echo $field['icon']?><!--"></i>-->


  <a class="btn btn-default btn-block" href="<?php echo $field['link']['url'] ?>" <?php echo ($field['link']['target']) ? ' target="_blank"' : '' ?>>
    <!-- <i class="<?php //echo $icon['icon']; ?> fa-5x"></i> -->
    <i class="<?php echo $icon['class']?> fa-5x"><?php echo $icon['content']?></i>
    <p class="msg"><?php echo $field['title_1']; ?></p>
    <h5><?php echo $field['title_2']; ?></h5>
  </a>
  
  
  
</div>
<!-- qx-element-icon -->