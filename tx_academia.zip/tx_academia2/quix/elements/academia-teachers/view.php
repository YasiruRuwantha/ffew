<?php
  // HTML class
  $classes = classNames( "qx-element qx-element-{$type} {$field['class']}", $visibilityClasses);

  $animation_class = ($field['animation']) ? 'wow ' . $field['animation'] : '';
  $animation_delay = 0;
  
  // Item settings
  $items = array_chunk($field['teachers'], (12/$field['columns']) );

?>

<div id="<?php echo $id; ?>" class="<?php echo $classes; ?>">

    <div class="module-teachers-team">
      <div class="ateam">
        <ul class="at-default at-cols<?php echo $field['columns']; ?>">

          <?php foreach( $items as $teacher ):?>
            <?php foreach( $teacher as $item ):?>
              <?php $animation_delay += 0.1;?>

              <li>
                <div class="at-inner">

                  <?php if($item['image']):?>
                    <figure>
                      <img class="qx-img-responsive square" src="<?php echo $item['image']?>" alt="<?php echo $item['name']?>">

                      <figcaption>
                        <h4><?php echo $item['name']?></h4>
                        <h5><?php echo $item['designation']?></h5>
                      </figcaption>
                    </figure>
                  <?php endif;?>

                  <div class="team-body">
                    <h4><?php echo $item['name']?></h4>
                    <h5><?php echo $item['designation']?></h5>

                    <?php if($item['description']):?>
                      <p class="at-desc"><?php echo $item['description']?></p>
                    <?php endif;?>

                    <?php if($item['social_enabled']):?>
                    <div class="at-social">
                      <?php if($item['facebook']):?>
                        <a href="<?php echo $item['facebook']?>" target="_blank"><span class="fa fa-facebook"></span></a>
                      <?php endif;?>

                      <?php if($item['twitter']):?>
                        <a href="<?php echo $item['twitter']?>" target="_blank"><span class="fa fa-twitter"></span></a>
                      <?php endif;?>

                      <?php if($item['googleplus']):?>
                        <a href="<?php echo $item['googleplus']?>" target="_blank"><span class="fa fa-google-plus"></span></a>
                      <?php endif;?>

                      <?php if($item['linkedin']):?>
                        <a href="<?php echo $item['linkedin']?>" target="_blank"><span class="fa fa-linkedin"></span></a>
                      <?php endif;?>
                    </div>
                    <?php endif;?>

                  </div>

                </div>

              </li>
            <?php endforeach;?>
          <?php endforeach;?>
        </ul>
      </div>
    </div>
</div>
<!-- qx-element-filterable-gallery -->