<?php 
###############
# Responsive #
###############

Css::padding("#$id .ateam ul li", $field['padding']);

?>

.at-cols2 li {
width: 50%
}

.at-cols3 li {
width: 33.33%
}

.at-cols4 li {
width: 25%
}

.at-cols5 li {
width: 20%
}

.ateam ul {
list-style-type: none;
margin: 0
}

.ateam ul {
margin: 0 -10px
}

.ateam ul li {
float: left
}

.ateam .at-inner {
margin: 0 10px 10px
}

.ateam .at-name,
.ateam .at-designation,
.ateam .at-desc,
.ateam .at-social {
margin: 10px 0 0
}

.at-default {
text-align: center
}

.at-default .at-name,
.at-default .at-designation {
line-height: 1
}

.at-default .at-name {
font-size: 1.5em;
font-width: bold;
text-transform: uppercase
}

.at-default .at-designation {
font-size: 1.2em;
color: #888
}

.at-classic .at-inner {
background: #f8f8f8;
padding: 15px;
border: 1px solid #ebebeb
}

.at-classic figure {
float: left;
width: 25%;
margin: 0 5% 0 0;
text-align: center
}

.at-classic .at-info {
float: left;
width: 70%
}

.at-classic .at-designation {
float: right;
background: silver;
color: #fff;
padding: 3px 10px;
font-size: 13px;
line-height: 1
}

.at-classic .at-name {
margin-top: 0
}

.at-classic .at-social {
text-align: left;
margin-top: 15px
}

.at-overlay-social figure {
margin: 0;
overflow: hidden;
position: relative
}

.at-overlay-social .overlay {
display: flex;
align-items: center;
justify-content: center;
position: absolute;
z-index: 20;
background: rgba(0, 0, 0, .8);
transition: all .3s;
width: 100%;
height: 0;
margin-top: 20px
}

.at-overlay-social figure:hover .overlay {
bottom: 0;
left: 0;
right: 0;
height: 100%
}





.module-teachers-team .ateam figure {
overflow: hidden;
}
.module-teachers-team .ateam .at-inner img {
<!--height: auto;-->
}
.qx-element-academia-teachers {
<!--overflow: hidden; -->
}


.ateam .at-social a .fa {
font-size: 16px;
font-style: normal;
margin: 0 5px 0 0;
border-radius: 50%;
color: #fff;
width: 30px;
height: 30px;
line-height: 30px;
}

.ateam .at-social a .fa-facebook {
background: #3f5896
}

.ateam .at-social a .fa-google-plus {
background: #d6492f
}

.ateam .at-social a .fa-linkedin {
background: #126698
}

.ateam .at-social a .fa-twitter {
background: #46cbfd
}