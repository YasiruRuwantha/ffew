<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

include_once 'helper.php';

$info = new JoomlArticleElementClass();
//print_r( $info->getInput());die;
$cats = array_reduce( $info->getInput(), function ( $carry, $module ) {
  $carry[$module->value] = $module->text;
  return $carry;
}, [ ] );

return [
  "slug" => "joomla-articles",
  "name" => "Joomla Articles",
  "groups" => ["joomla", "content"],
  "form" => [
    "general" => [
      [ "name" => "category", "type" => "select", "help"=> "Category", "multiple"=> true, "options" => $cats ],
      [ "name" => "count", "type" => "text",  "value" => 5, "help"=> "How many item you wanna show?"],
      [ "name" => "show_featured", "type" => "select",  "options" => [
          "show" => JText::_('JSHOW'), 
          "hide" => JText::_('JHIDE'), 
          "only" => "Only featured"
        ]
      ],
      [ "name" => "show_child_category_articles", "type" => "switch", "help"=> "Child category articles will be listed too?", "value"=> true],
      [ 
        "name" => 'article_ordering', 
        "type" => "select", 
        "value" => "a.title", 
        "options" => [
          "publish_up" => "Latest",
          "a.hits" => "Popular", 
          "a.ordering" => "Article order", 
          "a.title" => "Title"
        ]
      ],
      [ 
        "name" => 'article_ordering_direction', 
        "type" => "select", 
        "value" => "ASC", 
        "options" => [
          "DESC" => "Descending", 
          "ASC" => "Ascending"
        ]
      ],
      [
        "name" => 'animation', 
        "type" => "select", 
        "value" => 0, 
        "options" => [
          "fadeInLeft" => "Left To Right", 
          "fadeInRight" => "Right To Left", 
          "fadeInUp" => "Bottom To Top", 
          "fadeInDown" => "Top To Bottom",
          "fadeIn" => "Fade In",
          "zoomIn" => "Zoom In",
          0 => 'No Animation'
        ]
      ],
    ],
    "display" => [
      [ "name" => "link_titles", "type" => "switch", "help"=> "Show link title?", "value"=> true],
      [ "name" => "show_date", "type" => "switch", "help"=> "Show article date?", "value"=> false],
      [ "name" => "show_image", "type" => "switch", "help"=> "Show article image?", "value"=> true],
      [ "name" => "show_category", "type" => "switch", "help"=> "Show article category?", "value"=> false],
      [ "name" => "show_author", "type" => "switch", "help"=> "Show article author?", "value"=> false],
      [ "name" => "show_introtext", "type" => "switch", "help"=> "Show article intro?", "value"=> false],
      [ "name" => 'introtext_limit', "type" => "text", "value" => "100", "depends"=>["show_introtext"=> true]],
      [ "name" => "show_readmore", "type" => "switch", "help"=> "Show article readmore button?", "value"=> false],
    ]
  ]
];
