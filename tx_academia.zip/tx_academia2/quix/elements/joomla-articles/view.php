<?php
// no direct access
defined('_JEXEC') or die;

include_once 'helper.php';
use Joomla\Registry\Registry;
$registry = new Registry;
$params = $registry->loadArray($field);
$classes = classNames( "qx-element qx-element-{$type} {$field['class']}", $visibilityClasses, [
  "wow {$field['animation']}" => $field['animation']
]);
$items = JoomlArticleElementClass::getList($params);
?>
<!-- qx-element-joomla-article -->
<div id="<?php echo $id; ?>" class="<?php echo $classes; ?>">
	<ul class="list-unstyled">
		<?php foreach ($items as $item) : ?>
			<?php $images = json_decode($item->images); ?>
			<li>
				<h3>
					<?php if ($params->get('link_titles') == 1) : ?>
						<a class="qx-element-joomla-article-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
							<?php echo $item->title; ?>
						</a>
					<?php else : ?>
						<?php echo $item->title; ?>
					<?php endif; ?>					
				</h3>
	
				<?php if ($item->displayHits) : ?>
					<span class="qx-element-joomla-article-hits">
						<i class="fa fa-eye"></i> <?php echo $item->displayHits; ?>
					</span>
				<?php endif; ?>
	
				<?php if ($params->get('show_author')) : ?>
					<span class="qx-element-joomla-article-writtenby">
						<i class="fa fa-user"></i> <?php echo $item->displayAuthorName; ?>
					</span>
				<?php endif;?>
	
				<?php if ($item->displayCategoryTitle) : ?>
					<span class="qx-element-joomla-article-category">
						<i class="fa fa-folder-open"></i> <?php echo $item->displayCategoryTitle; ?>
					</span>
				<?php endif; ?>
	
				<?php if ($item->displayDate) : ?>
					<span class="qx-element-joomla-article-date">
						<i class="fa fa-calendar"></i> <?php echo $item->displayDate; ?>
					</span>
				<?php endif; ?>

				<?php if ($params->get('show_image') == 1) : ?>
					<?php if(isset($images->image_intro)) : ?>
						<figure>
								<div class="display-block">
									<img class="media-object img-responsive" src="<?php echo JURI::base().$images->image_intro; ?>" alt="<?php echo $images->image_intro_alt; ?>">
								</div>
								<figcaption>
									<?php 
									if ($images->image_intro_caption):
									echo $images->image_intro_caption;
									else:
									echo $item->title;
									endif; ?>
								</figcaption>
						</figure>
					<?php endif; ?> <!--//end if introimage-->
				<?php endif; ?> <!--//end show_image-->
				<?php if ($params->get('show_introtext')) : ?>
					<p class="qx-element-joomla-article-introtext">
						<?php echo $item->displayIntrotext; ?>
					</p>
				<?php endif; ?>
	
				<?php if ($params->get('show_readmore')) : ?>
					<p class="qx-element-joomla-article-readmore">
						<a class="qx-element-joomla-article-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
							<?php if ($item->params->get('access-view') == false) : ?>
								<?php echo JText::_('Register to see more'); ?>
							<?php else : ?>
								<?php echo JText::_('Readmore'); ?>
							<?php endif; ?>
						</a>
					</p>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
</div>