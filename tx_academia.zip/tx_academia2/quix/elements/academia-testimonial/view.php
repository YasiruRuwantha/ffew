<?php
  // HTML class
  $classes = classNames( "qx-element qx-element-{$type} {$field['class']}tx-infinito-testi", $visibilityClasses,[]);

  // css
  Assets::Css('qx-slick', QUIX_URL."/assets/css/slick.css");
  // JS script
  Assets::Js('qx-slick', QUIX_URL."/assets/js/slick.min.js");
    // RTL detection
    $direction = Jfactory::getDocument()->direction;

  $script = array();
  $script[] = 'fade: true';
  $script[] = 'infinite: true';
  $script[] = 'adaptiveHeight: true';
  $script[] = ($field['arrows']) ? 'arrows:true' : 'arrows:false';
  $script[] = ($field['dots']) ? 'dots:true' : 'dots:false';
  $script[] = ($field['autoplay']) ? 'autoplay:true' : 'autoplay:false';
  $script[] = 'autoplaySpeed:' . $field['autoplay_speed'];
    if( 'rtl' == $direction ){ $script[] = 'rtl:true'; }
    $script[] = 'autoplaySpeed:' . $field['autoplay_speed'];
?>

<div id="<?php echo $id; ?>" class="<?php echo $classes; ?>">
    <?php foreach( $field['testimonials'] as $testimonial ):?>
      <div class="qx-testimonial">
        <div class="qx-testimony"><?php echo $testimonial['testimony']?></div>
        <div class="author-img">
          <img class="qx-img-responsive <?php echo $field['image_style']?>" src="<?php echo $testimonial['image']?>" alt="<?php echo $testimonial['name']?>">
        </div>
        <div class="name-deg">
          <h4><?php echo $testimonial['name']?></h4>
          <p class="qx-designation"><?php echo $testimonial['company']?></p>
        </div>
      </div>
    <?php endforeach;?>
</div>

<script type="text/javascript">
  jQuery(document).ready(function(){
    jQuery('#<?php echo $id?>').slick({<?php echo implode(',', $script)?>});
  });
</script>
<!-- qx-element-testimonial-pro -->