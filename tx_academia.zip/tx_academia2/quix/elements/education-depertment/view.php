<?php
include_once "helper.php";
use Joomla\Registry\Registry;
$registry = new Registry;
$params = $registry->loadArray($field);
$classes = classNames( "qx-element qx-element-{$type} module-courselist scroller {$field['class']}", $visibilityClasses, [
  "wow {$field['animation']}" => $field['animation']
]);
$list = EducationDepertmentElementHelper::getList($params);
?>
<!-- qx-element-joomla-article -->
<div id="<?php echo $id; ?>" class="<?php echo $classes; ?>">

	<?php
	$layout_style =$params->get('layout_style', 'carosul');
	include 'style_'.$layout_style.'.php';
	?>	
	
<?php
$doc = JFactory::getDocument();
$doc->addStylesheet(JUri::root().'templates/tx_academia2/js/owl-carousel/owl.carousel.css');
$doc->addStylesheet(JUri::root().'templates/tx_academia2/js/owl-carousel/owl.theme.css');
$doc->addScript(JUri::root().'templates/tx_academia2/js/owl-carousel/owl.carousel.js');
$doc->addScriptDeclaration('
jQuery(document).ready(function() {
  jQuery(".owl-carousel").owlCarousel({
		// rtl: true,
		items : ' . $params->get('count', 4) .',
		pagination : false,
		navigation : true,
		navigationText : ["<i class=\"ico-chevron-left\"></i>","<i class=\"ico-chevron-right\"></i>"],
	});
});
');
?>


</div>