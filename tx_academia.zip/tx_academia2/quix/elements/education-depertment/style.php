
.module-courselist .style_list  .met-box .mod-articles-category-readmore {
margin-bottom: 0;
}
.style_list .col-xs-6.mod-category-item {
margin-bottom: 30px;
}
.module-courselist.scroller .style_list .met-box {
margin: 0;
}
.module-courselist.scroller .style_list .met-box .media-body {
padding: 10px 0 0 10px;
}
.module-courselist.scroller .style_list figure .display-block {
margin: -20px -10px -20px -20px;
}

@media only screen and (max-width: 992px) {
.module-courselist.scroller .style_list .met-box .media-body {
padding: 35px 0 0 10px;
}
}