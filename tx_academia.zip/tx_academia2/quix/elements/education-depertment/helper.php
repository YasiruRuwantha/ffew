<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

//require_once JPATH_SITE . '/components/com_txeducation/helpers/route.php';
JModelLegacy::addIncludePath(JPATH_SITE . '/components/com_txeducation/models', 'TxeducationModel');

/**
* Joomla article element class
* instead of using direct method use class
*/
class EducationDepertmentElementHelper
{
  public $element;
  function __construct(){
    $this->element  = array();
    $this->element['extension'] = 'com_content';
    $this->element['published'] = 1;
    $this->element['action'] = 0;
    $this->element['show_root'] = 1;
    $this->element['client_id'] = null;

    $this->name = 'education-module';
    $this->id = 'education-module';
    $this->class = '';
    $this->multiple = 0;
    $this->required = 'true';
    $this->autofocus = '';
    $this->readonly = 'false';
    $this->disabled = 'false';
    $this->onchange = '';
    $this->value = '';
  }
  /**
   * Method to get the field options for category
   * Use the extension attribute in a form to specify the.specific extension for
   * which categories should be displayed.
   * Use the show_root attribute to specify whether to show the global category root in the list.
   *
   * @return  array    The field option objects.
   *
   * @since   11.1
   */
  function getOptions()
  {
    $options = array();

    // Get an instance of the generic articles model
    $departments = JModelLegacy::getInstance('Departments', 'TxeducationModel', array('ignore_request' => true));

    // Set application parameters in model
//    $app       = JFactory::getApplication();
//    $appParams = $app->getParams();
//    $departments->setState('params', $appParams);
    $list = $departments->getItems();
    foreach ($list as $key=>$item) {
      $options[$key] = new stdClass();
      $options[$key]->text   =      $item->title      ;
      $options[$key]->value      =      $item->id;
//      $options[] = array('text' =>$item->title, 'value' => $item->id)  ;
//      $options['text'] = ;
//      $options['value'] = ;
    }

    // Merge any additional options in the XML definition.
    // $options = array_merge(parent::getOptions(), $options);

    return $options;
  }

  /**
   * Method to get the field input markup for a generic list.
   * Use the multiple attribute to enable multiselect.
   *
   * @return  string  The field input markup.
   *
   * @since   11.1
   */
  function getInput()
  {
    $html = array();
    $attr = '';

    // Initialize some field attributes.
    $attr .= !empty($this->class) ? ' class="' . $this->class . '"' : '';
    $attr .= !empty($this->size) ? ' size="' . $this->size . '"' : '';
    $attr .= $this->multiple ? ' multiple' : '';
    $attr .= $this->required ? ' required aria-required="true"' : '';
    $attr .= $this->autofocus ? ' autofocus' : '';

    // To avoid user's confusion, readonly="true" should imply disabled="true".
    if ((string) $this->readonly == '1' || (string) $this->readonly == 'true' || (string) $this->disabled == '1'|| (string) $this->disabled == 'true')
    {
      $attr .= ' disabled="disabled"';
    }

    // Initialize JavaScript field attributes.
    $attr .= $this->onchange ? ' onchange="' . $this->onchange . '"' : '';

    // Get the field options.
    return (array) $this->getOptions();

  }

  /**
   * Get a list of articles from a specific category
   *
   * @param   \Joomla\Registry\Registry  &$params  object holding the models parameters
   *
   * @return  mixed
   *
   * @since  1.6
   */
  public static function getList(&$params)
  {
    // Get an instance of the generic articles model
//    print_r($params);die;
    $articles = JModelLegacy::getInstance('Department', 'TxeducationModel', array('ignore_request' => true));
    $articles->setState('department.id', $params->get('department'));
    $items = $articles->getData();

//    // Prepare data for display using display options
    foreach ($items->courses as &$item)
    {
//      $item->slug    = $item->id . ':' . $item->alias;
//      $item->catslug = $item->catid . ':' . $item->category_alias;
//
//      if ($access || in_array($item->access, $authorised))
//      {
//        // We know that user has the privilege to view the article
//        $item->link = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catid, $item->language));
//      }
//      else
//      {
//        $app       = JFactory::getApplication();
//        $menu      = $app->getMenu();
//        $menuitems = $menu->getItems('link', 'index.php?option=com_users&view=login');
//
//        if (isset($menuitems[0]))
//        {
//          $Itemid = $menuitems[0]->id;
//        }
//        elseif ($app->input->getInt('Itemid') > 0)
//        {
//          // Use Itemid from requesting page only if there is no existing menu
//          $Itemid = $app->input->getInt('Itemid');
//        }
//
//        $item->link = JRoute::_('index.php?option=com_users&view=login&Itemid=' . $Itemid);
//      }
//
//      // Used for styling the active article
//      $item->active      = $item->id == $active_article_id ? 'active' : '';
//      $item->displayDate = '';
//
//      if ($show_date)
//      {
//        $item->displayDate = JHtml::_('date', $item->$show_date_field, $show_date_format);
//      }
//
//      if ($item->catid)
//      {
//        $item->displayCategoryLink  = JRoute::_(ContentHelperRoute::getCategoryRoute($item->catid));
//        $item->displayCategoryTitle = $show_category ? '<a href="' . $item->displayCategoryLink . '">' . $item->category_title . '</a>' : '';
//      }
//      else
//      {
//        $item->displayCategoryTitle = $show_category ? $item->category_title : '';
//      }
//
//      $item->displayHits       = $show_hits ? $item->hits : '';
//      $item->displayAuthorName = $show_author ? $item->author : '';
//
//      if ($show_introtext)
//      {
        $text = explode("<hr id=\"system-readmore\" />", $item->description);
        $item->text = $text[0];
//      }
//
//      $item->displayIntrotext = $show_introtext ? self::truncate($item->introtext, $introtext_limit) : '';
//      $item->displayReadmore  = $item->alternative_readmore;
    }

    return $items;
  }

  /**
   * Strips unnecessary tags from the introtext
   *
   * @param   string  $introtext  introtext to sanitize
   *
   * @return mixed|string
   *
   * @since  1.6
   */
  public static function _cleanIntrotext($introtext)
  {
    $introtext = str_replace('<p>', ' ', $introtext);
    $introtext = str_replace('</p>', ' ', $introtext);
    $introtext = strip_tags($introtext, '<a><em><strong>');
    $introtext = trim($introtext);

    return $introtext;
  }

  /**
   * Method to truncate introtext
   *
   * The goal is to get the proper length plain text string with as much of
   * the html intact as possible with all tags properly closed.
   *
   * @param   string   $html       The content of the introtext to be truncated
   * @param   integer  $maxLength  The maximum number of charactes to render
   *
   * @return  string  The truncated string
   *
   * @since   1.6
   */
  public static function truncate($html, $maxLength = 0)
  {
    $baseLength = strlen($html);

    // First get the plain text string. This is the rendered text we want to end up with.
    $ptString = JHtml::_('string.truncate', $html, $maxLength, $noSplit = true, $allowHtml = false);

    for ($maxLength; $maxLength < $baseLength;)
    {
      // Now get the string if we allow html.
      $htmlString = JHtml::_('string.truncate', $html, $maxLength, $noSplit = true, $allowHtml = true);

      // Now get the plain text from the html string.
      $htmlStringToPtString = JHtml::_('string.truncate', $htmlString, $maxLength, $noSplit = true, $allowHtml = false);

      // If the new plain text string matches the original plain text string we are done.
      if ($ptString == $htmlStringToPtString)
      {
        return $htmlString;
      }

      // Get the number of html tag characters in the first $maxlength characters
      $diffLength = strlen($ptString) - strlen($htmlStringToPtString);

      // Set new $maxlength that adjusts for the html tags
      $maxLength += $diffLength;

      if ($baseLength <= $maxLength || $diffLength <= 0)
      {
        return $htmlString;
      }
    }

    return $html;
  }
}