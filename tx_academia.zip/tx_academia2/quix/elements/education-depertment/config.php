<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

include_once 'helper.php';

$info = new EducationDepertmentElementHelper();
//print_r( $info->getInput());die;
$dpt = array_reduce( $info->getInput(), function ( $carry, $module ) {
  $carry[$module->value] = $module->text;
  return $carry;
}, [ ] );
//$dpt = array();
//print_r($dpt);die;
return [
  "slug" => "education-depertment",
  "name" => "Courses List",
  "groups" => "academia",
  "form" => [
    "general" => [
      [ "name" => "department", "type" => "select", "help"=> "Select depertment", "multiple"=> false, "options" => $dpt ],
      [ "name" => "count", "type" => "text",  "value" => 4, "help"=> "How many item you wanna show?"],
      [ 
          "name" => "layout_style", 
          "type" => "select",  
          "value" => "carosul", 
          "help"=> "How many item you wanna show?",
          "options" => [
              "carosul" => "Carosul", 
              "list" => "List" 
          ]
      ],
      [
        "name" => 'animation', 
        "type" => "select", 
        "value" => 0, 
        "options" => [
          "fadeInLeft" => "Left To Right", 
          "fadeInRight" => "Right To Left", 
          "fadeInUp" => "Bottom To Top", 
          "fadeInDown" => "Top To Bottom",
          "fadeIn" => "Fade In",
          "zoomIn" => "Zoom In",
          0 => 'No Animation'
        ]
      ],
    ]
  ]
];
