<div class="category-module owl-carousel">
    <!-- <div class="row"> -->
    <?php //print_r($list->courses); die;?>

    <?php foreach ($list->courses as $item) : ?>
        <?php // print_r($item); ?>

        <div class="owl-item">
            <div class="met-box">
                <div class="row">
                    <div class="col-xs-12">
                        <figure>
                            <a href="<?php echo JRoute::_('index.php?option=com_txeducation&view=course&id='.(int) $item->id); ?>" title="CELP">
                                <div class="display-block">
                                    <img class="media-object img-responsive" src="<?php echo $item->preview; ?>" alt="">
                                </div>
                                <figcaption>
                                    <?php echo $item->title; ?>
                                </figcaption>
                            </a>
                        </figure>
                    </div>
                    <div class="col-xs-12">
                        <div class="media-body">
                            <h3 class="media-heading">
                                <a class="mod-articles-category-title " href="#"><?php echo $item->title; ?></a>
                            </h3>
                            <div class="mod-articles-category-introtext">
                                <?php echo $item->text; ?>
                            </div>
                            <p class="mod-articles-category-readmore">
                                <a class="mod-articles-category-title  text-uppercase" href="<?php echo JRoute::_('index.php?option=com_txeducation&view=course&id='.(int) $item->id); ?>">
                                    <strong>Read More...</strong>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    <?php endforeach; ?>
    <!-- </div> -->
</div>