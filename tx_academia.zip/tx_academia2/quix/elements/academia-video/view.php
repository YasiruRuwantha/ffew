<?php
  $classes = classNames( "qx-element qx-element-{$type} module-home-feature {$field['class']}", $visibilityClasses, [
    "wow {$field['animation']}" => $field['animation']
  ] );

   // New icon system. Since @1.7
  $icon = get_icon($field);
?>

<?php if($field['trigger_type'] == 'image'): ?>
	
	<?php if($field['video_link']): ?>
	<div id="<?php echo $id;?>" class="<?php echo $classes?>">
	  <div class="video-wrapper" style="background-image: url(<?php echo $field['image'] ?>);">
	    <a href="<?php echo $field['video_link'] ?>" class="popup mfp-iframe vidwrap"></a>
	  </div>
	</div>
	<?php endif;?>

<?php elseif ($field['trigger_type'] == 'icon'): ?>
	<div id="<?php echo $id; ?>" class="<?php echo $classes; ?>">
		<a href="<?php echo $field['video_link'] ?>" class="popup mfp-iframe video-button text-uppercase">
			<i class="<?php echo $icon['class']?>"><?php echo $icon['content']?></i>
			<span><?php echo $field['icon_text'] ?></span>
		</a>
	</div>
<?php endif;?>
<!-- qx-element-academia-video -->


<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('.popup').magnificPopup({
			type: 'iframe'
		});
	});
</script>