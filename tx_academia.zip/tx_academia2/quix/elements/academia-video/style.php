<?php 
###############
# Responsive #
###############

// Typography
Css::typography("#$id a", $field['text_font']);
Css::alignment("#$id", $field['alignment']);

?>

#<?php echo $id;?> .video-wrapper{
	min-height: <?php echo $field['min_height']; ?>
}
#<?php echo $id;?> a{
  <?php Css::prop('color', $field['text_color']);?>
}