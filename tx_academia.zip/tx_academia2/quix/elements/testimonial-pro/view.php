<?php
  // HTML class
  $classes = classNames( "qx-element qx-element-{$type} {$field['class']}", $visibilityClasses,[]);

// css
Assets::Css('qx-slick', QUIX_URL."/assets/css/slick.css");
// JS script
Assets::Js('qx-slick', QUIX_URL."/assets/js/slick.min.js");


  $script = array();
  $script[] = 'fade: true';
  $script[] = 'infinite: true';
  $script[] = 'adaptiveHeight: true';
  $script[] = ($field['arrows']) ? 'arrows:true' : 'arrows:false';
  $script[] = ($field['dots']) ? 'dots:true' : 'dots:false';
  $script[] = ($field['autoplay']) ? 'autoplay:true' : 'autoplay:false';
  $script[] = 'autoplaySpeed:' . $field['autoplay_speed'];
?>

<div id="<?php echo $id; ?>" class="ateam carousel slide at-accordion <?php echo $classes; ?>">
    <?php foreach( $field['testimonials'] as $testimonial ):?>
      <div class="qx-testimonial inner-wrapper">
        <div class="inner-body">
          <div class="qx-testimony"><?php echo $testimonial['testimony']?></div>

          <h4><?php echo $testimonial['name']?></h4>
          <p class="qx-designation qx-text-muted"><?php echo $testimonial['company']?></p>
        </div>
        
        <div class="testi-img inner-image">
          <?php if($testimonial['image']):?>
            <img class="qx-img-responsive <?php echo $field['image_style']?>" src="<?php echo $testimonial['image']?>" alt="<?php echo $testimonial['name']?>">
          <?php endif;?>
        </div>
      </div>
    <?php endforeach;?>
</div>

<script type="text/javascript">
  jQuery(document).ready(function(){
    jQuery('#<?php echo $id?>').slick({<?php echo implode(',', $script)?>});
  });
</script>
<!-- qx-element-testimonial-pro -->