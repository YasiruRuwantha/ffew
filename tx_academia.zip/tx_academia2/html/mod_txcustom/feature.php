<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$show_link = $params->get('show_link');
$link_label = $params->get('link_label');
$video_prev = $params->get('video_prev');
if(isset($video_prev) && !empty($video_prev)){
  $bg = ' style="background-image: url('.$video_prev.');background-repeat:no-repeat;"';
}else {
  $bg = '';
}
$show_name = $params->get('show_name', 0);
JFactory::getDocument()->addStylesheet('media/mod_txgallery/magnific-popup.css');
JFactory::getDocument()->addScript('media/mod_txgallery/jquery.magnific-popup.min.js');
JFactory::getDocument()->addScriptDeclaration("
jQuery(document).ready(function (){
    jQuery('.mfp-iframe').magnificPopup();
});
");

?>
<div class="mod-txcustom<?php echo $modclass_sfx ?>">

  <div class="video-wrapper<?php echo $media_class . $media_wrap_class; ?>"<?php echo $bg; ?>>
    <a href="<?php echo $video; ?>" class="mfp-iframe vidwrap"></a>
  </div>

  <div class="content-wrapper pull-left <?php echo $description_class;?>">
    <div class="content-inner">
      <?php if($show_name): ?>
      <h3 class="module-title">
        <?php echo $name . (isset($name2) ? ' <span>'.$name2.'</span>' : '');?>
      </h3>
      <?php endif; ?>
      <div class="content-desc">
        <?php echo $description;?>

        <?php if($show_link) :?>
            <a class="<?php echo $params->get('link_class');?>" href="<?php echo $params->get('link');?>" title="<?php echo $link_label;?>">
              <?php echo $link_label;?>
            </a>
        <?php endif; ?>
      </div>

    </div>
  </div>

</div>
