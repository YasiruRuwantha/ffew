<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$show_link = $params->get('show_link');
$link_label = $params->get('link_label');
$show_name = $params->get('show_name');
?>
<div id="mod-txcustom<?php echo $module->id; ?>" class="mod-txcustom jumbotron">
  <?php if($media_position == 'top'): ?>
    <?php require JModuleHelper::getLayoutPath('mod_txcustom', basename(__FILE__, '.php') . '_' . $source); ?>
  <?php endif; ?>
  <div class="content-wrapper pull-left <?php echo $description_class;?>">
    <div class="content-inner">
      <?php if($show_name) :?>
      <h4>
        <?php echo $name . (isset($name2) ? ' <span>'.$name2.'</span>' : '');?>
      </h4>
      <?php endif; ?>
      <div class="content-desc">
        <?php echo $description;?>

        <?php if($show_link) :?>
            <a class="<?php echo $params->get('link_class');?>" href="<?php echo $params->get('link');?>" title="<?php echo $link_label;?>">
              <?php echo $link_label;?>
            </a>
        <?php endif; ?>
      </div>

    </div>
  </div>

  <?php if($media_position == 'bottom'): ?>
    <?php require JModuleHelper::getLayoutPath('mod_txcustom', basename(__FILE__, '.php') . '_' . $source); ?>
  <?php endif; ?>

</div>
<script type="text/javascript">
jQuery(document).ready(function (){
  function updateContainer(){
    var window_width = jQuery(window).width();
    if(window_width > 600){
      var whatever = jQuery("#mod-txcustom<?php echo $module->id; ?>");
      var rt = (jQuery(window).width() - (whatever.offset().left + whatever.outerWidth()));
      whatever.css('margin-right', "-" + rt + "px");
    } else {
      whatever.css('margin-right', "0px");
    }   
  }
  updateContainer();
  jQuery(window).on('resize', function() {
        updateContainer();
    });
});
</script>