<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$show_link = $params->get('show_link');
$link_label = $params->get('link_label');

$iname = $icon->name;
$isize = $icon->size;
?>
<?php if($show_link) :?>
<a
  class="<?php echo $params->get('link_class');?>"
  href="<?php echo $params->get('link');?>"
  title="<?php echo $link_label;?>"
  target="_blank">
  <i class="<?php echo $iname . ' ' . $isize; ?>"></i>
  <p class="msg"><?php echo $description;?></p>
  <h5><?php echo $name . (isset($name2) ? ' <span>'.$name2.'</span>' : '');?></h5>
</a>
<?php endif; ?>
