<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$show_link = $params->get('show_link');
$link_label = $params->get('link_label');
$link_class = $params->get('link_class');

JFactory::getDocument()->addStylesheet('media/mod_txgallery/magnific-popup.css');
JFactory::getDocument()->addScript('media/mod_txgallery/jquery.magnific-popup.min.js');
JFactory::getDocument()->addScriptDeclaration("
jQuery(document).ready(function (){
    jQuery('.mfp-iframe').magnificPopup();
});
");
?>
<div class="mod-txcustom clearfix">

  <h3 class="module-title">
    <?php echo $name . (isset($name2) ? ' <span>'.$name2.'</span>' : '');?>
  </h3>
  <div class="module-body">
    <?php echo $description;?>

    <?php if($show_link) :?>
      <p class="item-link">
        <a class="<?php echo $link_class; ?>" href="<?php echo $params->get('link');?>" title="<?php echo $link_label;?>">
          <?php echo $link_label;?>
        </a>
      </p>
    <?php endif; ?>
  </div>
  <?php if($source == 'video' or $source == 'image'): ?>
  <div class="media-box">
    <a href="<?php echo $video; ?>" class="mfp-iframe video-button text-uppercase">
      <i class="fa fa-play-circle-o"></i>
      <span>Watch Video</span>
    </a>    
  </div>
  <?php endif; ?>

</div>
