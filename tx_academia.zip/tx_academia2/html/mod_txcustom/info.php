<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$show_link = $params->get('show_link');
$link_label = $params->get('link_label');
?>
<div class="mod-txcustom<?php echo $modclass_sfx ?> clearfix">
  <h5 class="display-inline text-info">
    <?php echo $description;?>
  </h5>
  <?php if($show_link) :?>
    <p class="display-inline">
      <a class="<?php echo $params->get('link_class');?>" href="<?php echo $params->get('link');?>" title="<?php echo $link_label;?>">
        <?php echo $link_label;?>
      </a>
    </p>
  <?php endif; ?>
</div>
