<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

if(isset($video_prev) && !empty($video_prev))
{
  $bg = ' style="background: url('.$video_prev.') no-repeat;"';
}
else 
{
  $bg = '';
}
?>
<script type="text/javascript">function play<?php echo $module->id; ?>(){document.getElementById('vidwrap<?php echo $module->id; ?>').innerHTML = '<?php echo $video; ?>';}</script>
<div class="video-wrapper<?php echo $media_class . $media_wrap_class; ?>"<?php echo $bg; ?>>
  <div onclick="play<?php echo $module->id; ?>();" class="vidwrap" id="vidwrap<?php echo $module->id; ?>"></div>
</div>
