<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_contact
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/**
 * marker_class: Class based on the selection of text, none, or icons
 */
?>
<div class="contact-address" itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
	<?php if (($this->params->get('address_check') > 0) &&
		($this->contact->address || $this->contact->suburb  || $this->contact->state || $this->contact->country || $this->contact->postcode)) : ?>

		<?php if ($this->contact->telephone && $this->params->get('show_telephone')) : ?>
			<div class="media">
			  <div class="media-left">
			    <i class="ico-call fa-4x"></i>
			  </div>
			  <div class="media-body">
			    <h4 class="media-heading"><?php echo JText::_('TPL_TX_PHONE');?></h4>
			    <p>
						<span class="contact-emailto">
							<?php echo nl2br($this->contact->telephone); ?>
						</span>
			    </p>
			  </div>
			</div>
		<?php endif; ?>

		<?php if ($this->contact->email_to && $this->params->get('show_email')) : ?>
			<div class="media">
			  <div class="media-left">
			    <i class="ico-mail fa-4x"></i>
			  </div>
			  <div class="media-body">
			    <h4 class="media-heading"><?php echo JText::_('TPL_TX_EMAIL');?></h4>
			    <p>
						<span class="contact-emailto">
							<?php echo $this->contact->email_to; ?>
						</span>
			    </p>
			  </div>
			</div>
		<?php endif; ?>

		<?php if ($this->params->get('address_check') > 0) : ?>
			<div class="media">
			  <div class="media-left">
			      <i class="ico-location-on fa-4x"></i>
			  </div>
			  <div class="media-body">
			    <h4 class="media-heading"><?php echo JText::_('TPL_TX_ADDRESS');?></h4>
					<p>
						<?php if ($this->contact->address && $this->params->get('show_street_address')) : ?>
						<span class="contact-street" itemprop="streetAddress">
							<?php echo $this->contact->address .'<br/>'; ?>
						</span>
						<?php endif; ?>

						<?php if ($this->contact->suburb && $this->params->get('show_suburb')) : ?>
						<span class="contact-suburb" itemprop="addressLocality">
							<?php echo $this->contact->suburb .'<br/>'; ?>
						</span>
						<?php endif; ?>

						<?php if ($this->contact->state && $this->params->get('show_state')) : ?>
						<span class="contact-state" itemprop="addressRegion">
							<?php echo $this->contact->state . '<br/>'; ?>
						</span>
						<?php endif; ?>

						<?php if ($this->contact->postcode && $this->params->get('show_postcode')) : ?>
						<span class="contact-postcode" itemprop="postalCode">
							<?php echo $this->contact->postcode .'<br/>'; ?>
						</span>
						<?php endif; ?>

						<?php if ($this->contact->country && $this->params->get('show_country')) : ?>
						<span class="contact-country" itemprop="addressCountry">
							<?php echo $this->contact->country .'<br/>'; ?>
						</span>
						<?php endif; ?>

					</p>

			  </div>
			</div>
		<?php endif; ?>

		<?php endif; ?>
</div>
