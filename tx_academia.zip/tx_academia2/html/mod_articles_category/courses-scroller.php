<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_category
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$doc = JFactory::getDocument();
$doc->addStylesheet(JUri::root().'templates/tx_academia2/js/owl-carousel/owl.carousel.css');
$doc->addStylesheet(JUri::root().'templates/tx_academia2/js/owl-carousel/owl.theme.css');
$doc->addScript(JUri::root().'templates/tx_academia2/js/owl-carousel/owl.carousel.js');

$doc->addScriptDeclaration('
jQuery(document).ready(function() {

  jQuery(".owl-carousel").owlCarousel({
		// rtl: true,
		items : 4,
		pagination : false,
		navigation : true,
		navigationText : ["<i class=\"ico-chevron-left\"></i>","<i class=\"ico-chevron-right\"></i>"],
	});

});
');
?>
<div class="category-module<?php echo $moduleclass_sfx; ?> owl-carousel">
	<!-- <div class="row"> -->
	<?php foreach ($list as $key=> $item) :
		// $colwrap = (($key !=0 && $key%2 == '0') ? '</div><div class="row"><div class="col-sm-6 mod-category-item">' : '<div class="col-sm-6 mod-category-item">');
		$images = json_decode($item->images);
		// echo $colwrap;
		?>
			<div class="met-box">
				<div class="row">
					<?php if(isset($images->image_intro)) : ?>
				  <div class="col-xs-12">
						<figure>
							<a href="<?php echo $item->link; ?>" title="<?php echo $item->title; ?>">
								<div class="display-block">
									<img class="media-object img-responsive" src="<?php echo JURI::base().$images->image_intro; ?>" alt="<?php echo $images->image_intro_alt; ?>">
								</div>
								<figcaption>
									<?php 
									if ($images->image_intro_caption):
										echo $images->image_intro_caption;
									else:
										echo $item->title;
									endif; ?>
								</figcaption>
							</a>
					 	</figure>
				  </div>
					<?php endif; ?>
				  <div class="col-xs-12">
				    <div class="media-body">
					    <h3 class="media-heading">
								<?php if ($params->get('link_titles') == 1) : ?>
									<a class="mod-articles-category-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
										<?php echo $item->title; ?>
									</a>
								<?php else : ?>
									<?php echo $item->title; ?>
								<?php endif; ?>
							</h3>
							<?php if ($item->displayHits) : ?>
								<span class="mod-articles-category-hits">
									(<?php echo $item->displayHits; ?>)
								</span>
							<?php endif; ?>

							<?php if ($params->get('show_author')) : ?>
								<span class="mod-articles-category-writtenby">
									<?php echo $item->displayAuthorName; ?>
								</span>
							<?php endif;?>

							<?php if ($item->displayCategoryTitle) : ?>
								<span class="mod-articles-category-category">
									(<?php echo $item->displayCategoryTitle; ?>)
								</span>
							<?php endif; ?>

							<?php if ($item->displayDate) : ?>
								<span class="mod-articles-category-date"><?php echo $item->displayDate; ?></span>
							<?php endif; ?>

							<?php if ($params->get('show_introtext')) : ?>
								<p class="mod-articles-category-introtext">
									<?php echo $item->displayIntrotext; ?>
								</p>
							<?php endif; ?>

							<?php if ($params->get('show_readmore')) : ?>
								<p class="mod-articles-category-readmore">
									<a class="mod-articles-category-title <?php echo $item->active; ?> text-uppercase" href="<?php echo $item->link; ?>">
										<strong>
										<?php if ($item->params->get('access-view') == false) : ?>
											<?php echo JText::_('MOD_ARTICLES_CATEGORY_REGISTER_TO_READ_MORE'); ?>
										<?php elseif ($readmore = $item->alternative_readmore) : ?>
											<?php echo $readmore; ?>
											<?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
												<?php if ($params->get('show_readmore_title', 0) != 0) : ?>
													<?php echo JHtml::_('string.truncate', ($this->item->title), $params->get('readmore_limit')); ?>
												<?php endif; ?>
										<?php elseif ($params->get('show_readmore_title', 0) == 0) : ?>
											<?php echo JText::sprintf('MOD_ARTICLES_CATEGORY_READ_MORE_TITLE'); ?>
										<?php else : ?>
											<?php echo JText::_('MOD_ARTICLES_CATEGORY_READ_MORE'); ?>
											<?php echo JHtml::_('string.truncate', ($item->title), $params->get('readmore_limit')); ?>
										<?php endif; ?>
										</strong>
									</a>
								</p>
							<?php endif; ?>

				  	</div>
				  </div>
				</div>

			</div>
		<!-- </div> -->
	<?php endforeach; ?>
	<!-- </div> -->
</div>
