<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_category
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$delay = 0;
?>
<div class="category-module<?php echo $moduleclass_sfx; ?>">
	<div class="row">
	<?php foreach ($list as $key=> $item) :
		$delay = $delay + 0.3;
		$colwrap = (($key !=0 && $key%4 == '0') ? '</div><div class="row"><div class="col-md-3 col-xs-6 category-news-item">' : '<div class="col-md-3 col-xs-6 mod-category-item">');
		$images = json_decode($item->images);
		echo $colwrap;
		?>
			<div class="met-box no-padding wow fadeIn" data-wow-delay="<?php echo $delay, 's'; ?>">
				<?php if(isset($images->image_intro)) : ?>
					<figure>
						<a href="<?php echo $item->link; ?>" title="<?php echo $item->title; ?>">
							<img class="img-responsive" src="<?php echo JURI::base().$images->image_intro; ?>" alt="<?php echo $images->image_intro_alt; ?>">
					  </a>
				 	</figure>
				<?php endif; ?>
					<div class="category-info-box">

					<?php if ($item->displayHits) : ?>
						<span class="category-hits text-muted">
							(<?php echo $item->displayHits; ?>)
						</span>
					<?php endif; ?>

					<?php if ($params->get('show_author')) : ?>
						<span class="category-writtenby text-muted">
							<?php echo $item->displayAuthorName; ?>
						</span>
					<?php endif;?>

					<?php if ($item->displayCategoryTitle) : ?>
						<span class="category-category text-muted">
							(<?php echo $item->displayCategoryTitle; ?>)
						</span>
					<?php endif; ?>

					<?php if ($item->displayDate) : ?>
						<span class="category-date text-muted"><?php echo $item->displayDate; ?></span>
					<?php endif; ?>

					<h4 class="news-heading">
						<?php if ($params->get('link_titles') == 1) : ?>
							<a class="category-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
								<?php echo $item->title; ?>
							</a>
						<?php else : ?>
							<?php echo $item->title; ?>
						<?php endif; ?>
					</h4>

					<?php if ($params->get('show_introtext')) : ?>
						<p class="category-introtext">
							<?php echo $item->displayIntrotext; ?>
						</p>
					<?php endif; ?>

					<?php if ($params->get('show_readmore')) : ?>
						<p class="category-readmore">
							<a class="category-title <?php echo $item->active; ?>" href="<?php echo $item->link; ?>">
								<?php if ($item->params->get('access-view') == false) : ?>
									<?php echo JText::_('MOD_ARTICLES_CATEGORY_REGISTER_TO_READ_MORE'); ?>
								<?php elseif ($readmore = $item->alternative_readmore) : ?>
									<?php echo $readmore; ?>
									<?php echo JHtml::_('string.truncate', $item->title, $params->get('readmore_limit')); ?>
										<?php if ($params->get('show_readmore_title', 0) != 0) : ?>
											<?php echo JHtml::_('string.truncate', ($this->item->title), $params->get('readmore_limit')); ?>
										<?php endif; ?>
								<?php elseif ($params->get('show_readmore_title', 0) == 0) : ?>
									<?php echo JText::sprintf('MOD_ARTICLES_CATEGORY_READ_MORE_TITLE'); ?>
								<?php else : ?>
									<?php echo JText::_('MOD_ARTICLES_CATEGORY_READ_MORE'); ?>
									<?php echo JHtml::_('string.truncate', ($item->title), $params->get('readmore_limit')); ?>
								<?php endif; ?>
							</a>
						</p>
					<?php endif; ?>
			  	</div>
				</div>
			</div>
	<?php endforeach; ?>
	</div>
</div>
