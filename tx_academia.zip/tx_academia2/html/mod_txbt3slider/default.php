<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
JFactory::getDocument()->addStylesheet('modules/mod_txbt3slider/css/style.css');
$total = count($lists);
$width = (100 / $total);
$list_indicator = '';
?>
<div class="mod-txbt3slider mod-txbt3slider-wrapper<?php echo $moduleclass_sfx ?>">
    <div id="txbt3slider-slideshow-<?php echo $module->id ?>" class="slider-<?php echo $moduleclass_sfx ?> carousel slide carousel-fade" data-ride="carousel" data-interval="<?php echo $interval; ?>">

        <div class="carousel-inner">
          <?php foreach ($lists as $key => $item) : ?>
            <div class="item<?php echo ($key == 0 ? ' active' : '');?>">
              <div class="item-wrapper row">
                <div class="col-md-7">
                  <div class="img" data-animation="animated fadeInLeft">
                      <img src="<?php echo $item['image'];?>" alt="<?php echo $item['title'];?>" class="img-responsive" />
                  </div>
                </div>
                <div class="col-md-5">
                  <div class="jumbotron">

                    <h2 class="heading" data-animation="animated fadeInRight">
                        <?php echo $item['title'];?>
                    </h2>
                    <p class="intro lead" data-animation="animated fadeInRight">
                        <?php echo $item['desc'];?>
                    </p>

                    <a data-animation="animated fadeInRight" href="<?php echo $item['link'];?>" title="<?php echo $item['title'];?>" class="btn btn-rounded btn-primary btn-lg btn-special"><?php echo $item['link_lbl'];?></a>

                  </div>
                </div>
              </div>
            </div>
            <?php
            $list_indicator .= '<li data-target="#txbt3slider-slideshow-'.$module->id.'" data-slide-to="'.$key.'" class="'.($key == 0 ? 'active' : '').'" style="width: '.$width.'%;">
                <span class="title ">'.$item['title'].'</span>
            </li>';
             ?>
          <?php endforeach; ?>
        </div>

        <ul class="carousel-indicators">
          <?php echo $list_indicator; ?>
        </ul>

        <a data-slide="prev" role="button" href="#txbt3slider-slideshow-<?php echo $module->id ?>" class="left carousel-control"><i class="fa fa-angle-left"></i></a>
        <a data-slide="next" role="button" href="#txbt3slider-slideshow-<?php echo $module->id ?>" class="right carousel-control"><i class="fa fa-angle-right"></i></a>
    </div>
</div>
