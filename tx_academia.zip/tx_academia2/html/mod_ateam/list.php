<?php
/**
 * @package aTeam Module
 * @version ##VERSION##
 * @author ThemeXpert http://www.themexpert.com
 * @copyright Copyright (C) 2010 - 2015 ThemeXpert
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */
//http://www.cssscript.com/demo/pure-css3-animated-text-overlay-on-hover/
// no direct access
defined('_JEXEC') or die;
$i = 0;
?>

<div id="ateam-<?php echo $module->id; ?>" class="ateam at-<?php echo $params->get('layout');?>">
  <?php foreach( $params->get('teams') as $team ) : ?>
    <div class="media">
      <figure class="media-left">
        <?php if( !empty($team->image) ): ?>
            <img class="<?php echo $params->get('image_style')?> media-object" src="<?php echo $team->image ;?>" alt="<?php echo $team->name; ?>">
        <?php endif;?>
      </figure>
      <div class="media-body">
        <h4><?php echo $team->name; ?></h4>
        <h5 class="text-muted"><?php echo $team->designation; ?></h5>
        <?php if( !empty($team->description) ): ?>
            <p class="at-desc"><?php echo $team->description; ?></p>
        <?php endif; ?>
        <?php if( $team->facebook OR $team->twitter OR $team->linkedin OR $team->gplus ):?>
            <div class="at-social">
                <?php if($team->facebook): ?>
                    <a href="<?php echo $team->facebook ?>" target="_blank"><span class="aticon-facebook"></span></a>
                <?php endif;?>
                <?php if($team->twitter): ?>
                    <a href="<?php echo $team->twitter ?>" target="_blank"><span class="aticon-twitter"></span></a>
                <?php endif;?>
                <?php if($team->linkedin): ?>
                    <a href="<?php echo $team->linkedin ?>" target="_blank"><span class="aticon-linkedin"></span></a>
                <?php endif;?>
                <?php if($team->gplus): ?>
                    <a href="<?php echo $team->gplus ?>" target="_blank"><span class="aticon-google"></span></a>
                <?php endif;?>
            </div>
        <?php endif; ?>
      </div>
    </div>
    <?php $i++; endforeach;?>
</div>
