<?php
/**
 * @package aTeam Module
 * @version ##VERSION##
 * @author ThemeXpert http://www.themexpert.com
 * @copyright Copyright (C) 2010 - 2015 ThemeXpert
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */
//http://www.cssscript.com/demo/pure-css3-animated-text-overlay-on-hover/
// no direct access
defined('_JEXEC') or die;
$i = 0;
$total = count($params->get('teams'));
?>
<div id="ateam-<?php echo $module->id; ?>" class="ateam carousel slide at-<?php echo $params->get('layout');?>" data-ride="carousel">
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php foreach( $params->get('teams') as $team ) : ?>
            <div class="item<?php echo ($i == 0 ? " active" : ""); ?>">
                <div class="inner-wrapper">
                    <div class="inner-body">
                        <?php if( !empty($team->description) ): ?>
                            <p class="at-desc"><?php echo $team->description; ?></p>
                        <?php endif; ?>
                        
                        <h4><?php echo $team->name; ?></h4>
                        <h5><?php echo $team->designation; ?></h5>

                        <?php if( $team->facebook OR $team->twitter OR $team->linkedin OR $team->gplus ):?>
                            <div class="at-social">
                                <?php if($team->facebook): ?>
                                    <a href="<?php echo $team->facebook ?>" target="_blank"><span class="aticon-facebook"></span></a>
                                <?php endif;?>
                                <?php if($team->twitter): ?>
                                    <a href="<?php echo $team->twitter ?>" target="_blank"><span class="aticon-twitter"></span></a>
                                <?php endif;?>
                                <?php if($team->linkedin): ?>
                                    <a href="<?php echo $team->linkedin ?>" target="_blank"><span class="aticon-linkedin"></span></a>
                                <?php endif;?>
                                <?php if($team->gplus): ?>
                                    <a href="<?php echo $team->gplus ?>" target="_blank"><span class="aticon-google"></span></a>
                                <?php endif;?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="inner-image">
                        <?php if( !empty($team->image) ): ?>
                            <img class="<?php echo $params->get('image_style')?> img-responsive" src="<?php echo $team->image ;?>" alt="<?php echo $team->name; ?>">
                        <?php endif;?>
                    </div>
                </div>
            </div>
        <?php $i++; endforeach;?>
    </div>
    <ol class="carousel-indicators">
        <?php for ($j=0; $j < $i; $j++) { ?>
           <li data-target="#ateam-<?php echo $module->id; ?>" data-slide-to="<?php echo $j ?>"<?php echo ($j == 0 ? ' class="active"' : ""); ?>></li>             
        <?php } ?>
    </ol>

</div>
