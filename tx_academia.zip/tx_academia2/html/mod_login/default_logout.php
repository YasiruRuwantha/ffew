<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_login
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

require_once JPATH_SITE . '/components/com_users/helpers/route.php';

JHtml::_('behavior.keepalive');
if (version_compare(JVERSION, '3.0', 'ge')) {
	JHtml::_('bootstrap.tooltip');
	JHtml::_('bootstrap.modal');
}

?>
<div class="modal fade" id="loginModalAccess" tabindex="-1" role="dialog" aria-labelledby="loginModalAccessLabel">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"><?php echo $module->title;?></h4>
      </div>
      <div class="modal-body">
					<form action="<?php echo JRoute::_('index.php', true, $params->get('usesecure')); ?>" method="post" id="login-form"
						  class="form-vertical">
						<?php if ($params->get('greeting')) : ?>
							<div class="login-greeting">
								<?php if ($params->get('name') == 0) : {
									echo JText::sprintf('MOD_LOGIN_HINAME', htmlspecialchars($user->get('name')));
								} else : {
									echo JText::sprintf('MOD_LOGIN_HINAME', htmlspecialchars($user->get('username')));
								} endif; ?>
							</div>
						<?php endif; ?>
						<div class="logout-button">
							<input type="submit" name="Submit" class="btn btn-primary" value="<?php echo JText::_('JLOGOUT'); ?>"/>
							<input type="hidden" name="option" value="com_users"/>
							<input type="hidden" name="task" value="user.logout"/>
							<input type="hidden" name="return" value="<?php echo $return; ?>"/>
							<?php echo JHtml::_('form.token'); ?>
						</div>
					</form>
			</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
