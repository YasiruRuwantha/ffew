<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_latest
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
// var_dump($list);
$items = array_chunk($list, 4);
?>

<?php foreach($items as $item):?>
	<div class="row-fluid">
	<?php foreach($item as $product):?>
		<?php
			$images = json_decode($product->images);
		?>
		<div class="col-sm-3">
			<div class="block product" itemscope itemtype="http://schema.org/Product">
				<figure>
					<a href="<?php echo $product->link; ?>" itemprop="url">
						<div class="img-wrapper">
							<img class="img-responsive" src="<?php echo $images->image_intro?>" alt="<?php echo $product->name?>" />
						</div>
					</a>
					<?php if($product->price <= 0) :?>
						<figcaption>
								<span class="product-type-free"><?php echo JText::_('TPL_ACADEMIA_DIGICOM_PRICE'); ?></span>
						</figcaption>
					<?php endif;?>
				</figure>
				<div class="details">
					<h3 itemprop="name"><?php echo $product->name; ?></h3>
					<p class="product-tagline" itemprop="description"><?php echo $product->introtext?></p>
					<a class="btn btn-primary" itemprop="url" href="<?php echo $product->link; ?>">
						<?php echo JText::_('TPL_ACADEMIA_DIGICOM_PRICE_BUTTON'); ?>
						<span>
							<sup></sup>
						</span>
					</a>
				</div>
			</div>
		</div>
	<?php endforeach; ?>
</div>
<?php endforeach;?>
<p class="align-center">
	<a href="/digicom-addons" class="btn btn-primary btn-outline btn-large"><?php echo JText::_('TPL_ACADEMIA_DIGICOM_MORE_BUTTON'); ?></a>
</p>
