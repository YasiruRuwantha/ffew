<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_latest
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
$params->set('catid', 26); // Joomla template cat id
$joomla            = ModDigiComProductsHelper::getList($params);
$params->set('catid', 28); // WP themes cat id
$wordpress            = ModDigiComProductsHelper::getList($params);
?>
<ul class="nav nav-tabs nav--themes flex flex-center" id="myTab">
  <li class="active"><a href="#jt" data-toggle="tab"><span class="fa fa-joomla"></span><?php echo JText::_('TPL_ACADEMIA_DIGICOM_TAB1'); ?></a></li>
  <li><a href="#wt" data-toggle="tab"><span class="fa fa-wordpress"></span> <?php echo JText::_('TPL_ACADEMIA_DIGICOM_TAB2'); ?></a></li>
</ul>

<div class="tab-content">
  <div class="tab-pane active" id="jt">
    <div class="row-fluid">
      <?php foreach($joomla as $product):?>
    		<?php
    			$images = json_decode($product->images);
          $info = json_decode($product->attribs);
    		?>
    		<div class="grid4">
    			<div class="block product" itemscope itemtype="http://schema.org/Product">
    				<figure>
    					<a href="<?php echo $product->link; ?>" itemprop="url">
    						<div class="img-wrapper">
    							<img src="<?php echo $images->image_intro?>" alt="<?php echo $product->name?>" />
    						</div>
    					</a>
              <figcaption>
          			<?php if($product->price <= 0) :?>
          				<span class="product-type-free"><?php echo JText::_('TPL_ACADEMIA_DIGICOM_PRICE'); ?></span>
          			<?php endif;?>
          			<?php if($product->featured): ?>
          				<span class="label label-info label--featured"><?php echo JText::_('TPL_ACADEMIA_DIGICOM_FEATURED'); ?></span>
          			<?php endif; ?>
          			<div class="flex flex-middle flex-center btns">
          				<a class="btn btn-primary btn-large" href="<?php echo $product->link; ?>">View <?php echo $product->name; ?></a>
          			</div>
          		</figcaption>
    				</figure>
    				<div class="details">
    					<h3 itemprop="name"><?php echo $product->name; ?></h3>
              <?php if(isset($info->tagline)): ?>
          		<p class="product-tagline"><?php echo $info->tagline; ?></p>
          		<?php endif; ?>
    				</div>
    			</div>
    		</div>
    	<?php endforeach; ?>
    </div>
  </div>
  <div class="tab-pane" id="wt">
    <div class="row-fluid">
      <?php foreach($wordpress as $product):?>
    		<?php
    			$images = json_decode($product->images);
          $info = json_decode($product->attribs);
    		?>
    		<div class="grid4">
    			<div class="block product" itemscope itemtype="http://schema.org/Product">
    				<figure>
    					<a href="<?php echo $product->link; ?>" itemprop="url">
    						<div class="img-wrapper">
    							<img src="<?php echo $images->image_intro?>" alt="<?php echo $product->name?>" />
    						</div>
    					</a>
              <figcaption>
          			<?php if($product->price <= 0) :?>
          				<span class="product-type-free"><?php echo JText::_('TPL_ACADEMIA_DIGICOM_PRICE'); ?></span>
          			<?php endif;?>
          			<?php if($product->featured): ?>
          				<span class="label label-info label--featured"><?php echo JText::_('TPL_ACADEMIA_DIGICOM_FEATURED'); ?></span>
          			<?php endif; ?>
          			<div class="flex flex-middle flex-center btns">
          				<a class="btn btn-primary btn-large" href="<?php echo $product->link; ?>">View <?php echo $product->name; ?></a>
          			</div>
          		</figcaption>
    				</figure>
    				<div class="details">
    					<h3 itemprop="name"><?php echo $product->name; ?></h3>
              <?php if(isset($info->tagline)): ?>
          		<p class="product-tagline"><?php echo $info->tagline; ?></p>
          		<?php endif; ?>
    				</div>
    			</div>
    		</div>
    	<?php endforeach; ?>
    </div>
  </div>
</div>
