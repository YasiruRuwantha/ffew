<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Txeducation
 * @author     ThemeXpert <themexpert@gmail.com>
 * @copyright  2016 ThemeXpert
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_txeducation.' . $this->item->id);
if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_txeducation' . $this->item->id)) {
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>


<?php if ($this->item) : ?>

	<div class="courses">
		<?php if ($this->params->get('enable_dept_title')==1) : ?>
		<h3 class="article-title">
			<?php echo $this->item->title; ?>
		</h3>
		<?php endif;?>
		<div class="lead"><?php echo $this->item->description; ?></div>
		
		<div class="items-row cols-2 row-0 row">
			<?php foreach ($this->item->courses as $key => $course) { ?>	
				<?php //print_r($this->item); die;?>
				<div class="col-md-6 col-sm-6">
					<div class="item met-box column-1">
						<article class="course-hr">
							<section class="row clearfix">
								<div class="col-md-6">
									<figure>
										<a href="<?php echo JRoute::_('index.php?option=com_txeducation&view=course&id='.(int) $course->id); ?>">
											<div class="item-image display-block">
												<img class="img-responsive" src="<?php echo JUri::root() . $course->preview; ?>" alt="">
											</div>
											<figcaption><?php echo $this->escape($course->title); ?></figcaption>
										</a>
									</figure>
								</div>
								<div class="col-md-6">
									<div class="article-intro">
										<header class="article-header clearfix">
											<h3 class="article-title"><?php echo $this->escape($course->title); ?></h3>
										</header>
										<div><?php echo $course->text; ?></div>
										
										<?php //print_r($course); die;?>

										<section class="readmore">
											<a class="text-uppercase " href="<?php echo JRoute::_('index.php?option=com_txeducation&view=course&id='.(int) $course->id); ?>"><span><?php echo JText::_('COM_TXEDUCATION_DEPARTMENT_READMORE'); ?></span></a>
										</section>
									</div>
								</div>
							</section>
						</article>
					</div><!-- end item -->
				</div>
				
			<?php } ?>
		</div>
		
	</div>

	<?php if($canEdit && $this->item->checked_out == 0): ?>
		<a class="btn" href="<?php echo JRoute::_('index.php?option=com_txeducation&task=department.edit&id='.$this->item->id); ?>"><?php echo JText::_("COM_TXEDUCATION_EDIT_ITEM"); ?></a>
	<?php endif; ?>
								<?php if(JFactory::getUser()->authorise('core.delete','com_txeducation.department.'.$this->item->id)):?>
									<a class="btn" href="<?php echo JRoute::_('index.php?option=com_txeducation&task=department.remove&id=' . $this->item->id, false, 2); ?>"><?php echo JText::_("COM_TXEDUCATION_DELETE_ITEM"); ?></a>
								<?php endif; ?>
	<?php
else:
	echo JText::_('COM_TXEDUCATION_ITEM_NOT_LOADED');
endif;
