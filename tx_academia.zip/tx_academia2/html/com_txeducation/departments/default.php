<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Txeducation
 * @author     ThemeXpert <themexpert@gmail.com>
 * @copyright  2016 ThemeXpert
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT . '/helpers/html');
JHtml::_('bootstrap.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('formbehavior.chosen', 'select');

$user       = JFactory::getUser();
$userId     = $user->get('id');
$canCreate  = $user->authorise('core.create', 'com_txeducation');
$canEdit    = $user->authorise('core.edit', 'com_txeducation');
$canCheckin = $user->authorise('core.manage', 'com_txeducation');
$canChange  = $user->authorise('core.edit.state', 'com_txeducation');
$canDelete  = $user->authorise('core.delete', 'com_txeducation');
$items = array();
$column			= $this->params->get('dept_column', 3);
if(count($this->items)){
	$items = array_chunk($this->items, $column);
}
$grid = 12/$column;
?>

<div id="txeducation" class="txeducation departments-list">
	<?php if($this->params->get('enable_intro', 1)): ?>
	<h2 class="landing-title">
		<?php echo $this->params->get('landing_title', '') ?>
	</h2>
	<div class="landing-desc">
		<?php echo $this->params->get('landing_description', '') ?>
	</div>
	<?php endif; ?>
		        
	<form action="<?php echo JRoute::_('index.php?option=com_txeducation&view=departments'); ?>" method="post"
      name="adminForm" id="adminForm">
			
			<div class="dc-items" data-digicom-items>
				<?php if(count($items)): ?>
					<?php foreach($items as $row) :?>
					<div class="row">
						<?php foreach($row as $item) :?>
							<div class="col-md-<?php echo $grid?> span<?php echo $grid?>">
								<?php
									// Load item template
									$this->item = $item;
									echo $this->loadTemplate('item');
								?>
							</div>
						<?php endforeach;?>
					</div>
					<?php endforeach; ?>
				<?php endif;?>
				</div>

			<div class="pagination"><?php echo $this->pagination->getListFooter(); ?></div>
	</form>

</div>