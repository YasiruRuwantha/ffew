<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Txeducation
 * @author     ThemeXpert <themexpert@gmail.com>
 * @copyright  2016 ThemeXpert
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;
$item = $this->item;
?>
<div class="thumbnail">
	<?php if(!empty($item->banner)): ?>
		<img src="<?php echo JUri::root().$item->banner ;?>" alt="<?php echo $item->title; ?>">
	<?php endif; ?>
	<div class="caption">
    <h3><?php echo $item->title; ?></h3>
    <div class="department-desc description">
    	<?php echo $item->description; ?>
    </div>
    <p>
    	<a href="<?php echo JRoute::_('index.php?option=com_txeducation&view=department&id='.(int) $item->id); ?>" class="btn btn-primary" role="button">
				<?php echo JText::_('COM_TXEDUCATION_READMORE'); ?>
    	</a>
  	</p>
  </div>
</div>