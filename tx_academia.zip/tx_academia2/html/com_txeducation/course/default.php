<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Txeducation
 * @author     ThemeXpert <themexpert@gmail.com>
 * @copyright  2016 ThemeXpert
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;
require_once __DIR__ . '/../../../modulehelper.php';

$canEdit = JFactory::getUser()->authorise('core.edit', 'com_txeducation.' . $this->item->id);
if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_txeducation' . $this->item->id)) {
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
$dept = $this->item->dept_id;
$course_title = $this->item->title;
$subtitle = $this->item->options->leading_title;
$course_description = $this->item->text;
$course_video = $this->item->options->preview_video;
$course_price = $this->item->options->fee;
$course_apply = $this->item->options->apply_link;
$course_teachers = $this->item->teachers;
$course_info = $this->item->options->info;


//print_r($this->item);        die;


$source = parse_url($course_video);
switch ($source['host']) {
	case 'youtube.com':
	case 'www.youtube.com':
		parse_str($source['query'], $query);
		$video_id = $query['v'];
		$video_url = '//www.youtube.com/embed/' . $video_id;
		break;
	case 'youtu.be' :
		$video_id = trim( $source['path'], '/' );
		$video_url = '//www.youtube.com/embed/' . $video_id;
		break;
	case 'vimeo.com':
	case 'www.vimeo.com':
		$video_id = trim($source['path'],'/');
		$video_url = '//player.vimeo.com/video/' . $video_id;
}

//print_r($this->item)        ;

?>

<div class="course-item-wrapper">
	<div class="item-page clearfix">
		<article itemscope itemtype="http://schema.org/Article">

			<header class="course-header" style="background-image:url(<?php echo JUri::root() . $this->item->banner; ?>);">
				<div class="container">
					<div class="row-">
						<div class="col-xs-12-">
			
							<?php if (!empty($dept)) : ?>
<!--							<button class="btn btn-primary text-uppercase">--><?php //echo $dept; ?><!--</button>-->
							<?php endif; ?>
							
							<?php if (!empty($course_title)) : ?>
								<h1><?php echo $course_title; ?></h1>
							<?php endif; ?>
							
							<?php if (isset($subtitle)) : ?>
								<p class="lead"><?php echo $subtitle; ?></p>
							<?php endif; ?>
						
						</div>
					</div>
				</div>
			</header>
			
			<div class="courses-content container">
				<div class="row">
					<div class="col-md-8 col-sm-7">
						<?php if (!empty($course_description)) : ?>
							<section class="article-content clearfix"><?php echo $course_description; ?></section>
						<?php endif; ?>
					</div>
					
					<div class="col-md-4 col-sm-5">
						<div class="met-box">
							<?php if (!empty($course_video)) : ?>
							<figure>
								<iframe src="<?php echo $video_url; ?>" width="100%" height="250px"></iframe>
							</figure>
							<?php endif; ?>
							<?php if(!empty($course_price)) : ?>
							<h3><?php echo JText::_('COM_TXEDUCATION_COURSE_FEE'); ?> : <?php echo $course_price; ?></h3>
							<?php endif; ?>

							<?php if (!empty($course_apply)) : ?>
							<h4><a href="<?php echo $course_apply; ?>" class="text-primary">Apply Now</a></h4>
							<?php endif; ?>
						</div><!--/.met-box-->

						<div class="t3-module module-course-tutor met-box " id="Mod175">
							<div class="module-inner">
								<h3 class="module-title "><?php echo JText::_('COM_TXEDUCATION_COURSE_TUTORS'); ?></h3>
								<div class="module-ct">
									<div id="ateam-175" class="ateam at-list">
										
										<?php foreach ($course_teachers as $teacher) { ?>
										
										<div class="media">
											<figure class="media-left">
												<img class="circle media-object" src="<?php echo JUri::root() . $teacher->image; ?>" alt="Paul Groves">
											</figure>
											<div class="media-body">
												<h4><?php echo $teacher->name; ?></h4>
												<h5 class="text-muted"><?php echo $teacher->designation; ?></h5>
												<div class="at-desc"><?php echo $teacher->biography; ?></div>
												
												<div class="at-social">
													<?php foreach ($teacher->social as $social) { ?>
													<a href="<?php echo $social->link ?>" target="_blank"><span class="<?php echo $social->class ?>"></span></a>
													<?php } ?>
												</div>
												
											</div>
										</div>
										<?php } ?>										
										
									</div>
								</div>
							</div>
						</div><!--/.met-box-->

						<div class="t3-module module- met-box " id="Mod176">
							<div class="module-inner">
								<h3 class="module-title "><?php echo JText::_('COM_TXEDUCATION_QUICK_INFO'); ?></h3>
								<div class="module-ct">
									<div class="mod-txlinks">
										<?php foreach ($course_info as $info ) { ?>
										<div class="media">
											<div class="media-left">
												<i class="<?php echo $info->class ?>"></i>
											</div>
											<div class="media-body">
												<?php echo $info->label ?>
											</div>
										</div>
										<?php } ?>
										
									</div>
								</div>
							</div>
						</div><!--/.met-box-->
						
						<?php echo JoomlaModuleHelper::loadModulebyPosition($this->item->alias, 't3Xhtml'); ?>

						<?php echo JoomlaModuleHelper::loadModulebyPosition('course_banner', 't3Xhtml'); ?>
						
					</div>
				</div>

				<div class="clearfix">
					<?php echo JoomlaModuleHelper::loadModulebyPosition('course_bottom', 't3Xhtml'); ?>
					<?php echo JoomlaModuleHelper::loadModulebyPosition($this->item->alias . '_bottom', 't3Xhtml'); ?>
				</div>
				
			</div>
		</article>

	</div>
</div>