<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_search
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>
<div class="mod-txlinks">
    <?php foreach ($lists as $key => $value) : ?>
      <div class="media">
          <div class="media-left">
            <i class="<?php echo $value['icon']; ?>"></i>
          </div>
          <div class="media-body">
            <?php echo $value['label']; ?>
          </div>
      </div>
    <?php endforeach; ?>
</div>
