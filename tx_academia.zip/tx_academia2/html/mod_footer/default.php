<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_footer
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;
?>
<div class="module">
	<p class="pull-left">
			<?php echo $lineone; ?>
	</p>
	<p class="pull-right">
			Designed by <a href="https://www.themexpert.com/" title="Visit ThemeXpert!" <?php echo method_exists('T3', 'isHome') && T3::isHome() ? '' : 'rel="nofollow"' ?>>ThemeXpert</a></small>
	</p>
</div>
