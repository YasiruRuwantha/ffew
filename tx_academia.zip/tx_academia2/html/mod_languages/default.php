<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_languages
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
JHtml::_('formbehavior.chosen', 'select');
?>
<div class="mod-languages<?php echo $moduleclass_sfx ?>">
<?php if ($headerText) : ?>
	<div class="pretext"><p><?php echo $headerText; ?></p></div>
<?php endif; ?>


	<form class="form form-inline" name="lang" method="post" action="<?php echo htmlspecialchars(JUri::current()); ?>">
		<select class="form-control" onchange="document.location.replace(this.value);" >
		<?php foreach ($list as $language) : ?>
			<option dir=<?php echo JLanguage::getInstance($language->lang_code)->isRtl() ? '"rtl"' : '"ltr"'?> value="<?php echo $language->link;?>" <?php echo $language->active ? 'selected="selected"' : ''?>>
			<?php echo $language->title_native;?></option>
		<?php endforeach; ?>
		</select>
	</form>

<?php if ($footerText) : ?>
	<div class="posttext"><p><?php echo $footerText; ?></p></div>
<?php endif; ?>
</div>
