<?php
/**
 * @package Xpert Contact
 * @version ##VERSION##
 * @author ThemeXpert http://www.themexpert.com
 * @copyright Copyright (C) 2009 - 2011 ThemeXpert
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Load jQuery
JHtml::_('jquery.framework');
?>

<div id="xcon-<?php echo $module->id; ?>" class="xpert-contact">

  <div id="xcon-msg"></div>

  <form id="xcon-form">
    <div>
<!--      <label>--><?php //echo JText::_('NAME'); ?><!--</label>-->
      <input type="text" name="jform[name]" placeholder="Your Name" required />
    </div>

    <div>
<!--      <label>--><?php //echo JText::_('EMAIL'); ?><!--</label>-->
      <input type="email" name="jform[email]" placeholder="Your Email" required />
    </div>

    <div>
<!--      <label>--><?php //echo JText::_('SUBJECT'); ?><!--</label>-->
      <input type="text" name="jform[subject]" placeholder="Your Subject" required />
    </div>

    <div>
<!--      <label>--><?php //echo JText::_('MESSAGE'); ?><!--</label>-->
      <textarea name="jform[body]" rows="10" placeholder="Your Message" required></textarea>
    </div>

    <div>
      <button id="xcon-submit" type="submit" class="btn btn-primary"><?php echo JText::_('SEND');?></button>
    </div>

    <?php echo JHtml::_('form.token'); ?>

  </form>

</div>
