<?php
/**
 * @package Xpert Contact
 * @version ##VERSION##
 * @author ThemeXpert http://www.themexpert.com
 * @copyright Copyright (C) 2009 - 2011 ThemeXpert
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Load jQuery
JHtml::_('jquery.framework');
?>

<div id="xcon-<?php echo $module->id; ?>" class="xpert-contact">

  <div id="xcon-msg"></div>

  <form id="xcon-form">
      <input type="text" class="form-control" name="jform[name]" placeholder="Your Name" required />
      <input type="email" class="form-control" name="jform[email]" placeholder="Your Email" required />
      <input type="text" class="form-control" name="jform[subject]" placeholder="Your Subject" required />
      <textarea class="form-control" name="jform[body]" rows="10" placeholder="Your Message" required></textarea>
    <div>
      <?php echo $form->getInput('captcha'); ?>
    </div>
    <div>
      <button id="xcon-submit" type="submit" class="btn btn-primary"><?php echo JText::_('Send Message');?></button>
    </div>

    <input type="hidden" name="option" value="com_ajax" />
    <input type="hidden" name="module" value="xpertcontact" />
    <input type="hidden" name="format" value="raw" />
    <?php echo JHtml::_('form.token'); ?>

  </form>

</div>
