<?php
/**
 * @package		DigiCom
 * @author 		ThemeXpert http://www.themexpert.com
 * @copyright	Copyright (c) 2010-2015 ThemeXpert. All rights reserved.
 * @license 	GNU General Public License version 3 or later; see LICENSE.txt
 * @since 		1.0.0
 */

defined('_JEXEC') or die;
$configs = $this->configs;
$images  = json_decode($this->item->images);
// Legacy code
// TODO : Remove after 1.1
if(!isset($images->image_full)){
	$images = new stdClass();
	$images->image_full = $this->item->images;
}elseif(empty($images->image_full)){
	$images->image_full = $images->image_intro;
}
if($this->item->price > 0){
	$price = DigiComSiteHelperPrice::format_price($this->item->price, $configs->get('currency','USD'), true, $configs).'</span>';
}else{
	$price = '<span>'.JText::_('COM_DIGICOM_PRODUCT_PRICE_FREE').'</span>';
}
$link = JRoute::_(DigiComSiteHelperRoute::getProductRoute($this->item->id, $this->item->catid, $this->item->language));
?>

<div id="digicom" class="dc dc-product" itemscope itemtype="http://schema.org/CreativeWork">
	<article>
		<div class="row">
			<div class="col-sm-5">
				<?php if(!empty($images->image_full)): ?>
				<div class="met-box no-padding">
						<figure>
							<img itemprop="image" src="<?php echo JURI::root().$images->image_full; ?>" alt="<?php echo $this->item->name; ?>" class="dc-product-image"/>
						</figure>
				</div>
				<?php endif; ?>
			</div>
			<div class="col-sm-7">

				<div class="" itemprop="offers" itemscope itemtype="http://schema.org/Offer">

					<meta itemprop="priceCurrency" content="<?php echo $configs->get('currency','USD');?>" />

					<?php if($configs->get('enable_taxes','0') && $configs->get('display_tax_with_price','0')):?>
						<div class="dc-product-tax text-info text-center">
							<?php echo JLayoutHelper::render('tax.price', array('config' => $configs, 'item' => $this->item)); ?>
						</div>
					<?php endif; ?>

				</div>

				<header class="dc-item-head">
					<h1 class="dc-product-title">
						<span itemprop="name">
							<?php echo $this->item->name; ?>
						</span>
					</h1>
				</header>

				<?php if ($this->configs->get('show_validity',1) == 1) : ?>
					<div class="dc-product-validity text-muted text-center">
						<?php echo JText::_('COM_DIGICOM_PRODUCT_VALIDITY'); ?> : <?php echo DigiComSiteHelperPrice::getProductValidityPeriod($this->item); ?>
					</div>
				<?php endif; ?>
				<p class="dc-product-intro"><?php echo $this->item->introtext?></p>
				<div class="dc-product-details" itemprop="description">
					<?php echo $this->item->text; ?>
				</div>

				<?php
				if(!empty($this->item->bundle_source)):
					echo $this->loadTemplate('bundle');
				endif;
				?>

				<meta itemprop="price" content="<?php echo $this->item->price; ?>" />
				<?php if ($this->configs->get('catalogue',0) == '0' and !$this->item->hide_public) : ?>
					<div class="dc-addtocart-bar">
						<form name="prod" class="form" id="product-form" action="<?php echo JRoute::_('index.php?option=com_digicom&view=cart');?>" method="post" style="width:100%;">
							<div class="form-group<?php echo ($configs->get('show_quantity',0) == 1 ? " with-qnty " : ' '); ?>no-padding no-margin">

								<?php if($configs->get('show_quantity',0) == "1") {	?>
									<input data-digicom-id="quantity_<?php echo $this->item->id; ?>" type="number" name="qty" min="1" class="dc-product-qnty form-control" value="1" size="2" placeholder="<?php echo JText::_('COM_DIGICOM_QUANTITY'); ?>">
								<?php } ?>

								<?php if($configs->get('afteradditem',0) == "2") {	?>
									<div type="button" class="btn btn-primary btn-lg btn-cart" onclick="Digicom.addtoCart(<?php echo $this->item->id; ?>,'<?php echo JRoute::_("index.php?option=com_digicom&view=cart"); ?>');">
										<?php echo JText::_("COM_DIGICOM_ADD_TO_CART");?> | <?php echo $price; ?>
									</div>
								<?php }else { ?>
									<button type="submit" class="btn btn-primary btn-lg">
										<?php echo JText::_('COM_DIGICOM_ADD_TO_CART'); ?> | <?php echo $price; ?>
									</button>
								<?php } ?>
							</div>

							<input type="hidden" name="option" value="com_digicom"/>
							<input type="hidden" name="view" value="cart"/>
							<input type="hidden" name="task" value="cart.add"/>
							<input type="hidden" name="pid" value="<?php echo $this->item->id; ?>"/>
						</form>
					</div>
				<?php endif; ?>


			</div>
		</div>
	</article>


	<?php
		if($configs->get('afteradditem',0) == "2"):
			$layoutData = array(
				'selector' => 'digicomCartPopup',
				'params'   => array(
												'title' 	=> JText::_('COM_DIGICOM_CART_ITEMS'),
												'height' 	=> '400',
												'width'	 	=> '1280',
												'footer'	=> '<button type="button" class="btn btn-default" data-dismiss="modal">'.JText::_('COM_DIGICOM_CONTINUE').'</button> <a href="'.JRoute::_("index.php?option=com_digicom&view=cart").'" class="btn btn-success"><i class="ico-ok-sign"></i> '.JText::_("COM_DIGICOM_CHECKOUT").'</a>'
											),
				'body'     => ''
			);
			echo JLayoutHelper::render('bt3.modal.main', $layoutData);
		endif;
	?>

	<?php echo DigiComSiteHelperDigicom::powered_by(); ?>

</div>
