<?php
/**
 * @package		Custom use
 * @author 		Abu Huraira Bin Aman shams.bd71@gmail.com
 * @license 	GNU General Public License version 3 or later; see LICENSE.txt
 * @version 	1.0.0
 */

defined('_JEXEC') or die;
jimport('joomla.application.module.helper');

/**
* create a class with JModuleHelper
* Joomla Module Helper Class name is JModuleHelper
* dont get confused :P
*/
class JoomlaModuleHelper
{
	/**
	* @method loadModule to load single module
	* load by mod_modname, module title
	* $mod_name = string, ex: mod_login
	* $title = string, ex: Login
	* $style = string, ex: raw, html
	*/
	public static function loadModule($mod_name,$title,$style = 'raw')
	{

		$module = JModuleHelper::getModule($mod_name,$title);
		$params = array('style' => $style);
		return JModuleHelper::renderModule($module, $params);

	}

  	/**
	* @method loadModules to All modules in a position
	* load by Joomla module position
	* $position = string, ex: position-3
	* $style = string, ex: raw, html
	*/
	public static function loadModules($position, $style = 'raw')
	{

		$result = array();
		$modules = JModuleHelper::getModules($position);
		$params = array('style' => $style);
		foreach ($modules as $module) {
			$result[] = JModuleHelper::renderModule($module, $params);
		}

		return $result;

	}

	/**
	* @method loadModulesbyIDs to all modules by ids
	* load Joomla module by id or ids
	* $ids = array, ex: array(1,2)
	* $style = string, ex: raw, html
	*/
	public static function loadModulesbyIDs($ids,$style = 'raw')
	{

		if(count($ids) <= 0) return false;

		$db = JFactory::getDBo();
		$query = $db->getQuery(true);
		$query->select(array('title','module'))
			->from('#__modules')
			->where('id in (' . implode(', ',$ids) . ')');
		$db->setQuery($query);
		$modules = $db->loadObjectList();

		$params = array('style' => $style);

		$result = array();
		foreach ($modules as $module) {
			$module = JModuleHelper::getModule($module->module,$module->title);
			$result[] = JModuleHelper::renderModule($module, $params);
		}
		return $result;
	}

  	/**
	* @method loadModulesbyID to single module by id
	* load Joomla module by id=
	* $ids = intiger, ex: 22
	* $style = string, ex: raw, html
	*/
	public static function loadModulebyID($id,$style = 'raw')
	{

		$db = JFactory::getDBo();
		$query = $db->getQuery(true);
		$query->select(array('title','module'))
			->from('#__modules')
			->where('id = ' . $id );
		$db->setQuery($query);
		$module = $db->loadObject();

		$params = array('style' => $style);
		$moduleinfo = JModuleHelper::getModule($module->module,$module->title);

		return JModuleHelper::renderModule($moduleinfo, $params);

	}

	/**
	 * Loads and renders the module
	 *
	 * @param   string  $position  The position assigned to the module
	 * @param   string  $style     The style assigned to the module
	 *
	 * @return  mixed
	 *
	 * @since   1.6
	 */
	public static function loadModulebyPosition($position, $style = 'none')
	{

		$document = JFactory::getDocument();
		$renderer = $document->loadRenderer('module');
		$modules  = JModuleHelper::getModules($position);
		if(!$modules) return;
		$params   = array('style' => $style);
		ob_start();

		foreach ($modules as $module)
		{
			echo $renderer->render($module, $params);
		}

		$output = ob_get_clean();

		return $output;
	}

}
