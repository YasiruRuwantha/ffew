/**
 *------------------------------------------------------------------------------
 * @package       T3 Framework for Joomla!
 *------------------------------------------------------------------------------
 * @copyright     Copyright (C) 2004-2013 JoomlArt.com. All Rights Reserved.
 * @license       GNU General Public License version 2 or later; see LICENSE.txt
 * @authors       JoomlArt, JoomlaBamboo, (contribute to this project at github
 *                & Google group to become co-author)
 * @Google group: https://groups.google.com/forum/#!forum/t3fw
 * @Link:         http://t3-framework.org
 *------------------------------------------------------------------------------
 */
jQuery(document).ready(function (){

    //Preloader
    jQuery(window).load(function () {
        jQuery('.preloader-box').fadeOut('slow', function () {
            jQuery(this).remove();
        });
    });

    // Back to top
    jQuery('#back-to-top').on('click', function () {
        jQuery("html, body").animate({scrollTop: 0}, 500);
        return false;
    });

     jQuery('a[href="#"]').on('click', function(e){
        if(!jQuery(this).hasClass('dropdown-toggle')){
            return false;
        }
    });

 jQuery('#head-search-trigger').on('click', function(e){
   e.preventDefault();
   jQuery('.head-search > .search').toggle().toggleClass('search-open');

   if (jQuery('.head-search > .search').hasClass('search-open')){
     jQuery('#mod-search-searchword').focus();
     jQuery('#head-search-trigger i').removeClass('fa-search').addClass('fa-close');
   }else{
     jQuery('#head-search-trigger i').removeClass('fa-close').addClass('fa-search');
   }

 });
 atvImg();

 /* Demo Scripts for Bootstrap Carousel and Animate.css article
 * on SitePoint by Maria Antonietta Perna
 */
 (function( $ ) {

     //Function to animate slider captions
     function doAnimations( elems ) {
         //Cache the animationend event in a variable
         var animEndEv = 'webkitAnimationEnd animationend';

         elems.each(function () {
             var $this = $(this),
                 $animationType = $this.data('animation');
             $this.addClass($animationType).one(animEndEv, function () {
                 $this.removeClass($animationType);
             });
         });
     }

     //Variables on page load
     var $myCarousel = $('.slider-home-main-slide'),
         $firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");

     //Initialize carousel
     $myCarousel.carousel();

     //Animate captions in first slide on page load
     doAnimations($firstAnimatingElems);

     //Pause carousel
     $myCarousel.carousel('pause');


     //Other slides to be animated on carousel slide event
     $myCarousel.on('slide.bs.carousel', function (e) {
         var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
         doAnimations($animatingElems);
     });

 })(jQuery);

 new WOW().init();
});
