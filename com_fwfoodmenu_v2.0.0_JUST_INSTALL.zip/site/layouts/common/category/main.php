<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$view = $displayData['view'];

if ($css = $view->params->get('additional_css')) {
?>
<style type="text/css">
<?php echo $css; ?>
</style>
<?php
}
if ($view->params->get('show_page_heading')) {
?>
<h1><span><?php echo $view->params->get('page_heading'); ?></span></h1>
<?php
}
$view->app->triggerEvent('setExtraClasses', array('com_fwfoodmenu', $view));
?>
<div id="fwfm" class="fwcss fwfm-category-list fwfm-bootstrap <?php echo $view->params->get('extra_classes'); ?>">
	<div class="fwfm-header clearfix mb-4">
<?php
if ($view->category->description) {
	echo $view->category->description;
}
?>
	</div>
	<div class="fwfm-list row">
<?php
if ($view->list) {
	foreach ($view->list as $row) {
		$view->row = $row;
		echo fwFoodMenuHelper::loadTemplate('category.item', array('view'=>$view));
	}
}
?>
	</div>
</div>
