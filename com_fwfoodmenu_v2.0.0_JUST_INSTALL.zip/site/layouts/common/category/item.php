<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$view = $displayData['view'];

$row = $view->row;
$add_classes = 'fwfm-category-no-images';
$view->app->triggerEvent('getCategoryItemExtraClasses', array('com_fwfoodmenu', $view, &$add_classes));
?>
<div class="col-lg-4 col-sm-6 fwfm-category-wrapper <?php echo $add_classes; ?>">
	<div class="fwfm-category-item">
		<a class="fwfm-category-item-link" href="<?php echo JRoute::_('&view=menu&id='.$row->id.':'.$row->alias); ?>">
<?php
$view->app->triggerEvent('showCategoryItemHeader', array('com_fwfoodmenu', $view, $row));
?>
			<div class="fwfm-category-description">
				<div class="fwfm-category-description-title"><?php echo $row->name; ?></div>
<?php
		if ($row->short_description) {
?>
				<div class="fwfm-category-description-text">
					<?php echo $row->short_description; ?>
				</div>
<?php
		}
?>
				<span class="btn" href="">
					<?php echo JText::_('FWFM_VIEW_MENU'); ?>
				</span>
				<div class="fwfm-category-meals">
					<?php echo fwFoodMenuHelper::countMealsQty($row->id); ?> <?php echo JText::_('FWFM_MEALS'); ?>
				</div>
			</div>
		</a>
	</div>
</div>
