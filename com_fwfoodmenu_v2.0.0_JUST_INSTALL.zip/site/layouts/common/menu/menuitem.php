<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$view = $displayData['view'];

$row = $view->row;

$additional_classes = ' fwfm-menu-item-'.$row->category_id;
$view->app->triggerEvent('collectMenuStatus', array('com_fwfoodmenu', $view, $row, &$additional_classes));

$price_block = '';
$view->app->triggerEvent('getMenuPriceBlock', array('com_fwfoodmenu', $view, $row, &$price_block));

?>
<div class="fwfm-menu-item <?php echo $additional_classes; ?>">
	<a name="<?php echo $view->escape(urlencode($row->name)); ?>"></a>
<?php
$view->app->triggerEvent('showMenuItemHeader', array('com_fwfoodmenu', $view, $row));
?>
	<div class="fwfm-menu-item-text">
<?php
$view->app->triggerEvent('showMenuPromoTopBadges', array('com_fwfoodmenu', $view, $row));
?>
		<div class="fwfm-menu-item-title">
			<span><?php echo $row->name; ?></span>
<?php
$view->app->triggerEvent('showMenuPromoHeaderIcons', array('com_fwfoodmenu', $view, $row));
?>

			<div class="fwfm-menu-item-price">
<?php
if ($price_block) {
	echo $price_block;
} elseif (!empty($row->_prices[0]->price)) {
	echo fwFoodMenuHelper::formatPrice($row->_prices[0]->price);
}
?>
			</div>
		</div>
<?php
$view->app->triggerEvent('showMenuPromoBlock', array('com_fwfoodmenu', $view, $row));
?>
		<div class="fwfm-menu-item-description">
			<?php echo $row->description; ?>
		</div>
<?php
$view->app->triggerEvent('showMenuPromoBottom', array('com_fwfoodmenu', $view, $row));
?>
	</div>
</div>
