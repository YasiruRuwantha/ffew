<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$view = $displayData['view'];

$row = $view->row;
?>
<a name="<?php echo $row->alias; ?>"></a>
<div class="fwfm-subcategory-item fwfm-menu-item-<?php echo $row->id; ?>" id="fwfm-category-<?php echo $row->id; ?>">
	<div class="fwfm-category-title fwfm-level-<?php echo $row->level; ?>"><span><?php echo $row->name; ?></span></div>
<?php
if (!empty($row->description)) {
?>
		<div class="fwfm-subcategory-text"><?php echo $row->description; ?></div>
<?php
}
?>
</div>
