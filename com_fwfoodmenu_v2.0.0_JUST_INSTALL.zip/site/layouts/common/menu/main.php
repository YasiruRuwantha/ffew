<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$view = $displayData['view'];

if ($css = $view->params->get('additional_css')) {
?>
<style type="text/css">
<?php echo $css; ?>
</style>
<?php
}
if ($view->params->get('show_page_heading')) {
?>
<h1><span><?php echo $view->params->get('page_heading'); ?></span></h1>
<?php
}
$view->app->triggerEvent('setExtraClasses', array('com_fwfoodmenu', $view));
?>
<div id="fwfm" class="fwcss fwfm-bootstrap <?php echo $view->params->get('extra_classes'); ?>">
	<!-- Food Menu extension area -->
<?php
$view->app->triggerEvent('showMenuTopInfo', array('com_fwfoodmenu', $view));
?>
	<!-- Menu list -->
	<div class="fwfm-list">
<?php
$view->app->triggerEvent('showMenuListTopInfo', array('com_fwfoodmenu', $view));

if ($view->list) {
	$prev_params = $view->params;
	foreach ($view->list as $cat) {
		if (!$cat->published or !count($cat->_items)) {
			continue;
		}
		$qty = count($cat->_items);

		$view->params = new JFParams($cat->params, fwFoodMenuHelper::getParentCategories($cat->parent));

		$view->app->triggerEvent('setCategoryExtraClasses', array('com_fwfoodmenu', $view, $cat));
		$extra_classes = $view->params->get('extra_category_classes');

		$align_by = $view->params->get('align_by', 'meal');
		$cols_qty = $col_qty = $view->params->get('col_qty', 1);
		$desc_pos = $view->params->get('category_descr_position', 'top');
		$bs_col = 12/$cols_qty;

		/* count menu items, skip subcategories */
		$qty = 0;
		foreach ($cat->_items as $item) {
			if (empty($item->type)) $qty++;
		}

		if ($extra_classes) {
?>
		<div class="<?php echo $extra_classes; ?>">
<?php
		}
?>
		<div id="fwfm-category-<?php echo $cat->id; ?>" class="fwfm-category">
			<div id="fwfm-category-title-<?php echo $cat->id; ?>"></div>
<?php
		if ($view->params->get('display_category_title', 1)) {
?>
			<div class="fwfm-category-title">
				<a name="<?php echo $cat->alias; ?>"></a>
				<span><?php echo $cat->name; ?></span>
<?php
				$view->app->triggerEvent('showCategoryPDFLink', array('com_fwfoodmenu', $view, $cat));
?>
			</div>
<?php
		}
?>
			<div class="fwfm-category-body-wrapper fwfm-category-body-<?php echo $desc_pos; ?>">
<?php
		if (count(trim(strip_tags($cat->description)))) {
?>
				<div class="fwfm-category-body">
					<div class="fwfm-category-description"><?php echo $cat->description; ?></div>
				</div>
<?php
		}
?>
				<div class="fwfm-category-menu">
					<div class="row">
						<div class="col-md-<?php echo $bs_col; ?>">
<?php
		$num = 0;
		$cols_displayed = 1;

		$items_per_column = max(1, round($qty/$col_qty));
		$shift = max(0, $qty - $items_per_column * $col_qty);

		foreach ($cat->_items as $row) {
			$view->row = $row;
			if (isset($row->type)) {
				if ($align_by == 'category' and $num > 0) {
?>
						</div>
						<div class="col-md-<?php echo $bs_col; ?>">
<?php
				}
				$view->params = new JFParams($row->params, fwFoodMenuHelper::getParentCategories($row->parent));
				$view->app->triggerEvent('setCategoryExtraClasses', array('com_fwfoodmenu', $view, $row));
				echo fwFoodMenuHelper::loadTemplate('menu.subcategoryitem', array('view'=>$view));
			} else {
				echo fwFoodMenuHelper::loadTemplate('menu.menuitem', array('view'=>$view));
				$num++;

				if ($align_by == 'meal' and ($num - $shift) and (($num - $shift) % $items_per_column) == 0 and $cols_displayed < $col_qty) {
					$cols_displayed++;
?>
						</div>
						<div class="col-md-<?php echo $bs_col; ?>">
<?php
				}
			}
		}
?>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php
		if ($extra_classes) {
?>
		</div>
<?php
		}

	}
	$view->params = $prev_params;
}
?>
	</div>
</div>
<?php
$view->app->triggerEvent('showGoogleData', array('com_fwfoodmenu', $view));
