<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

function fwFoodMenuBuildRoute(&$query) {
    $segments = array();

    if (!empty($query['Itemid'])) {
        $menu = JMenu::getInstance('site');
        $item = $menu->getItems('id', $query['Itemid'], true);
        if ($item) {
		 	if (!empty($query['view'])) {
				if ($query['view'] == $item->query['view']) {
					unset($query['view']);
				}
			}
		}
	}

	return $segments;
}
function fwFoodMenuParseRoute($segments) {
    $vars = array();

	return $vars;
}
