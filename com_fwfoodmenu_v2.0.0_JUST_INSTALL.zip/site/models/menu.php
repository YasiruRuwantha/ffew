<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class MenuModelMenu extends JModelLegacy {
	function loadCategory($params = null) {
		$app = JFactory::getApplication();
		if (is_null($params)) {
			$params = $app->getParams();
			if ($id = $app->input->getInt('id')) {
				$params->set('category_id', array($id));
			}
		}
		$category = $this->getTable('category');
		$ids = $params->get('category_id');
		if (is_array($ids) and count($ids) == 1 and $cid = (int)$ids[0]) {
			$category->load($cid);
		}
		return $category;
	}
	function loadList($params = null) {
		$db = JFactory::getDBO();
		$app = JFactory::getApplication();
		if (is_null($params)) {
			$params = $app->getParams();
			if ($id = $app->input->getInt('id')) {
				$params->set('category_id', array($id));
			}
		}

		$where = array(
			'm.published = 1',
			'c.published = 1'
		);

		$cids = (array)$params->get('category_id');
		$cats = array();
		$tree = fwFoodMenuHelper::loadCategoriesTree($cids);
		if ($tree) {
			foreach ($tree as $row) {
				$row->_items = array();
				$cats[] = $row;
			}
		}

		if ($cids) {
			JArrayHelper::toInteger($cids, 0);
			if (!in_array(0, $cids)) {
				$where[] = 'm.category_id IN ('.implode(',', fwFoodMenuHelper::getCategoriesIdBelow($cats, $cids)).')';
			}
		}

		$app->triggerEvent('collectMenuListWhere', array('com_fwfoodmenu', $params, &$where));
        $extras = $app->triggerEvent('getMenuListExtraFields', array('com_fwfoodmenu'));

		$db->setQuery('
SELECT
    m.*,
	c.parent,
	c.name AS _category_name,
	c.alias AS _category_alias,
	c.description AS _category_descr,
	\'\' AS _prices
    '.implode('', $extras).'
FROM
    #__fwfoodmenu_menu AS m
    LEFT JOIN #__fwfoodmenu_category AS c ON m.category_id = c.id
WHERE
	'.implode(' AND ', $where).'
ORDER BY
	c.parent,
	c.ordering,
	c.name,
	m.ordering'
		);
		if ($list = $db->loadObjectList()) {
			$ids = array();
			foreach ($list as $i=>$row) {
				$ids[] = $row->id;
				$list[$i]->_prices = array();
			}
			$db = JFactory::getDBO();
			$db->setQuery('SELECT * FROM `#__fwfoodmenu_menu_price` WHERE menu_id IN ('.implode(',', $ids).') ORDER BY ordering');
			if ($buff = $db->loadObjectList()) {
				foreach ($buff as $row) {
					$key = array_search($row->menu_id, $ids);
					$list[$key]->_prices[] = $row;
				}
			}
			$app->triggerEvent('calculateMenuListExtraFields', array('com_fwfoodmenu', &$list));
			$buff = $this->fillCategories($tree, $list);
			foreach ($buff as $i=>$row) {
				$cats[$i]->_items = fwFoodMenuHelper::straightenTree($row);
			}
		}
		return $cats;
	}

	function fillCategories($cats, $list) {
		foreach ($cats as $i=>$cat) {
			$cats[$i]->_items = array();
			foreach ($list as $row) {
				if ($row->category_id == $cat->id) {
					$cats[$i]->_items[] = $row;
				}
			}
			if (!empty($cat->_children)) {
				$cats[$i]->_children = $this->fillCategories($cats[$i]->_children, $list);
			}
		}
		return $cats;
	}
}
