<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class MenuModelCategory extends JModelLegacy {
	function loadCategory($params = null) {
		if (is_null($params)) {
			$params = JFactory::getApplication()->getParams();
		}
		$category = $this->getTable('category');
		$ids = (array)$params->get('category_id');
		if (count($ids) == 1) {
			$category->load($ids[0]);
		}
		return $category;
	}
	function loadList($params = null) {
		$db = JFactory::getDBO();
		if (is_null($params)) {
			$params = JFactory::getApplication()->getParams();
		}

		$where = array(
			'c.published = 1',
			'c.id IN ('.implode(',', (array)$params->get('category_id', 0)).')'
		);

		$db->setQuery('
SELECT
    c.*,
	\'\' AS _images,
	\'\' AS _cids
FROM
    #__fwfoodmenu_category AS c
WHERE
	'.implode(' AND ', $where).'
ORDER BY
	c.ordering,
	c.name'
		);
		if ($list = $db->loadObjectList()) {
			$ids = array();
			foreach ($list as $i=>$row) {
				$list[$i]->_images = array();
				$list[$i]->params = new JRegistry($row->params);

				$cats = fwFoodMenuHelper::loadCategoriesTree(array($row->id));
				$list[$i]->_cids = fwFoodMenuHelper::getCategoriesIdBelow($cats, array($row->id));
				$ids = array_merge($ids, $list[$i]->_cids);
			}

			$db->setQuery('SELECT `image`, name, category_id FROM `#__fwfoodmenu_menu` WHERE published = 1 AND category_id IN ('.implode(',', $ids).') ORDER BY ordering');
			if ($buff = $db->loadObjectList()) {
				foreach ($buff as $row) {
					foreach ($list as $key=>$cat) {
						if (in_array($row->category_id, $cat->_cids)) {
							$list[$key]->_images[] = $row;
							break;
						}
					}
				}
			}
		}
		return $list;
	}
}
