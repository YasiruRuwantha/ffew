<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldFwAddons extends JFormField {
	var	$type = 'fwaddons';

	function getInput() {
		$path = JPATH_SITE.'/components/com_fwfoodmenu/helpers/helper.php';
		if (!file_exists($path)) return;
		require_once($path);
		
		if (!is_array($this->value)) {
			$this->value = array();
		}

		ob_start();
		if ($list = fwFoodMenuHelper::loadPlugins() and !empty($list['fwfoodmenu'])) {
			$name = str_replace(array('[', ']'), array('_', ''), $this->name);
			foreach ($list['fwfoodmenu'] as $row) {
				JFactory::getLanguage()->load('plg_fwfoodmenu_'.$row->element);
				$id = $name.$row->element;
				if (!isset($this->value[$row->element])) {
					$this->value[$row->element] = 1;
				}
?>
<div class="control-group">
	<div class="control-label">
		<?php echo JText::_('FW_FOODMENU_'.$row->element); ?>
	</div>
	<div class="controls">
		<fieldset id="jform_<?php echo $id; ?>" class="btn-group radio">
			<input type="radio" id="jform_<?php echo $id; ?>0" name="<?php echo $this->name; ?>[<?php echo $row->element ?>]" value="0"<?php if (empty($this->value[$row->element])) { ?> checked="checked"<?php } ?>>
			<label for="jform_<?php echo $id; ?>0" class="btn<?php if (empty($this->value[$row->element])) { ?> active btn-danger<?php } ?>">
				<?php echo JText::_('JNO'); ?>
			</label>
			<input type="radio" id="jform_<?php echo $id; ?>1" name="<?php echo $this->name; ?>[<?php echo $row->element ?>]" value="1"<?php if (!empty($this->value[$row->element])) { ?> checked="checked"<?php } ?>>
			<label for="jform_<?php echo $id; ?>1" class="btn<?php if (!empty($this->value[$row->element])) { ?> active btn-success<?php } ?>">
				<?php echo JText::_('JYES'); ?>
			</label>
		</fieldset>
	</div>
</div>
<?php
			}
		}
		return ob_get_clean();
	}
}
