<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldFwFmColsQty extends JFormField {
	var	$type = 'fwfmcolsqty';

	function getInput() {
		$path = JPATH_SITE.'/components/com_fwfoodmenu/helpers/helper.php';
		if (!file_exists($path)) return;
		require_once($path);
		
		$qty = array();
		JFactory::getApplication()->triggerEvent('getFoodMenuColsQty', array('com_fwfoodmenu', &$qty));

		ob_start();
		if ($qty) {
			$name = str_replace(array('[', ']'), array('_', ''), $this->name);
?>
		<fieldset id="jform_<?php echo $name; ?>" class="btn-group radio">
<?php
			foreach ($qty as $i=>$col) {
				$id = $name.$col;
				$active = ($this->value == $col or (!$this->value and !$i));
?>
			<input type="radio" id="jform_<?php echo $id; ?>" name="<?php echo $this->name; ?>" value="<?php echo $col; ?>"<?php if ($active) { ?> checked="checked"<?php } ?>>
			<label for="jform_<?php echo $id; ?>" class="btn<?php if ($active) { ?> active btn-success<?php } ?>">
				<?php echo $col; ?>
			</label>
<?php
			}
?>
		</fieldset>
<?php
		} else {
?>
<div id="fwfmcolsqty"></div>
<script>
jQuery(function($) {
	$('#fwfmcolsqty').closest('.control-group').hide();
});
</script>
<?php
		}
		return ob_get_clean();
	}
}