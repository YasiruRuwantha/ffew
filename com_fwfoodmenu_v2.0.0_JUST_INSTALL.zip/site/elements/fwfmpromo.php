<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldFwFmPromo extends JFormField {
	var	$type = 'fwfmpromo';

	function getInput() {
		$path = JPATH_SITE.'/components/com_fwfoodmenu/helpers/helper.php';
		if (!file_exists($path)) return;
		require_once($path);

		$options = array();
		JFactory::getApplication()->triggerEvent('getFoodMenuPromoOptions', array('com_fwfoodmenu', &$options));

		ob_start();
		if ($options) {
//			$name = str_replace(array('[', ']'), array('_', ''), $this->name);
			echo JHTML::_('select.genericlist', $options, $this->name, 'class="form-control"', 'id', 'name', $this->value);
		} else {
?>
<div id="fwfmpromo"></div>
<script>
jQuery(function($) {
	$('#fwfmpromo').closest('.control-group').hide();
});
</script>
<?php
		}
		return ob_get_clean();
	}
}