<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldFwFmLayout extends JFormField {
	var	$type = 'fwfmlayout';

	function getInput() {
		$path = JPATH_SITE.'/components/com_fwfoodmenu/helpers/helper.php';
		if (!file_exists($path)) return;
		require_once($path);
		
		$layouts = array();
		JFactory::getApplication()->triggerEvent('getFoodMenuLayouts', array('com_fwfoodmenu', &$layouts));

		ob_start();
		if ($layouts) {
			$name = str_replace(array('[', ']'), array('_', ''), $this->name);
?>
		<fieldset id="jform_<?php echo $name; ?>" class="btn-group radio">
<?php
			foreach ($layouts as $i=>$layout) {
				$id = $name.$layout;
				$active = ($this->value == $layout or (!$this->value and !$i));
?>
			<input type="radio" id="jform_<?php echo $id; ?>" name="<?php echo $this->name; ?>" value="<?php echo $layout; ?>"<?php if ($active) { ?> checked="checked"<?php } ?>>
			<label for="jform_<?php echo $id; ?>" class="btn<?php if ($active) { ?> active btn-success<?php } ?>">
				<?php echo JText::_('FWFM_LAYOUT_'.$layout); ?>
			</label>
<?php
			}
?>
		</fieldset>
<?php
		} else {
?>
<div id="fwfmlayout"></div>
<script>
jQuery(function($) {
	$('#fwfmlayout').closest('.control-group').hide();
});
</script>
<?php
		}
		return ob_get_clean();
	}
}