<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

class JFormFieldFoodCats extends JFormFieldList {
	protected $type = 'foodcats';
	function getInput() {
		require_once(JPATH_SITE.'/components/com_fwfoodmenu/helpers/helper.php');
		JHTML::addIncludePath(JPATH_SITE.'/administrator/components/com_fwfoodmenu/helpers');
		$multiple = (bool) $this->element['multiple'];
		return JHTML::_('fwfCategory.getCategories', $this->name, $this->value, '', $multiple);
	}
}
