<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

define('FWA_UPDATE_NAME', 'com_fwfoodmenu');
define('FWA_UPDATE_SERVER', 'https://fastw3b.net');

JPluginHelper::importPlugin('fwfoodmenu');
JPluginHelper::importPlugin('fwfoodmenutmpl');
JPluginHelper::importPlugin('fwfoodmenutype');

if (!class_exists('JFParams')) {
	class JFParams {
		var $params = null;
		var $parent_categories = null;
		function __construct($params, $parent_categories=null) {
			$this->params = clone($params);
			if ($parent_categories) {
				$this->parent_categories = $parent_categories;
			}
		}
		function set($key, $val) {
			$this->params->set($key, $val);
		}
		function get($key, $def=null) {
			$val = $this->params->get($key, 'def');
			if ($val == 'def') {
				if ($this->parent_categories) {
					foreach ($this->parent_categories as $category) {
						$val = $category->params->get($key, 'def');
						if ($val != 'def') {
							return $val;
						}
					}
				}
				$app = JFactory::getApplication();
				if ($app->isSite() and $app->input->getCmd('option') == 'com_fwfoodmenu') {
					$val = $app->getParams()->get($key, $def);
					if ($val == 'def') {
						$val = JComponentHelper::getParams('com_fwfoodmenu')->get($key, $def);
					}
				} else {
					$val = JComponentHelper::getParams('com_fwfoodmenu')->get($key, $def);
				}
			}
			return $val;
		}
	}
}

class fwFoodMenuHelper {
	static function getCategoryParams($cid) {
		static $data = array();
		if (!isset($data[$cid])) {
			$cats = fwFoodMenuHelper::loadCategories();
			$params = null;
			if ($cid) {
				foreach ($cats as $cat) {
					if ($cat->id == $cid) {
						$data[$cid] = new JFParams($cat->params, fwFoodMenuHelper::getParentCategories($cat->parent));
						break;
					}
				}
			}
			if (!isset($data[$cid])) {
				$data[$cid] = new JFParams(new JRegistry);
			}
		}
		return $data[$cid];
	}
	static function getParentCategories($id) {
		$galleries = fwFoodMenuHelper::loadCategories();
		$data = array();
		if ($id) {
			foreach ($galleries as $gallery) {
				if ($gallery->id == $id) {
					$data[$gallery->parent] = $gallery;
				}
			}
			do {
				$found = false;
				$ids = array_keys($data);
				foreach ($galleries as $gallery) {
					if (!isset($ids[$gallery->parent]) and in_array($gallery->id, $ids)) {
						$ids[$gallery->parent] = $gallery;
						$found = true;
					}
				}
			} while($found);
		}
		return $data;
	}
	static function getInstalledLanguages() {
		static $languages;
		if (!is_array($languages)) {
			$buff = JLanguage::getKnownLanguages(JPATH_BASE);
			foreach ($buff as $row) {
				$code = substr($row['tag'], 0, 2);
				$lang = new stdclass;
				$lang->id = $code;
				$lang->tag = $row['tag'];
				$lang->name = $row['name'];
				$languages[$code] = $lang;
			}
		}
		return $languages;
	}
	static function getLanguage() {
		static $lang_name = null;
		if (!$lang_name) {
			$app = JFactory::getApplication();
			$lang = JFactory::getLanguage();
			$lang_name = strtolower(substr($app->getUserStateFromRequest('com_fwfoodmenu.language', 'lang', $lang->getTag()), 0, 2));
			if (!$lang_name or ($lang_name and !in_array($lang_name, array_keys(fwFoodMenuHelper::getInstalledLanguages())))) {
				$db = JFactory::getDBO();
				$db->setQuery('SELECT `sef` FROM #__languages WHERE `published` = 1 AND `ordering` = 1');
				$lang_name = $db->loadResult();
				if (!$lang_name) $lang_name = 'en';
			}
		}
		return $lang_name;
	}
	static function storeConfig($params) {
		$cache = JFactory::getCache('_system', 'callback');
    	$cache->clean();

    	$db = JFactory::getDBO();
    	$db->setQuery('UPDATE #__extensions SET params = '.$db->quote($params->toString()).' WHERE `element` = \'com_fwfoodmenu\' AND `type` = \'component\'');
    	return $db->query();
	}
    static function loadPlugins() {
        static $plugins;
        if (!is_array($plugins)) {
			$plugins = array();

            $db = JFactory::getDBO();
            $db->setQuery('
SELECT
    `element`,
    `enabled`,
	`folder`
FROM
    #__extensions
WHERE
    `type` = \'plugin\'
    AND
    `folder` IN (\'fwfoodmenu\', \'fwfoodmenutmpl\')');
            if ($data = $db->loadObjectList()) {
				foreach ($data as $row) {
					if (!isset($plugins[$row->folder])) {
						$plugins[$row->folder] = array();
					}
					$plugins[$row->folder][$row->element] = $row;
				}
			}
        }
        return $plugins;
    }
    static function pluginInstalled($name, $type = 'fwfoodmenu') {
        $plugins = fwFoodMenuHelper::loadPlugins();
        return isset($plugins[$type][$name]);
    }
    static function pluginEnabled($name, $type = 'fwfoodmenu') {
        $plugins = fwFoodMenuHelper::loadPlugins();
        if (!empty($plugins[$type][$name])) {
            return $plugins[$type][$name]->enabled;
        }
    }
	static function pluginDisabledViaMenu($plugin) {
		$params = JFactory::getApplication()->getParams();
		$disabled_addons = $params->get('plugins', array($plugin=>1));
		return empty($disabled_addons[$plugin]);
	}
	static function getThemesList() {
		$themes = array(
			JHTML::_('select.option', 'common', JText::_('FWFM_THEME_DEFAULT'), 'id', 'name')
		);
		$db = JFactory::getDBO();
		$db->setQuery("SELECT name, `element` FROM #__extensions WHERE `type` = 'plugin' AND `folder` = 'fwfoodmenutmpl' AND `enabled` = 1");
		if ($list = $db->loadObjectList()) {
			$lang = JFactory::getLanguage();
			foreach ($list as $row) {
				$lang->load('plg_fwfoodmenutmpl_'.$row->element);
				$themes[] = JHTML::_('select.option', $row->element, JText::_($row->name), 'id', 'name');
			}
		}
		return $themes;
	}
    static function loadTemplate($view, $displayData, $path=null) {
        $app = JFactory::getApplication();

        $tmpl = '';
		$com_path = JPATH_SITE.'/components/com_fwfoodmenu/layouts/';
		if (is_null($path)) {
			$path = JPATH_SITE.'/plugins/fwfoodmenutmpl/';
			$tmpl = $app->input->getCmd('t', $displayData['view']->params->get('template'));

			if (!$tmpl or ($tmpl and !is_dir($path.$tmpl))) {
				$tmpl = 'common';
				$path = $com_path;
			}
			if (!defined('FWFM_STYLES_LOADED')) {
				define('FWFM_STYLES_LOADED', true);
				$com_params = JComponentHelper::getParams('com_fwfoodmenu');
				if (!$com_params->get('do_not_load_bootstrap')) {
					JHTML::stylesheet('components/com_fwfoodmenu/assets/css/bootstrap.css', array('version'=>'v=100'));
					JHTML::_('jquery.framework');
/*					JHTML::script('components/com_fwfoodmenu/assets/js/tether.min.js');
					JHTML::script('components/com_fwfoodmenu/assets/js/popper.js');
					JHTML::script('components/com_fwfoodmenu/assets/js/bootstrap.min.js');*/	
				}
				if (!$com_params->get('do_not_load_awesome')) {
					JHTML::stylesheet('components/com_fwfoodmenu/assets/css/all.min.css');
				}
				JHTML::stylesheet('components/com_fwfoodmenu/assets/css/fwfm-design-styles.css', array('version'=>'v=100'));
				if ($buff = $app->getParams()->get('additional_css')) {
					JFactory::getDocument()->addStyleDeclaration($buff);
				}
			}
			if (file_exists($path.$tmpl.'/assets/css/fwfm-design-styles.css')) {
				JHTML::stylesheet('plugins/fwfoodmenutmpl/'.$tmpl.'/assets/css/fwfm-design-styles.css');
			}
		}

        $buff = explode('.', $view);
        $filename = array_pop($buff).'.php';
        $view_path = implode('/', $buff);

        $full_path = $path.$tmpl.'/'.$view_path.'/'.$filename;
        $tmpl_found = file_exists($full_path);
        if (!$tmpl_found and $tmpl != 'common') {
            $full_path = $com_path.'common/'.$view_path.'/'.$filename;
            $tmpl_found = file_exists($full_path);
        }
        if ($tmpl_found) {
            ob_start();
            include($full_path);
            return ob_get_clean();
        } else {
            return 'template '.$tmpl.', view '.$view.' not found';
        }
    }
	static function fixDescriptionImagesLinks($text) {
		if (preg_match_all('#(src\=")(images/)#', $text, $matches, PREG_SET_ORDER)) {
			$base = JURI::root(true).'/';
			foreach ($matches as $match) {
				$text = str_replace($match[0], $match[1].$base.$match[2], $text);
			}
		}
		return $text;
	}
	static function escape($text) {
		return str_replace('"', '&quot;', $text);
	}
	static function straightenTree($cat, $level = 1) {
		$result = array();

		$header_added = false;

		if (!empty($cat->_children)) {
			foreach ($cat->_children as $child) {
				if (!$child->published) {
					continue;
				}
				if ($buff = fwFoodMenuHelper::straightenTree($child, $level + 1)) {
					if (!$header_added and $level > 1) {
						$header_added = true;
						$result[] = (object)array(
							'id' => $cat->id,
							'parent' => $cat->parent,
							'type' => 'category',
							'level' => min($level, 4),
							'name' => $cat->name,
							'alias' => $cat->alias,
							'pdf_menu' => $cat->pdf_menu,
							'published' => $cat->published,
							'description' => $cat->description,
							'params' => $cat->params
						);
					}
					$result = array_merge($result, $buff);
				}
			}
		}

		if (!empty($cat->_items)) {
			if (!$header_added and $level > 1) {
				$result[] = (object)array(
					'id' => $cat->id,
					'parent' => $cat->parent,
					'type' => 'category',
					'level' => min($level, 4),
					'name' => $cat->name,
					'alias' => $cat->alias,
					'pdf_menu' => $cat->pdf_menu,
					'published' => $cat->published,
					'description' => $cat->description,
					'params' => $cat->params
				);
			}
			foreach ($cat->_items as $item) {
				$result[] = $item;
			}
		}
		return $result;
	}
	static function loadCategoriesTree($sel_cats) {
		static $cats;
		if (!is_array($cats)) {
			$items = fwFoodMenuHelper::loadCategories();
			$children = array();
		    foreach($items as $i=>$item) {
				$items[$i]->params = new JRegistry($item->params);
		        $children[$item->parent][] = $item;
			}
		    foreach($items as $item) {
				if (isset($children[$item->id])) {
					$item->_children = $children[$item->id];
				}
			}
		    $cats = $children[0];
		}
		if ($sel_cats and !in_array(0, $sel_cats)) {
			return fwFoodMenuHelper::getSelectedCategories($cats, $sel_cats);
		} else {
			return $cats;
		}
	}
	static function getCategoriesIdBelow($cats, $ids) {
		foreach ($cats as $cat) {
			if (!in_array($cat->id, $ids)) {
				$ids[] = $cat->id;
			}
			if (!empty($cat->_children) and $buff = fwFoodMenuHelper::getCategoriesIdBelow($cat->_children, array())) {
				$ids = array_merge($ids, $buff);
			}
		}
		return $ids;
	}
	static function getSelectedCategories($cats, $sel_cats) {
		$data = array();
		if ($cats) {
			foreach ($cats as $cat) {
				if (in_array($cat->id, $sel_cats)) {
					$data[] = $cat;
				} elseif (!empty($cat->_children) and $buff = fwFoodMenuHelper::getSelectedCategories($cat->_children, $sel_cats)) {
					$data = array_merge($data, $buff);
				}
			}
		}
		return $data;
	}
	static function loadCategories() {
		static $cats;
		if (!is_array($cats)) {
			$db = JFactory::getDBO();
			$db->setQuery('
SELECT
    c.*,
	(SELECT COUNT(*) FROM #__fwfoodmenu_category AS cc WHERE cc.parent = c.id) AS _cats_qty,
	(SELECT COUNT(*) FROM #__fwfoodmenu_menu AS m WHERE m.category_id = c.id) AS _menu_qty
FROM
    #__fwfoodmenu_category AS c
ORDER BY
	`parent`,
	ordering');
			$cats = $db->loadObjectList('id');
		}
		return $cats;
	}
	static function countMealsQty($cid) {
		$cats = fwFoodMenuHelper::loadCategories();
		$qty = isset($cats[$cid])?$cats[$cid]->_menu_qty:0;
		foreach ($cats as $cat) {
			if ($cat->parent == $cid) {
				$qty += fwFoodMenuHelper::countMealsQty($cat->id);
			}
		}
		return $qty;
	}
	static function checkPrevCategory($c) {
		$items = fwFoodMenuHelper::loadCategories();
		$cats = array();
		foreach ($items as $item) {
			if ($item->parent == $c->parent) {
				$cats[$item->id] = $item;
			}
		}

		$prev_id = 0;
		foreach ($cats as $cat) {
			if ($cat->id == $c->id) {
				return !(!$prev_id or ($prev_id and $cats[$prev_id]->parent != $cat->parent));
			}
			$prev_id = $cat->id;
		}
	}
	static function checkNextCategory($c) {
		$items = fwFoodMenuHelper::loadCategories();
		$cats = array();
		foreach ($items as $item) {
			if ($item->parent == $c->parent) {
				$cats[$item->id] = $item;
			}
		}

		$ids = array_keys($cats);
		$next_id = 0;
		for ($i = count($ids) - 1; $i >= 0; $i--) {
			if ($cats[$ids[$i]]->id == $c->id) {
				return !(!$next_id or ($next_id and $cats[$next_id]->parent != $cats[$ids[$i]]->parent));
			}
			$next_id = $cats[$ids[$i]]->id;
		}
	}
	static function findUnicFilename($path, $ext) {
		$filename = '';
		do {
			$filename = md5(microtime().rand()).'.'.$ext;
		} while(file_exists($path.$filename));
		return $filename;
	}
	static function humanFileSize($val) {
		if ($val > 1073741824) return round($val / 1073741824, 2).' Gb';
		if ($val > 1048576) return round($val / 1048576, 2).' Mb';
		elseif ($val > 1024) return round($val / 1024, 2).' Kb';
		elseif ($val and is_numeric($val)) return $val.' b';
		else return $val;
	}
	static function getIniSize($name) {
		$val = ini_get($name);
		if (preg_match('/^(\d+)([MK])$/', $val, $matches)) {
			if ($matches[2] == 'M') $val = $matches[1] * 1024 * 1024;
			elseif ($matches[2] == 'K') $val = $matches[1] * 1024;
		}
		return $val;
	}
	static function formatPrice($price) {
		if (!$price or !is_numeric($price)) return $price;
		$params = JComponentHelper::getParams('com_fwfoodmenu');
		$currency = $params->get('currency');
		if (!$currency) return number_format($price, 2);
		if ($params->get('currency_after')) {
			return rtrim(rtrim(number_format($price, 2), '0'), '.,').' '.$currency;
		} else {
			return $currency.rtrim(rtrim(number_format($price, 2), '0'), '.,');
		}
	}
	static function checkMenuImage($menu) {
		return ($menu->image and file_exists(JPATH_SITE.'/media/com_fwfoodmenu/menu/'.$menu->image));
	}
	static function getMenuImageUrl($menu, $direct_link=false) {
		if (fwFoodMenuHelper::checkMenuImage($menu)) {
			return ($direct_link?JURI::root(false):(JURI::root(true).'/')).'media/com_fwfoodmenu/menu/'.$menu->image;
		}
		return 'data:image/svg+xml;charset=UTF-8,%3C%3Fxml-stylesheet%20rel%3D%22stylesheet%22%20href%3D%22http%3A%2F%2Fnetdna.bootstrapcdn.com%2Ffont-awesome%2F4.1.0%2Fcss%2Ffont-awesome.min.css%22%3F%3E%0A%3C%3Fxml-stylesheet%20rel%3D%22stylesheet%22%20href%3D%22http%3A%2F%2Ffonts.googleapis.com%2Fcss%3Ffamily%3DPacifico%22%3F%3E%3Csvg%20width%3D%22400%22%20height%3D%22400%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20400%20400%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_1690f886afe%20text%20%7B%20fill%3A%23AAAAAA%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A20pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_1690f886afe%22%3E%3Crect%20width%3D%22400%22%20height%3D%22400%22%20fill%3D%22%23EEEEEE%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22148.0234375%22%20y%3D%22209%22%3E400x400%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E';
	}
	static function getItemid($view='menu', $id=null) {
		$menu = JMenu::getInstance('site');
		$item = null;
		if ($items = $menu->getItems('link', 'index.php?option=com_fwfoodmenu&view='.$view)) {
			if (!is_null($id)) {
				foreach ($items as $menuItem) {
					if (in_array($id, (array)$menuItem->params->get('category_id'))) {
						$item = $menuItem;
						break;
					}
				}
			}
			if (!$item) $item = $items[0];
		}

		if ($item) return $item->id;
	}
	static function request($url, $method='get', $data=null) {
		if (function_exists('curl_init')) {
			if ($method) {
				$method = strtolower($method);
				if (!in_array($method, array('get','post'))) {
					$method = 'get';
				}
			}

			$ch = curl_init();
			if ($data) {
				if ($method == 'post') {
					curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
				} elseif ($method == 'get') {
					$buff = http_build_query($data);
					$url .= (strpos($url, '?')===false?'?':'&').$buff;
				}
			}
			if ($method == 'post') {
				curl_setopt($ch, CURLOPT_POST, true);
			}
			if (stripos($url, 'https') === 0) {
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			}
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			$result = curl_exec ($ch);
			curl_close($ch);
			return $result;
		} elseif (function_exists('file_get_contents')) {
			return file_get_contents($url);
		}
	}
	static function getCategoryAlias($id, $name) {
		$name = JFilterOutput::stringURLSafe($name);
		if (!$name) return '';
		$db = JFactory::getDBO();
		$index = 0;
		$alias = '';
		do {
			$alias = $name.($index?('-'.$index):'');
			$db->setQuery('SELECT COUNT(*) FROM `#__fwfoodmenu_category` WHERE alias = '.$db->quote($alias).' AND id <> '.(int)$id);
			$index++;
		} while ($db->loadResult());
		return $alias;
	}
}
