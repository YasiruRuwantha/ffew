<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="<?php echo JURI :: root(false); ?>components/com_fwfoodmenu/assets/css/bootstrap.css" rel="stylesheet" />
<link href="<?php echo JURI :: root(false); ?>components/com_fwfoodmenu/assets/css/front-template.css" rel="stylesheet" />
<link href="<?php echo JURI :: root(false); ?>components/com_fwfoodmenu/assets/css/fwfm-front.css" rel="stylesheet" />
<style type="text/css">
html #fwfm * {
	font-family: helvetica !important;
}
.fwcss h1, .fwcss .h1 {
    font-size: 36px !important;
}
.fwcss h3, .fwcss .h3 {
    font-size: 24px !important;
}
#fwfm .row:after {
	display: table;
	content: '';
	clear: both;
}
.fwcss .mb-2 {
    margin-bottom: 6px !important;
}
#fwfm .fwfm-item-promo {
	padding: 6px !important;
	margin: 6px 0 !important;
}
#fwfm .fwfm-menu-download {
	display: none;
}
#fwfm .fwfm-item-img {
	width: 16.666666%;
	float: left;
}
#fwfm .fwfm-item-img img {
	width: 100%;
}
#fwfm .fwfm-item-price {
	width: 8.333333%;
	float: right;
}
#fwfm .fwfm-item-text {
	width: 75,000001%;
	float: left;
	padding-left: 20px;
}
#fwfm .pull-left {
	float: left;
}
#fwfm .badge,
#fwfm .fwfm-item-promo,
#fwfm .fwfm-item-description {
	font-size: 12px !important;
}
#fwfm .fwfm-item-footer {
	font-size: 10px !important;
}
#fwfm .fwfm-menu-item {
    padding: 8px !important;
    margin-bottom: 6px !important;
}
#fwfm .fa-cutlery:before {
	content: '<?php echo JText::_('FWFM_MENU_SIZE', true); ?>:';
}
#fwfm .fa-fire:before {
	content: '<?php echo JText::_('FWFM_MENU_CALORIES', true); ?>:';
}
</style>
</head>
<body>
<?php
$this->setLayout('default');
echo $this->loadTemplate();
?>
</body>
</html>