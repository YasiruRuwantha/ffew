<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class MenuViewMenu extends JViewLegacy {
	function display($tmpl=null) {
		$model = $this->getModel();
		$app = JFactory::getApplication();
		$params = $app->getParams();

		set_time_limit(60);
		ini_set('memory_limit', '1024M');

		$filename = $params->get('pdf_file');
		if ($filename) {
			$path = JPATH_SITE.'/media/com_fwfoodmenu/'.$filename;

			if (is_file($path)) {
				if (!headers_sent()) {
					header('Content-Type: application/pdf');
					header('Content-Length: '.filesize($path));
					header('Content-Disposition: attachment;filename="Online menu - '.$app->getCfg('sitename').' - '.date('d M Y').'.pdf"');
					header('Cache-Control: public, must-revalidate, max-age=0');
					header('Pragma: public');
				}
				readfile($path);
			}
		}

		die();
	}
}
