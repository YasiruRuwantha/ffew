<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class MenuViewMenu extends JViewLegacy {
	function display($tmpl=null) {
		$model = $this->getModel();

		$this->direct_link = false;

		$this->category = $model->loadCategory();
		if ($this->category->id and !$this->category->published) {
			throw new Exception(JText::_('FWFM_CATEGORY_NOT_PUBISHED', $name, $type, $prefix), 500);
		}

		$this->app = JFactory::getApplication();
		if ($this->category->id) {
			$this->params = new JFParams($this->category->params, fwFoodMenuHelper::getParentCategories($this->category->parent));
			$this->params->set('category_id', array($this->category->id));
		} else {
			$this->params = new JFParams(new JRegistry);
		}
		$this->params->set('col_qty', 1);
		$this->link = JURI::getInstance()->toString();
		$this->list = $model->loadList($this->params);

		$this->app->triggerEvent('beforeMenuDisplay', array('com_fwfoodmenu', $this, $this->list));

		if ($title = $this->params->get('page_title')) {
			JFactory::getDocument()->setTitle($title);
		}
		if ($this->params->get('show_page_heading') and !$this->params->get('page_heading')) {
			if ($this->category->id) {
				$this->params->set('page_heading', $this->category->name);
			} else {
				$this->params->set('page_heading', $this->params->get('page_title'));
			}
		}
		parent::display($tmpl);
	}
}
