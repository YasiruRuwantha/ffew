<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class JHTMLfwView {
	static function orderingListLinks($params) {
		ob_start();
?>
<div class="input-group">
<?php
		if (!empty($params['display_up'])) {
?>
	<a href="javascript:" onclick="return listItemTask('cb<?php echo $params['num']; ?>','orderup')" class="input-group-addon form-control-sm" id="btnGroupAddon"><i class="fal fa-angle-up"></i></a>
<?php
		}
?>
	<input class="form-control form-control-sm" placeholder="0" size="4" aria-describedby="btnGroupAddon" type="text" name="order[]" value="<?php echo $params['value']; ?>">
<?php
		if (!empty($params['display_down'])) {
?>
	<a href="javascript:" onclick="return listItemTask('cb<?php echo $params['num']; ?>','orderdown')" class="input-group-addon form-control-sm" id="btnGroupAddon"><i class="fal fa-angle-down"></i></a>
<?php
		}
?>
</div>
<?php
		return ob_get_clean();
	}
	static function radioListLinks($params) {
		ob_start();
?>
<div class="btn-group mb-1 <?php if (!empty($params['wrapper_class'])) echo $params['wrapper_class']; ?>" role="group">
<?php
		$row = $params['row'];
		foreach ($params['buttons'] as $button) {
			$key = $button['name'];
			$is_checked = $row->$key;
			$classes = array('btn', 'btn-secondary', 'btn-sm');
			print_r($classes);
			if ($is_checked) {
				$classes[] = 'active';
				if (!empty($button['active_class'])) {
					$classes[] = $button['active_class'];
				}
			}
			// print_r($classes);
?>
	<a href="javascript:" onclick="return listItemTask('cb<?php echo $params['num']; ?>','<?php echo $is_checked?$button['task_off']:$button['task_on']; ?>')" class="<?php echo implode(' ', $classes); ?>" title="<?php echo JText::_($is_checked?$button['title_off']:$button['title_on']); ?>"><i class="<?php echo $button['icon_class']; ?>"></i></a>
<?php
		}
?>
</div>
<?php
		return ob_get_clean();
	}
	static function booleanListLink($params) {
		ob_start();
?>
<a href="javascript:" onclick="return listItemTask('cb<?php echo $params['num']; ?>','<?php echo $params['value']?$params['task_off']:$params['task_on']; ?>')" title="<?php echo JText::_($params['value']?$params['title_off']:$params['title_on']); ?>"><span class="badge badge-pill badge-<?php echo $params['value']?'success':'danger'; ?>"><i class="fal fa-<?php echo $params['value']?'check':'times'; ?>"></i></span></a>
<?php
		return ob_get_clean();
	}
	static function menuItem($params) {
		ob_start();
?>
<li class="fwa-menu-item<?php if (!empty($params['active'])) { ?> active<?php } ?>">
	<a href="<?php echo $params['link']; ?>"><i class="<?php echo $params['icon_class']; ?>"></i> <?php echo $params['name']; ?></a>
</li>
<?php
		return ob_get_clean();
	}
	static function radioGroup($name, $value, $params) {
		ob_start();
?>
<div class="btn-group<?php if (!empty($params['wrapper_class'])) { ?> <?php echo $params['wrapper_class']; } ?>" role="group">
<?php
		foreach ($params['buttons'] as $button) {
?>
	<button type="button" class="btn<?php if (!empty($button['class'])) { ?> <?php echo $button['class']; } if ($value == $button['value']) { ?> active <?php echo $button['active_class']; } ?>" data-name="<?php echo $name; ?>" data-value="<?php echo $button['value']; ?>" data-active-class="<?php echo $button['active_class']; ?>"><?php if (!empty($button['icon_class'])) { ?><i class="fa <?php echo $button['icon_class']; ?>"></i><?php } if (!empty($button['title'])) { echo $button['title']; } ?></button>
<?php
		}
?>
</div>
<input type="hidden" name="<?php echo $name; ?>" value="<?php echo str_replace('"', '&quot;', $value); ?>" />
<?php
		if (!defined('FW_RADIO_HANDLER_LOADED')) {
			define('FW_RADIO_HANDLER_LOADED', 1);
			JHTML::_('jquery.framework');
?>
<script>
jQuery(function($) {
	$('.btn-group button').click(function() {
		var $button = $(this);
		var $input = $('input[name="'+$button.data('name')+'"]');
		if ($input.length && $input.val() != $button.data('value')) {
			$('button', $button.closest('.btn-group')).attr('class', 'btn');
			$button.addClass($button.data('active-class')).addClass('active');
			$input.val($button.data('value')).change();
		}
	});
});
</script>
<?php
		}
		return ob_get_clean();
	}
	static function handleUploadButton($params) {
		ob_start();
?>
<script>
jQuery(function($) {
<?php
		if (!defined('FWVIEW_UPLOAD_HANDLER_LOADED')) {
			define('FWVIEW_UPLOAD_HANDLER_LOADED', true);
?>
	$(document).on('change', '.fwcss input[type="file"]', function() {
		var $inp = $(this);
		var files = $inp.prop('files');
		if (files && files.length) {
			var buff = [];
			for (var i = 0; i < files.length; i++) {
				var file = files[i];
				if ('name' in file) {
					buff.push(file.name);
				} else {
					buff.push(file.fileName);
				}
			}
			$inp.parent().next().html(buff.join(','));
		} else {
			$inp.parent().next().html('<?php echo JText::_('FWFM_CHOOSE_FILE', false); ?>');
		}
	});
	$('.fwcss input[type="file"]').change();
<?php
		}
?>
	$(document).on('click', '<?php echo $params['button']; ?>', function() {
		var form = this.form;
		var $button = $(this);
		var $input = $('<?php echo $params['input']; ?>');
		var filename = $input.val();
		if (filename != '') {
			var exts = [<?php if (!empty($params['exts'])) { ?>'<?php echo implode("','", $params['exts']); ?>'<?php } ?>];
			if (exts) {
				var ext = filename.split('.').pop().toLowerCase();
				var ext_found = false;
				for (var i = 0; i < exts.length; i++) {
					if (exts[i] == ext) {
						ext_found = true;
						break;
					}
				}
				if (!ext_found) {
					alert('<?php echo JText::sprintf('FWFM_MENU_EXTENSIONS_ALLOWED', implode(", ", $params['exts'])); ?>');
					return;
				}
			}
<?php
		if (!empty($params['submit_code'])) echo $params['submit_code'];
?>
			var formdata = new FormData(form);
			formdata.append('layout', '<?php echo $params['layout']; ?>');
			formdata.append('format', 'json');

			var $progress_bar = $('<div class="progress"><div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div></div>');
			$button.attr('disabled', true).after($progress_bar);

			$.ajax({
				xhr: function() {
					var xhr = new window.XMLHttpRequest();

					xhr.upload.addEventListener("progress", function(evt) {
						if (evt.lengthComputable) {
							var percentComplete = evt.loaded / evt.total;
							percentComplete = parseInt(percentComplete * 100);
							$progress_bar.find('.progress-bar').css('width', percentComplete+'%');
						}
					}, false);

					return xhr;
				},
				url: <?php if (empty($params['url'])) { ?>form.action<?php } else { ?>'<?php echo $params['url']; ?>'<?php } ?>,
				type: "POST",
				data: formdata,
				contentType: false,
				processData: false,
				success: <?php if (empty($params['callback'])) { ?>function(result) {
					$progress_bar.remove();
					$button.attr('disabled', false);
					$input.parent().next().html('<?php echo JText::_('FWFM_CHOOSE_FILE', false); ?>');
					var $parent = $input.parent();
					var input_html = $parent.html();
					$parent.html(input_html);
					var data = $.parseJSON(result);
					if (data) {
						if (data.id) {
							$('input[name="id"]').val(data.id);
						}
						if (data.image) {
							$('<?php echo $params['image']; ?>').attr('src', data.image).parent().show();
						}
						if (data.msg) {
							alert(data.msg);
						}
					}
				}
<?php
				} else echo $params['callback'];
?>
			});
		}
	});
});
</script>
<?php
		return ob_get_clean();
	}
	static function handleRemoveButton($params) {
		ob_start();
?>
<script>
jQuery(function($) {
	$(document).on('click', '<?php echo $params['button']; ?>', function() {
		var form = this.form;
		var $button = $(this);
		if (form.id.value > 0) {
			$img = $('<img/>', {
				src: '<?php echo JURI::root(true); ?>/components/com_fwfoodmenu/assets/images/ajax-loader.gif',
				style: 'margin: 0 0 0 6px;'
			});
			$button.attr('disabled', true).after($img);
			$.ajax({
				url: <?php if (empty($params['url'])) { ?>form.action<?php } else { ?>'<?php echo $params['url']; ?>'<?php } ?>,
				type: 'post',
				data: {
					format: 'json',
					id: form.id.value,
					button_id: $button.data('id'),
					layout: '<?php echo $params['layout']; ?>'
				},
				success: <?php if (empty($params['callback'])) { ?>function(result) {
					$img.remove();
					$button.attr('disabled', false);
					var data = $.parseJSON(result);
					if (data) {
						if (data.result) {
							$('<?php echo $params['image']; ?>').parent().hide();
						}
						if (data.image) {
							$('<?php echo $params['image']; ?>').attr('src', data.image);
						}
						if (data.msg) {
							alert(data.msg);
						}
					}
				}
<?php
				} else echo $params['callback'];
?>
			});
		}
	});
});
</script>
<?php
		return ob_get_clean();
	}
}
