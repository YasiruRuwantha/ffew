<?php
/**
 * FW Gallery 2.0.0
 * @copyright (C) 2018 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

?>
            </div>
        </div>
    </div>
</div>
<script>
jQuery(function($) {
	$('[data-toggle="tooltip"]').tooltip();
});
</script>
