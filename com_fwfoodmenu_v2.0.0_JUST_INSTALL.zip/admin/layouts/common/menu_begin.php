<?php
/**
 * FW Gallery 2.0.0
 * @copyright (C) 2018 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

JHTML::_('bootstrap.popover', '[data-toggle="popover"]');
JHTML::_('bootstrap.tooltip', '[data-toggle="tooltip"]');

$menus = array(
    'menu',
    'category',
    'items',
    'addon',
	'data',
    'translation',
    'css',
    'settings'
);
$icons = array(
    'menu' => 'fal fa-tachometer-alt',
    'category' => 'fal fa-folder',
    'items' => 'fal fa-utensils',
    'addon' => 'fal fa-puzzle-piece',
	'data' => 'fal fa-database',
    'translation' => 'fal fa-globe',
    'css' => 'fal fa-paint-brush-alt',
    'settings' => 'fal fa-sliders-h'
);
$titles = array(
    'menu' => 'DASHBOARD',
    'category' => 'CATEGORIES',
    'items' => 'MENU',
    'addon' => 'ADDONS',
	'data' => 'DATA_MANAGEMENT',
    'translation' => 'TRANSLATIONS',
    'css' => 'STYLES',
    'settings' => 'SETTINGS',
);

$params = JComponentHelper::getParams('com_fwfoodmenu');
$update_code = $params->get('update_code');
$verified_code = $params->get('verified_code');
$user_name = $params->get('user_name');
$user_avatar = $params->get('user_avatar');
$user_email = $params->get('user_email');

$account_verified = ($update_code and $update_code == $verified_code);

$view = $displayData['view'];
?>
<div id="fw-admin" class="container-fluid fwcss fw-admin">
    <div class="row no-gutters">
        <div class="col-lg-2 col-md-3 col-sm-4 fwa-sidebar-wrapper">
            <div class="fwa-sidebar">
                <div class="fwa-account">
                    <div class="alert alert-danger fwa-user-no-login"<?php if ($account_verified) { ?> style="display:none"<?php } ?>>
                        <i class="far fa-exclamation-triangle mr-1"></i>
                        <strong><?php echo JText::_('FWFM_UPDATES_SUPPORT_LIMITED'); ?></strong>
                        <?php echo JText::_('FWFM_USE_FASTW3B_ACCOUNT_ACCESS_CODE'); ?>
                    </div>
                    <div id="fwre-verify-code" class="input-group fwa-user-no-login"<?php if ($account_verified) { ?> style="display:none"<?php } ?>>
                        <input class="form-control" type="password" name="update_code" placeholder="<?php echo $view->escape(JText::_('FWFM_ENTER_ACCESS_CODE')); ?>" />
                        <span class="input-button-btn">
                            <button type="button" class="btn btn-success">
                                <i class="fal fa-user-check mr-1"></i><?php echo JText::_('FWFM_VERIFY'); ?></button>
                        </span>
                    </div>
                    <div class="alert alert-success row no-gutters fwa-account-user fwa-user-logged-in"<?php if (!$account_verified) { ?> style="display:none"<?php } ?>>
                        <div class="col-4 fwa-account-photo">
                            <a href="https://fastw3b.net/client-section" target="_blank" title="<?php echo $this->escape(JText::_('FWFM_USER_NAME')); ?>">
								<img class="img-thumbnail rounded-circle" src="<?php if ($user_avatar) { echo $user_avatar; } else { ?>data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22100%22%20height%3D%22100%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20100%20100%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_163baf62b65%20text%20%7B%20fill%3A%23AAAAAA%3Bfont-weight%3Abold%3Bfont-family%3AArial%2C%20Helvetica%2C%20Open%20Sans%2C%20sans-serif%2C%20monospace%3Bfont-size%3A10pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_163baf62b65%22%3E%3Crect%20width%3D%22100%22%20height%3D%22100%22%20fill%3D%22%23EEEEEE%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%2220%22%20y%3D%2250%22%3E100x100%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E<?php } ?>">
							</a>
                        </div>
                        <div class="col-8 fwa-account-user-info">
                            <div class="fwa-account-user-info-name">
                                <a href="https://fastw3b.net/client-section" target="_blank" title="<?php echo $this->escape(JText::_('FWFM_USER_NAME')); ?>">
                                    <?php echo $user_name; ?></a>
                            </div>
                            <div class="fwa-account-user-info-email"><?php echo $user_email; ?></div>
                            <div class="fwa-account-user-revoke">
                                <a class="text-danger" href="javascript:">
                                    <i class="fal fa-sign-out mr-1"></i><?php echo JText::_('FWFM_REVOKE_CODE'); ?>
								</a>
                            </div>
                        </div>
                    </div>
<script>
jQuery(function($) {
	$('ul[role="tablist"] li.nav-item').click(function(ev) {
		ev.stopPropagation();
		ev.preventDefault();
		var $el = $(this).removeClass('active');

		var $link = $el.find('a');
		if (!$link.hasClass('active')) {
			var $prev_link = $el.closest('ul').find('a.active').removeClass('active');
			$($prev_link.attr('href')).hide();
			$link.addClass('active');
			$($link.attr('href')).show();
		}
	});
	$('#fwre-verify-code button').click(function() {
		var $btn = $(this);
		var code = $('input[name="update_code"]').val();
		if (code.trim() != '') {
			$btn.attr('disabled', true);

			$.ajax({
				'url': '',
				'method': 'post',
				'dataType': 'json',
				'data': {
					'format': 'json',
					'view': 'menu',
					'layout': 'verify_code',
					'code': code
				}
			}).done(function(data) {
				$btn.attr('disabled', false);

				if (data) {
					if (data.user_avatar) {
						$('.fwa-account-photo img').attr('src', data.user_avatar);
					}
					if (data.user_name) {
						$('.fwa-account-user-info-name a').html(data.user_name);
					}
					if (data.user_email) {
						$('.fwa-account-user-info-email').html(data.user_email);
					}
					if (data.verified) {
						$('.fwa-user-no-login').hide(300, function() {
							$('.fwa-user-logged-in').show(300);
						});
					}
					if (data.msg) alert(data.msg);
				}
			});
		} else alert('<?php echo JText::_('FWFM_ENTER_YOUR_ACCESS_CODE', true); ?>');
	});
	$('.fwa-account-user-revoke a').click(function() {
		var $btn = $(this);
		if ($btn.data('fwa-wip')) return;
		$btn.data('fwa-wip', true);

		$.ajax({
			'url': '',
			'method': 'post',
			dataType: 'json',
			'data': {
				'format': 'json',
				'view': 'menu',
				'layout': 'revoke_code'
			}
		}).done(function(data) {
			$btn.data('fwa-wip', false);
			if (data) {
				if (data.result) {
					$('input[name="update_code"]').val('');
					$('.fwa-user-logged-in').hide(300, function() {
						$('.fwa-user-no-login').show(300);
					});
				}
				if (data.msg) alert(data.msg);
			}
		});
	});
});
</script>
                </div>
                <ul class="fwa-sidebar-menu">
<?php
foreach ($menus as $menu) {
    echo JHTML::_('fwView.menuItem', array(
        'active' => ($menu == $view->menu),
        'link' => 'index.php?option=com_fwfoodmenu&view='.$menu,
        'icon_class' => $icons[$menu],
        'name' => JText::_('FWFM_MENU_'.(empty($titles[$menu])?$menu:$titles[$menu]))
    ));
}
?>
                </ul>
            </div>
        </div>
        <div class="col-md col-sm-12 fwa-main">
            <div class="fwa-main-header">
                <h2><?php echo $displayData['title']; ?></h2>
                <div class="fwa-main-text"><?php echo $displayData['title_hint']; ?></div>
            </div>
            <div class="fwa-main-body">
