<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class TableCategory extends JTable {
    var $id = null,
        $parent = null,
    	$name = null,
		$alias = null,
		$ordering = null,
		$short_description = null,
		$description = null,
		$published = null,
		$pdf_menu = null,
		$params = null;

    function __construct(&$db) {
        parent::__construct('#__fwfoodmenu_category', 'id', $db);
    }

	function load($oid = null, $reset = null) {
		if (parent::load($oid, $reset)) {
			$this->params = new JRegistry($this->params);
			JFactory::getApplication()->triggerEvent('loadCategory', array('com_fwfoodmenu', &$this));
			return true;
		}
	}

    function check() {
		if (!$this->name) {
			$this->setError(JText :: _('FWFM_EMPTY_NAME'));
			return false;
		}

		$db = JFactory :: getDBO();
		if (!$this->id) {
			if (!$this->ordering) {
				$db->setQuery('SELECT MAX(ordering) FROM `#__fwfoodmenu_category`');
				$this->ordering = 1 + (int)$db->loadResult();
			}
		}

		if (!$this->alias) $this->alias = $this->name;
		$this->alias = fwFoodMenuHelper::getCategoryAlias($this->id, $this->alias);
		
		$params = new JRegistry($this->params);
		$this->params = $params->toString();

		$data = JFactory::getApplication()->triggerEvent('checkCategory', array('com_fwfoodmenu', &$this));
		if ($data) {
			foreach ($data as $row) {
				if (!$row) {
					return;
				}
			}
		}

		return true;
    }
	function store($updn = null) {
		if (parent::store($updn)) {
			JFactory::getApplication()->triggerEvent('storeCategory', array('com_fwfoodmenu', &$this));
			return true;
		}
	}
    function delete($oid = null) {
    	if ((int)$oid and $this->load($oid) and parent::delete($oid)) {
			JFactory::getApplication()->triggerEvent('deleteCategory', array('com_fwfoodmenu', &$this));
    		return true;
    	} else $this->setError(JText::_('FWFM_NO_CATEGORY_ID_PASSED'));
    }
}
