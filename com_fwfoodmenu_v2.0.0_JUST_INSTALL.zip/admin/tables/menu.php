<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class TableMenu extends JTable {
    var $id = null,
    	$category_id = null,
    	$ordering = null,
    	$name = null,
		$published = null,
		$image = null,
        $image_size = null,
		$description = null,
		$created = null,
		$price = null,
		$special_price = null,
		$special_descr = null,
		$weight = null,
		$energy = null,
		$is_meal_of_the_day = null,
		$is_new = null,
		$is_recommended = null;

	var $_category_name = null,
        $_prices_exists = null,
        $_prices = null;

    function __construct(&$db) {
        parent::__construct('#__fwfoodmenu_menu', 'id', $db);
    }

    function load($keys = NULL, $reset = true) {
		if ($keys and is_numeric($keys)) {
			$app = JFactory::getApplication();
			$extras = $app->triggerEvent('getMenuExtraFields', array('com_fwfoodmenu'));

			$db = JFactory::getDBO();
			$db->setQuery('
SELECT
	m.*,
	(SELECT c.name FROM #__fwfoodmenu_category AS c WHERE c.id = m.category_id LIMIT 1) AS _category_name,
	(SELECT COUNT(*) FROM #__fwfoodmenu_menu_price AS mp WHERE mp.menu_id = m.id) AS _prices_exists
    '.implode('', $extras).'
FROM
	#__fwfoodmenu_menu AS m
WHERE
	m.id = '.(int)$keys);
			if ($obj = $db->loadObject()) {
				foreach ($obj as $key => $val) $this->$key = $val;
				if ($this->_prices_exists) {
					$db = JFactory::getDBO();
					$db->setQuery('SELECT * FROM `#__fwfoodmenu_menu_price` WHERE menu_id = '.(int)$this->id.' ORDER BY `ordering`');
					$this->_prices = $db->loadObjectList();
				}
				$app->triggerEvent('loadMenu', array('com_fwfoodmenu', $this));
				return true;
			}
		}
    }

    function check() {
			$db = JFactory::getDBO();
    		jimport('joomla.filesystem.file');

    		if (!$this->id) {
    			if (!$this->ordering) {
//					$db->setQuery('SELECT MAX(ordering) FROM #__fwfoodmenu_menu WHERE category_id = '.(int)$this->category_id);
					$db->setQuery('SELECT MAX(ordering) FROM #__fwfoodmenu_menu');
					$this->ordering = 1 + (int)$db->loadResult();
    			}
    		}
			$input = JFactory::getApplication()->input;

    		$path = JPATH_SITE.'/media/com_fwfoodmenu/menu/';
    		if ($this->image and $input->getInt('delete_image')) {
    			if (is_file($path.$this->image)) JFile::delete($path.$this->image);
				$this->image = '';
                $this->image_size = 0;
    		}
    		if ($image = $input->files->get('image') and !empty($image['tmp_name']) and empty($image['error'])) {
				$ext = strtolower(JFile::getExt($image['name']));
				$filename = fwFoodMenuHelper::findUnicFilename($path, $ext);
				if (JFile::upload($image['tmp_name'], $path.$filename)) {
					$this->image = $filename;
                    $this->image_size = filesize($path.$filename);
				}
    		}
			$data = JFactory::getApplication()->triggerEvent('checkMenu', array('com_fwfoodmenu', $this));
			if ($data) {
				foreach ($data as $row) {
					if (!$row) {
						return;
					}
				}
			}
    		return true;
    }
    function store($updn=null) {
        if (parent::store($updn)) {
			$db = JFactory::getDBO();
			if ($this->_prices_exists) {
				$db->setQuery('DELETE FROM `#__fwfoodmenu_menu_price` WHERE menu_id = '.(int)$this->id);
				$db->execute();
			}
			$input = JFactory::getApplication()->input;
			if ($prices = $input->getVar('prices')) {
				$i = 0;
				foreach ($prices as $row) {
					if (empty($row['name']) and empty($row['size']) and empty($row['price']) and empty($row['special_price']) and empty($row['energy'])) {
						continue;
					}
					$db->setQuery('
	INSERT INTO
		`#__fwfoodmenu_menu_price`
	SET
		`menu_id` = '.(int)$this->id.',
		`ordering` = '.(int)$i.',
		`name` = '.$db->quote($row['name']).',
		`size` = '.$db->quote($row['size']).',
		`price` = '.$db->quote($row['price']).',
		`special_price` = '.$db->quote($row['special_price']).',
		`energy` = '.$db->quote($row['energy']));
					$db->execute();
					$i++;
				}
			}
			JFactory::getApplication()->triggerEvent('storeMenu', array('com_fwfoodmenu', $this));
            return true;
        }
    }
    function delete($oid = null) {
    	if ((int)$oid and $this->load($oid) and parent::delete($oid)) {
			if ($this->_prices_exists) {
				$db = JFactory::getDBO();
				$db->setQuery('DELETE FROM `#__fwfoodmenu_menu_price` WHERE menu_id = '.(int)$this->id);
				$db->execute();
			}
			jimport('joomla.filesystem.file');
			$path = JPATH_SITE.'/media/com_fwfoodmenu/menu/';
			if ($this->image and is_file($path.$this->image)) {
				JFile::delete($path.$this->image);
			}
			JFactory::getApplication()->triggerEvent('deleteMenu', array('com_fwfoodmenu', $this));
    		return true;
    	} else $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED'));
    }
}
