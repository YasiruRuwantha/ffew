CREATE TABLE IF NOT EXISTS `#__fwfoodmenu_category` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `ordering` int(10) unsigned NOT NULL default '0',
  `name` varchar(200) default NULL,
  `description` text,
  `published` tinyint unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`),
  KEY `published` (`published`),
  KEY `ordering` (`ordering`)
);

CREATE TABLE IF NOT EXISTS `#__fwfoodmenu_menu` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `category_id` int(10) unsigned default NULL,
  `ordering` int(10) unsigned NOT NULL default '0',
  `name` varchar(200) default NULL,
  `published` tinyint unsigned default NULL,
  `image` varchar(200) default NULL,
  `description` text,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `price` decimal(10,2) default NULL,
  `special_price` decimal(10,2) default NULL,
  `special_descr` text,
  `weight` int(10) unsigned default NULL,
  `energy` int(10) unsigned default NULL,
  `is_new` tinyint unsigned default NULL,
  `is_meal_of_the_day` tinyint unsigned default NULL,
  `is_daily_special` tinyint unsigned default NULL,
  `file` varchar(200) default NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`),
  KEY `published` (`published`),
  KEY `ordering` (`ordering`),
  KEY `category_id` (`category_id`)
);
