<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2018 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

class menuModelTranslation extends JModelLegacy {
    function getUserState($name, $def='', $type='cmd') {
        $app = JFactory::getApplication();
        $context = 'com_fwfoodmenu.language.';
        return $app->getUserStateFromRequest($context.$name, $name, $def, $type);
    }
	function getLanguageData() {
		jimport('joomla.filesystem.file');
		$langs = fwFoodMenuHelper::getInstalledLanguages();
		$lang = JArrayHelper::getValue($langs, fwFoodMenuHelper::getLanguage());
		$type = (int)$this->getUserState('type', 0, 'int');

		$serach = $this->getUserState('search', '', 'string');

		$src_file = ($type?JPATH_SITE:JPATH_ADMINISTRATOR).'/language/en-GB/en-GB.com_fwfoodmenu.ini';
		$trg_file = ($type?JPATH_SITE:JPATH_ADMINISTRATOR).'/language/'.$lang->tag.'/'.$lang->tag.'.com_fwfoodmenu.ini';

		$src_buff = file_exists($src_file)?explode("\n", JFile::read($src_file)):array();
		$result = array();
		foreach ($src_buff as $i=>$row) if (trim($row)) {
			$row = explode("=", trim($row), 2);
			if (!empty($row[1]) and (!$serach or ($serach and (mb_stripos($row[0], $serach) !== false or mb_stripos($row[1], $serach) !== false))))
				$result[$row[0]] = array(
					'src' => trim($row[1], '"'),
					'trg' => ''
				);
		}

		$trg_buff = file_exists($trg_file)?explode("\n", JFile::read($trg_file)):array();
		foreach ($trg_buff as $i=>$row) if (trim($row)) {
			$row = explode("=", trim($row), 2);
			if (!empty($row[1]) and (!$serach or ($serach and (mb_stripos($row[0], $serach) !== false or mb_stripos($row[1], $serach) !== false)))) {
				if (isset($result[$row[0]])) {
					$result[$row[0]]['trg'] = trim($row[1], '"');
				} else {
					$result[$row[0]] = array(
						'src' => '',
						'trg' => trim($row[1], '"')
					);
				}
			}
		}

		return $result;
	}
	function save() {
		$langs = fwFoodMenuHelper::getInstalledLanguages();
		$lang = JArrayHelper::getValue($langs, fwFoodMenuHelper::getLanguage());
		$input = JFactory::getApplication()->input;
		$type = (int)$input->getInt('type');

		$trg_file = ($type?JPATH_SITE:JPATH_ADMINISTRATOR).'/language/'.$lang->tag.'/'.$lang->tag.'.com_fwfoodmenu.ini';

		$result = array();

/* load existing values */
		$trg_buff = file_exists($trg_file)?explode("\n", JFile::read($trg_file)):array();
		foreach ($trg_buff as $i=>$row) if (trim($row)) {
			$row = explode("=", trim($row), 2);
			if (!empty($row[1]))
				$result[$row[0]] = trim($row[1], '"');
		}

/* update changes */
		if ($data = (array)$input->getRaw('lang_data')) {
			foreach ($data as $const => $val) {
				$result[$const] = $val;
			}

/* collect language file */
			$buff = '';
			foreach ($result as $const=>$val) if (!empty($val)) {
				$buff .= $const.'="'.str_replace(array('"', "\r", "\n", "\t"), array('&quot;', ' ', ' ', ' '), $val).'"'."\n";
			}

/* store updated language file */
			jimport('joomla.filesystem.file');
			if (JFile::write($trg_file, $buff)) {
				$this->setError(JText::_('FWFM_LANGUAGE_FILE_SUCCESFULLY_UPDATED'));
				return true;
			} else {
				$this->setError(JText::_('FWFM_LANGUAGE_CANT_WRITE_FILE'));
			}
		}
	}
}
