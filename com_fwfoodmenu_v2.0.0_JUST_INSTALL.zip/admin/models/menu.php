<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class MenuModelMenu extends JModelLegacy {
	function localStat() {
		$db = JFactory::getDBO();
		$query = '
SELECT
	(SELECT COUNT(*) FROM `#__fwfoodmenu_category`) AS ct,
	(SELECT COUNT(*) FROM `#__fwfoodmenu_category` WHERE published = 1) AS cp,
	(SELECT COUNT(*) FROM `#__fwfoodmenu_menu`) AS mt,
	(SELECT COUNT(*) FROM `#__fwfoodmenu_menu` WHERE published = 1) AS mp,
	(SELECT SUM(`image_size`) FROM `#__fwfoodmenu_menu` WHERE `image_size` IS NOT NULL) AS `is`';

		$db->setQuery($query);
		$data = $db->loadObject();

		$size = 0;
		foreach ($data as $key=>$val) {
			/* sum up all sizes */
			if ($key[strlen($key) - 1] == 's') {
				$size += $val;
				unset($data->$key);
			}
		}
		$data->fs = $size;

		return $data;
	}
	function quickCheck() {
		$data = new stdclass;
		jimport('joomla.filesystem.file');
		$path = JPATH_SITE.'/media/';
		if (!file_exists($path)) {
			JFile::write($path.'index.html', $html='<html><body></body></html>');
		}
		$data->media_folder_exists = file_exists($path);
		$path .= 'com_fwfoodmenu/';
		if (!file_exists($path)) {
			JFile::write($path.'index.html', $html='<html><body></body></html>');
		}
		$data->gallery_folder_exists = file_exists($path);
		$data->gallery_folder_writeable = is_writable($path);
		$data->gd_installed = function_exists('gd_info');
		$data->exif_installed = function_exists('exif_read_data');
		$data->version = $this->getVersion();

		$data->test_passed = true;
		foreach ($data as $key=>$val) {
			if (!$val) {
				$data->test_passed = false;
				break;
			}
		}

		return $data;
	}
	function loadParamsObj() {
		return (object)array(
			'params' => JComponentHelper::getParams('com_fwfoodmenu')
		);
	}
    function save() {
    	$params = JComponentHelper::getParams('com_fwfoodmenu');
		$input = JFactory::getApplication()->input;
		$data = (array)$input->getVar('config');

    	$fields = array(
			'display_descr_gallery',
		);
		foreach ($fields as $field) $data[$field] = $input->getVar($field);

	   	$params->loadArray($data);

		return $this->store($params);
	}
	function store($params) {
		$cache = JFactory::getCache('_system', 'callback');
    	$cache->clean();

    	$db = JFactory::getDBO();
		$db->setQuery('UPDATE #__update_sites SET extra_query = '.$db->quote('&code='.$params->get('update_code')).' WHERE name = \'FW Food Menu\'');
		$db->execute();
		$db->setQuery('TRUNCATE TABLE #__updates');
		$db->execute();

    	$db->setQuery('UPDATE #__extensions SET params = '.$db->quote($params->toString()).' WHERE `element` = \'com_fwfoodmenu\' AND `type` = \'component\'');
    	return $db->execute();
	}
	function getDescription() {
		$buff = file_get_contents(JPATH_ADMINISTRATOR.'/components/com_fwfoodmenu/fwfoodmenu.xml');
		if (preg_match('#<description><\!\[CDATA\[(.*?)\]\]></description>#msi', $buff, $match)) {
			return $match[1];
		}
	}
	function getVersion() {
		$buff = file_get_contents(JPATH_ADMINISTRATOR.'/components/com_fwfoodmenu/fwfoodmenu.xml');
		if (preg_match('#<version>(.*?)</version>#msi', $buff, $match)) {
			return $match[1];
		}
	}
	function checkUpdate() {
		$data = new stdclass;
		$data->loc_version = $this->getVersion();
		$data->need_update = false;
		if ($buff = fwFoodMenuHelper::request(FWA_UPDATE_SERVER.'/index.php?option=com_fwsales&view=updates&layout=package&format=raw&package='.FWA_UPDATE_NAME.'&dummy=extension.xml')) {
			if (preg_match('#<extension.*version="([^"]*)"#', $buff, $match)) {
				$data->rem_version = $match[1];

				if ($data->loc_version != 'x.x.x') {
					$rem_buff = explode('.', $data->rem_version);
					$loc_buff = explode('.', $data->loc_version);
					if (count($rem_buff) == 3 and count($loc_buff) == 3 and ($rem_buff[0] > $loc_buff[0] or ($rem_buff[0] == $loc_buff[0] and $rem_buff[1] > $loc_buff[1]) or ($rem_buff[0] == $loc_buff[0] and $rem_buff[1] == $loc_buff[1] and $rem_buff[2] > $loc_buff[2]))) {
						$data->need_update = true;
					}
				}
			}
		} else $this->setError(JText::_('FWFM_NO_RESPONSE_FROM_REMOTE_SERVER'));

		return $data;
	}
	function verifyCode() {
		$data = new stdclass;
		$input = JFactory::getApplication()->input;
		if ($code = $input->getString('code')) {
			if ($buff = fwFoodMenuHelper::request(FWA_UPDATE_SERVER.'/index.php?option=com_fwsales&view=updates&layout=verify_code&format=raw&package='.FWA_UPDATE_NAME.'&code='.urlencode($code).'&host='.urlencode(JURI::root(false)))) {
				$tmp = json_decode($buff);
				if ($tmp) {
					if (!empty($tmp->msg)) $this->setError($tmp->msg);
					$data->user_name = empty($tmp->user_name)?'':$tmp->user_name;
					$data->user_avatar = empty($tmp->user_avatar)?'':$tmp->user_avatar;
					$data->user_email = empty($tmp->user_email)?'':$tmp->user_email;
					if (!empty($tmp->verified)) {
						$data->verified = 1;
						$params = JComponentHelper::getParams('com_fwrealestate');
						$params->set('update_code', $code);
						$params->set('verified_code', $code);
						$params->set('user_name', $data->user_name);
						$params->set('user_avatar', $data->user_avatar);
						$params->set('user_email', $data->user_email);
						$this->store($params);
					}
				} elseif (preg_match('#<title>([^<]+)<#msi', $buff, $match)) {
					$this->setError($match[1]);
				}
			} else $this->setError(JText::_('FWFM_NO_RESPONSE_FROM_REMOTE_SERVER'));
		} else $this->setError(JText::_('FWFM_NO_CODE_TO_VERIFY'));
		return $data;
	}
	function getChangelog() {
		if ($buff = fwFoodMenuHelper::request(FWA_UPDATE_SERVER.'/index.php?option=com_fwsales&view=updates&layout=changelog&format=raw&package='.FWA_UPDATE_NAME)) {
			$tmp = json_decode($buff);
			if (!empty($tmp->msg)) $this->setError($tmp->msg);
			if ($tmp->result) {
				return $tmp->result;
			}
		}
	}
	function revokeCode() {
		$data = new stdclass;
		$params = JComponentHelper::getParams('com_fwfoodmenu');
		$params->set('verified_code', '');
		$data->result = $this->store($params);
		return $data;
	}
	function updatePackage() {
		$params = JComponentHelper::getParams('com_fwfoodmenu');
		$code = $params->get('update_code');
		$result = false;
		if ($code) {
			if ($code == $params->get('verified_code')) {
				if ($buff = fwFoodMenuHelper::request(FWA_UPDATE_SERVER.'/index.php?option=com_fwsales&view=updates&layout=package&format=raw&package='.FWA_UPDATE_NAME.'&dummy=extension.xml')) {
					if (preg_match('#detailsurl="([^"]*)"#', $buff, $match)) {
						$url = str_replace('&amp;', '&', $match[1]);
						if ($buff = fwFoodMenuHelper::request($url)) {
							if (preg_match('#<downloadurl[^>]*>([^<]+)</downloadurl>#', $buff, $match)) {
								$url = str_replace('&amp;', '&', $match[1]).'&code='.urlencode($code);
								if ($buff = fwFoodMenuHelper::request($url)) {
									jimport('joomla.filesystem.file');
									jimport('joomla.filesystem.folder');
									$path = JPATH_SITE.'/tmp/';

									$filename = '';
									do {
										$filename = 'inst'.rand().'.zip';
									} while (file_exists($path.$filename));

									if (JFile::write($path.$filename, $buff)) {
										$package = JInstallerHelper::unpack($path.$filename, true);
										if (!empty($package['dir'])) {
											$installer = JInstaller::getInstance();
											if ($result = $installer->install($package['dir'])) {
												$this->setError(JText::_('FWFM_UPDATED_SUCCESFULLY'));
											} else {
												$this->setError(JText::_('FWFM_NOT_UPDATED'));
											}
										}
										if (file_exists($path.$filename)) JFile::delete($path.$filename);
										if (file_exists($package['dir'])) JFolder::delete($package['dir']);
									} else $this->setError(JText::_('FWFM_CANT_WRITE_FILE'));
								} else $this->setError(JText::_('FWFM_SERVER_REFUSES_DOWNLOAD'));
							} else $this->setError(JText::_('FWFM_WRONG_RESPONSE_FORMAT_FROM_REMOTE_SERVER'));
						} else $this->setError(JText::_('FWFM_NO_RESPONSE_FROM_REMOTE_SERVER'));
					} else $this->setError(JText::_('FWFM_WRONG_RESPONSE_FORMAT_FROM_REMOTE_SERVER'));
				} else $this->setError(JText::_('FWFM_NO_RESPONSE_FROM_REMOTE_SERVER'));
			} else $this->setError(JText::_('FWFM_CODE_NOT_VERIFIED'));
		} else $this->setError(JText::_('FWFM_NO_UPDATE_CODE'));
		return $result;
	}
	function getAddons() {
		$model = JModelLegacy::getInstance('addon', 'menuModel');
		return $model->getPluginsData();
	}
}
