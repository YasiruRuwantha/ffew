<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class MenuModelcss extends JModelLegacy {
	function getEditor() {
		$editor = '';
		$db = JFactory::getDbo();
		$db->setQuery('SELECT `element` FROM `#__extensions` WHERE `element` IN (\'codemirror\',\'none\') AND `folder` = \'editors\'');
		if ($list = $db->loadColumn()) {
			if (in_array('codemirror', $list)) {
				$editor = 'codemirror';
			} else {
				$editor = 'none';
			}
		} else {
			$editor = JFactory::getConfig()->get('editor');
		}
		return JEditor::getInstance($editor);
	}
	function loadObject() {
		return (object)array(
			'params' => JComponentHelper::getParams('com_fwfoodmenu')
		);
	}
    function save() {
    	$params = JComponentHelper::getParams('com_fwfoodmenu');
		$input = JFactory::getApplication()->input;
		$data = (array)$input->getVar('config');

    	$fields = array(
		);
		foreach ($fields as $field) $data[$field] = $input->getVar($field);

	   	$params->loadArray($data);

		return fwFoodMenuHelper::storeConfig($params);
	}
	function getTmplPluginsCss() {
		$plugins = fwFoodMenuHelper::loadPlugins();
		$data = array();
		if (!empty($plugins['fwfoodmenutmpl'])) {
			$lang = JFactory::getLanguage();
			foreach ($plugins['fwfoodmenutmpl'] as $plg) {
				$path = JPATH_SITE.'/plugins/fwfoodmenutmpl/'.$plg->element.'/assets/css/fwfm-design-styles.css';
				if (file_exists($path)) {
					$lang->load('plg_fwfoodmenutmpl_'.$plg->element);
					$data[] = (object)array(
						'element' => $plg->element,
						'path' => str_replace('\\', '/', $path),
						'content' => file_get_contents($path)
					);
				}
			}
		}
		return $data;
	}
}
