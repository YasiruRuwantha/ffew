<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class menuModelItems extends JModelLegacy {
	function _collectWhere() {
		$where = array();
		$db = JFactory::getDBO();
		$input = JFactory::getApplication()->input;
		if ($buff = $input->getInt('category')) $where[] = 'm.category_id = '.(int)$buff;
		if ($buff = $input->getString('search')) $where[] = "m.name LIKE '%".$db->escape($buff)."%'";
		return $where?(' WHERE '.implode(' AND ', $where)):'';
	}
	function loadList() {
        $app = JFactory::getApplication();
		$input = $app->input;
		$db = JFactory::getDBO();

        $extras = $app->triggerEvent('getMenuListExtraFields', array('com_fwfoodmenu'));

        $db->setQuery('
SELECT
    m.*,
	c.name AS _category_name,
	\'\' AS _prices
    '.implode('', $extras).'
FROM
    #__fwfoodmenu_menu AS m
    LEFT JOIN #__fwfoodmenu_category AS c ON m.category_id = c.id
'.$this->_collectWhere().'
ORDER BY
	m.ordering',
			$input->getInt('limitstart'),
			$input->getInt('limit', $app->getCfg('list_limit'))
		);
        if ($list = $db->loadObjectList()) {
			$ids = array();
			foreach ($list as $i=>$row) {
				$ids[] = $row->id;
				$list[$i]->_prices = array();
			}
			$db = JFactory::getDBO();
			$db->setQuery('SELECT * FROM `#__fwfoodmenu_menu_price` WHERE menu_id IN ('.implode(',', $ids).') ORDER BY ordering');
			if ($buff = $db->loadObjectList()) {
				foreach ($buff as $row) {
					$key = array_search($row->menu_id, $ids);
					$list[$key]->_prices[] = $row;
				}
			}
			$app->triggerEvent('calculateMenuListExtraFields', array('com_fwfoodmenu', &$list));
			return $list;
		}
	}
	function loadQty() {
		$db = JFactory::getDBO();
        $db->setQuery('
SELECT
    COUNT(*)
FROM
    #__fwfoodmenu_menu AS m
    LEFT JOIN #__fwfoodmenu_category AS c ON m.category_id = c.id
'.$this->_collectWhere());
        return $db->loadResult();
	}
	function getPagination() {
        $app = JFactory::getApplication();
		$input = $app->input;
        jimport('joomla.html.pagination');
		return new JPagination(
			$this->loadQty(),
			$input->getInt('limitstart'),
			$input->getInt('limit', $app->getCfg('list_limit'))
		);
	}
	function loadObject() {
        $menu = $this->getTable('menu');
		$input = JFactory::getApplication()->input;
        if (($ids = (array)$input->getVar('cid') and $id = JArrayHelper::getValue($ids, 0)) or $id = $input->getInt('id', 0)) {
            $menu->load($id);
        } else if ($category_id = $input->getInt('category')) {
        	$menu->category_id = $category_id;
        }
        return $menu;
	}
    function save() {
        $menu = $this->getTable('menu');
		$input = JFactory::getApplication()->input;
        if ($id = $input->getInt('id') and !$menu->load($id)) $input->set('id', 0);

        if ($menu->bind($input->getArray(array(), null, 'RAW')) and $menu->check() and $menu->store()) {
            $this->setError(JText::_('FWFM_MENU_STORED_SUCCESSFULLY'));
            return $menu->id;
        } else
        	$this->setError($menu->getError());
    }
	function save2copy() {
		$input = JFactory::getApplication()->input;

		$menu = $this->getTable('menu');

		$image_uploaded = $input->files->get('image');
		$id = $input->getInt('id');
		$input->set('id', 0);

		if ($menu->bind($input->getArray(array(), null, 'RAW')) and $menu->check() and $menu->store()) {
			if ($id and empty($image_uploaded['name'])) {
				$path = JPATH_SITE.'/media/com_fwfoodmenu/menu/';
				$db = JFactory::getDBO();
				$db->setQuery('SELECT `image` FROM `#__fwfoodmenu_menu` WHERE id = '.(int)$id);
				if ($image = $db->loadResult() and file_exists($path.$image)) {
					$ext = strtolower(JFile::getExt($image));
					$filename = fwFoodMenuHelper::findUnicFilename($path, $ext);
					if (JFile::copy($path.$image, $path.$filename)) {
						$db->setQuery('UPDATE `#__fwfoodmenu_menu` SET image = '.$db->quote($filename).' WHERE id = '.(int)$menu->id);
						$db->execute();
					}
				}
			}
			$this->setError(JText::_('FWFM_MENU_COPIED'));
			return $menu->id;
		} else $this->setError($menu->getError());
	}
    function copy() {
		$app = JFactory::getApplication();
		$input = $app->input;
        if ($cid = (array)$input->getVar('cid')) {
			jimport('joomla.filesystem.file');
			$db = JFactory::getDBO();
            $menu = $this->getTable('menu');
			$path = JPATH_SITE.'/media/com_fwfoodmenu/menu/';
            foreach ($cid as $id) {
                if ($menu->load($id)) {
					$menu->id = 0;
					$menu->ordering = 0;
					$menu->published = 0;
					$menu->name .= ' (copy)';
					if ($menu->check() and $menu->store()) {
						if ($menu->image and file_exists($path.$menu->image)) {
							$ext = strtolower(JFile::getExt($menu->image));
							$filename = fwFoodMenuHelper::findUnicFilename($path, $ext);
							if (JFile::copy($path.$menu->image, $path.$filename)) {
								$menu->image = $filename;
								$menu->store();
							}
						}
						if ($menu->_prices) {
							$db = JFactory::getDBO();
							foreach ($menu->_prices as $price) {
								$db->setQuery('INSERT INTO `#__fwfoodmenu_menu_price` SET menu_id = '.(int)$menu->id.', ordering = '.(int)$price->ordering.', name = '.$db->quote($price->name).', size = '.$db->quote($price->size).', price = '.$db->quote($price->price).', special_price = '.$db->quote($price->special_price).', energy = '.$db->quote($price->energy));
								$db->execute();
							}
						}
						$app->triggerEvent('copyMenuExtraFields', array('com_fwfoodmenu', $menu));
					} else $this->setError($menu->getError());
				}
            }
            $this->setError(JText::_('FWFM_MENU_COPIED'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_COPY'));
    }
    function remove() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
            $menu = $this->getTable('menu');
            foreach ($cid as $id) {
                $menu->delete($id);
            }
            $this->setError(JText::_('FWFM_MENU_REMOVED'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_REMOVE'));
    }
    function saveOrder() {
		$input = JFactory::getApplication()->input;
        $cid = $input->getVar('cid');
        $order = $input->getVar('order');

        if (is_array($cid) and is_array($order) and count($cid) and count($cid) == count($order)) {
            $db = JFactory::getDBO();
            foreach ($cid as $num=>$id) {
				$odering = (int)JArrayHelper::getValue($order, $num);
				$db->setQuery('UPDATE #__fwfoodmenu_menu SET ordering = '.$odering.' WHERE id = '.(int)$id);
				$db->execute();
            }
            $menu = $this->getTable('menu');
			$menu->reorder();
            return true;
        }
    }
    function orderDown() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid') and $id = JArrayHelper::getValue($cid, 0)) {
            $menu = $this->getTable('menu');
            $menu->load($id);
            $menu->move(1);
            return true;
        }
    }
    function orderup() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid') and $id = JArrayHelper::getValue($cid, 0)) {
            $menu = $this->getTable('menu');
            $menu->load($id);
            $menu->move(-1);
            return true;
        }
    }
    function publish() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
            $menu = $this->getTable('menu');
            $menu->publish($cid, 1);
            $this->setError(JText::_('FWFM_MENU_PUBLISHED'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_PUBLISH'));
    }
    function unPublish() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
            $menu = $this->getTable('menu');
            $menu->publish($cid, 0);
            $this->setError(JText::_('FWFM_MENU_UNPUBLISHED'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_UNPUBLISH'));
    }
    function mealDay() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
			JArrayHelper::toInteger($cid, 0);
			$db = JFactory::getDBO();
			$db->setQuery('UPDATE #__fwfoodmenu_menu SET is_meal_of_the_day = 1 WHERE id IN ('.implode(',', $cid).')');
			$db->execute();
            $this->setError(JText::_('FWFM_MENU_SET_AS_mealday'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_SET_AS_mealday'));
    }
    function unMealDay() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
			JArrayHelper::toInteger($cid, 0);
			$db = JFactory::getDBO();
			$db->setQuery('UPDATE #__fwfoodmenu_menu SET is_meal_of_the_day = 0 WHERE id IN ('.implode(',', $cid).')');
			$db->execute();
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_UNSET_AS_mealday'));
    }
    function asNew() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
			JArrayHelper::toInteger($cid, 0);
			$db = JFactory::getDBO();
			$db->setQuery('UPDATE #__fwfoodmenu_menu SET is_new = 1 WHERE id IN ('.implode(',', $cid).')');
			$db->execute();
            $this->setError(JText::_('FWFM_MENU_SET_AS_new'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_SET_AS_NEW'));
    }
    function unNew() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
			JArrayHelper::toInteger($cid, 0);
			$db = JFactory::getDBO();
			$db->setQuery('UPDATE #__fwfoodmenu_menu SET is_new = 0 WHERE id IN ('.implode(',', $cid).')');
			$db->execute();
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_UNSET_AS_NEW'));
    }
    function asrecommended() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
			JArrayHelper::toInteger($cid, 0);
			$db = JFactory::getDBO();
			$db->setQuery('UPDATE #__fwfoodmenu_menu SET is_recommended = 1 WHERE id IN ('.implode(',', $cid).')');
			$db->execute();
            $this->setError(JText::_('FWFM_MENU_SET_AS_RECOMMENDED'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_SET_AS_RECOMMENDED'));
    }
    function unrecommended() {
		$input = JFactory::getApplication()->input;
        if ($cid = (array)$input->getVar('cid')) {
			JArrayHelper::toInteger($cid, 0);
			$db = JFactory::getDBO();
			$db->setQuery('UPDATE #__fwfoodmenu_menu SET is_recommended = 0 WHERE id IN ('.implode(',', $cid).')');
			$db->execute();
            $this->setError(JText::_('FWFM_MENU_UNSET_AS_RECOMMENDED'));
            return true;
        }
        $this->setError(JText::_('FWFM_NO_MENU_ID_PASSED_TO_UNSET_AS_RECOMMENDED'));
    }
	function upload() {
        $menu = $this->getTable('menu');
		$input = JFactory::getApplication()->input;
        if ($id = $input->getInt('id') and !$menu->load($id)) $input->set('id', 0);

        if ($menu->bind($input->getArray(array(), null, 'RAW')) and $menu->check() and $menu->store()) {
            $menu->load($menu->id);
            return (object)array(
				'id' => $menu->id,
				'image' => fwFoodMenuHelper::getMenuImageUrl($menu)
			);
        } else {
        	$this->setError($menu->getError());
		}
	}
	function deleteImage() {
        $menu = $this->getTable('menu');
		$input = JFactory::getApplication()->input;
        if ($id = $input->getInt('id') and $menu->load($id)) {
			$input->set('delete_image', 1);
			if ($menu->check() and $menu->store()) {
				$menu->load($menu->id);
				return (object)array(
					'id' => $menu->id,
					'result' => 1,
					'image' => fwFoodMenuHelper::getMenuImageUrl($menu)
				);
			} else {
				$this->setError($menu->getError());
			}
		} else $this->setError(JText::_('FWFM_MENU_NOT_FOUND'));
	}
	function quickMeals() {
		$input = JFactory::getApplication()->input;
		if ($text = $input->getString('text')) {
			$db = JFactory::getDBO();
			$data = explode("\n", str_replace("\r", '', $text));

			$cid = $input->getInt('category');
			if (!$cid) {
				$this->setError(JText::_('FWFM_SELECT_CATEGORY'));
				return;
			}

			$updated = $added = 0;

			foreach ($data as $row) {
				$buff = explode('=', $row, 3);
				$name = trim($buff[0]);
				if (empty($name)) {
					continue;
				}

				$price = empty($buff[1])?'':trim($buff[1]);
				$descr = empty($buff[2])?'':('<p>'.trim($buff[2]).'</p>');

				$db->setQuery('
SELECT
	(SELECT id FROM #__fwfoodmenu_menu WHERE name = '.$db->quote($name).' AND category_id = '.(int)$cid.') AS mid,
	(SELECT MAX(ordering) FROM #__fwfoodmenu_menu WHERE category_id = '.(int)$cid.') AS ordering');
				if ($obj = $db->loadObject()) {
					$mid = $obj->mid;
					if ($mid) {
						if ($descr) {
							$db->setQuery('UPDATE #__fwfoodmenu_menu SET description = '.$db->quote($descr).' WHERE id = '.(int)$mid);
							$db->execute();
						}
						$updated++;
						if ($price > 0) {
							$db->setQuery('SELECT id FROM #__fwfoodmenu_menu_price WHERE menu_id = '.(int)$mid);
							if ($pid = $db->loadResult()) {
								$db->setQuery('UPDATE #__fwfoodmenu_menu_price SET price = '.$db->quote($price).' WHERE id = '.(int)$pid);
							} else {
								$db->setQuery('INSERT INTO #__fwfoodmenu_menu_price SET menu_id = '.(int)$mid.', price = '.$db->quote($price));
							}
							$db->execute();
						}
					} else {
						$db->setQuery('INSERT INTO #__fwfoodmenu_menu SET published = 1, name = '.$db->quote($name).', category_id = '.(int)$cid.', ordering = '.((int)$obj->ordering + 1).', description = '.$db->quote($descr));
						if ($db->execute()) {
							$added++;
							$mid = $db->insertid();
							$db->setQuery('INSERT INTO #__fwfoodmenu_menu_price SET menu_id = '.(int)$mid.', price = '.$db->quote($price));
							$db->execute();
						}
					}
				} else {
					$this->setError($db->getError());
				}
			}
			if ($added and $updated) {
				$this->setError(JText::sprintf('FWFM_MEAL_QUICK_IMPORT_RESULT_ADDED_EXISTED', $added, $updated));
			} elseif ($added) {
				$this->setError(JText::sprintf('FWFM_MEAL_QUICK_IMPORT_RESULT_ADDED', $added));
			} elseif ($updated) {
				$this->setError(JText::sprintf('FWFM_MEAL_QUICK_IMPORT_RESULT_EXISTED', $updated));
			} else {
				$this->setError(JText::_('FWFM_MEAL_QUICK_IMPORT_RESULT'));
			}
			return true;
		} else $this->setError(JText::_('FWFM_NOTHING_TO_PROCESS'));
	}
}
