<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class menuViewItems extends JViewLegacy {
	function display($tmpl=null) {
        $this->menu = 'items';
		$model = $this->getModel();
		$this->app = JFactory::getApplication();
		$this->input = $this->app->input;
		$this->params = JComponentHelper::getParams('com_fwfoodmenu');

		$this->fields = array('limit', 'limitstart', 'search', 'category');
		foreach ($this->fields as $field) {
			$this->$field = $this->input->getString($field);
		}
		switch ($this->getLayout()) {
			case 'edit' :
			$this->object = $model->loadObject();
			break;
			default :
			$this->add_url = '';
			$this->list = $model->loadList();
			$this->pagination = $model->getPagination();
			foreach ($this->fields as $field) {
				if ($this->$field) {
					$this->add_url .= '&amp;'.$field.'='.urlencode($this->$field);
					$this->pagination->setAdditionalUrlParam($field, $this->$field);
				}
			}
		}
		parent::display($tmpl);
	}
}
