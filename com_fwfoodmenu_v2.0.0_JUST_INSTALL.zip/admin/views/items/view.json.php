<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class menuViewItems extends JViewLegacy {
	function display($tmpl=null) {
		$model = $this->getModel();
		$this->app = JFactory::getApplication();
		$data = new stdclass;
		switch ($this->getLayout()) {
			case 'quick_meals' :
			$data->result = $model->quickMeals();
			$data->msg = implode('\\n', $model->getErrors());
			break;
			case 'upload' :
			$data = $model->upload();
			if (empty($data->id)) {
				$data->msg = $model->getError();
			}
			break;
			case 'delete_image' :
			$data = $model->deleteImage();
			if (empty($data->id)) {
				$data->msg = $model->getError();
			}
			break;
		}
		die(json_encode($data));
	}
}
