<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

$listDirn = 'asc';
$listOrder = 'ordering';
JHtml::_('sortablelist.sortable', 'fwfm-sizes', 'adminForm', strtolower($listDirn), '', false, true);
JHTML::_('formbehavior.chosen');

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));

JToolBarHelper::apply();
JToolBarHelper::save();
JToolBarHelper::save2New();
JToolBarHelper::save2Copy();
JToolBarHelper::cancel();

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => $this->object->id?'<i class="fal fa-utensils mr-1"></i> '.JText::sprintf('FWFM_MENU_EDIT_MENU', $this->object->name):'<i class="fal fa-utensils mr-1"></i> '.JText::_('FWFM_MENU_NEW_MENU'),
    'title_hint' => '',
	'view' => $this
), JPATH_COMPONENT);
$editor = JFactory::getEditor();
?>
<form id="adminForm" name="adminForm" method="post" action="index.php?option=com_fwfoodmenu&view=items" enctype="multipart/form-data">
	<div class="row fwa-mb-cardbox">
		<div class="col-lg-6 col-sm-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title"><?php echo JText::_('FWFM_MENU_Menu_item_details'); ?></h4>
				</div>
				<div class="card-block">
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_MENU_Published'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_MENU_Published_HINT_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_MENU_Published_HINT_title')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTML::_('fwView.radioGroup', 'published', $this->object->published, array(
								'wrapper_class' => 'mr-2',
								'buttons' => array(array(
									'active_class' => 'btn-success',
									'title' => JText::_('JYES'),
									'value' => 1
								), array(
									'active_class' => 'btn-danger',
									'title' => JText::_('JNO'),
									'value' => 0
								))
							)); ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix" for="fwfm-category-id">
							<?php echo JText::_('FWFM_MENU_CATEGORY'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_MENU_CATEGORY_HINT_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_MENU_CATEGORY_HINT_title')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTML::_('fwfCategory.parent', (object)array('category_id'=>$this->object->category_id), 'category_id', 'class="form-control advancedSelect"'); ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix" for="fwfm-name">
							<?php echo JText::_('FWFM_MENU_Name'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_MENU_NAME_HINT_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_MENU_NAME_HINT_title')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<input class="form-control" value="<?php echo $this->escape($this->object->name); ?>" id="fwfm-name" type="text" name="name"/>
						</div>
					</div>
<?php
$prices = '';
$this->app->triggerEvent('getMenuEditPrices', array('com_fwfoodmenu', $this, &$prices));
if ($prices) {
	echo $prices;
} else {
?>
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label clearfix" for="fwfm-name">
                            <?php echo JText::_('FWFM_MENU_Price'); ?>
                            <i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top"
                                data-content="<?php echo $this->escape(JText::_('FWFM_MENU_PRICE_HINT_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_MENU_PRICEHINT_title')); ?>"></i>
                        </label>
                        <div class="col-sm-7">
                            <div class="input-group">
<?php
	if (!$this->params->get('currency_after')) {
?>
                                <span class="input-group-addon"><?php echo $this->params->get('currency'); ?></span>
<?php
	}
?>
                                <input name="prices[0][price]" class="form-control" value="<?php if (!empty($this->object->_prices[0]->price)) echo $this->escape($this->object->_prices[0]->price); ?>" />
<?php
	if ($this->params->get('currency_after')) {
?>
                                <span class="input-group-addon"><?php echo $this->params->get('currency'); ?></span>
<?php
	}
?>
                            </div>
                        </div>
                    </div>
<?php
}
?>

                </div>
            </div>
            <div class="card">
				<div class="card-header">
					<h4 class="card-title"><?php echo JText::_('FWFM_MENU_Description'); ?></h4>
				</div>
				<div class="card-block">
                    <?php echo $editor->display('description', $this->object->description, '100%', 240, 60, 10, $buttons = false); ?>
                </div>
    		</div>
		</div>
		<div class="col-lg-6 col-sm-12">
<?php
$this->app->triggerEvent('showMenuEditExtraCardsRight', array('com_fwfoodmenu', $this));
?>
			</div>
		</div>
	</div>
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="id" value="<?php echo $this->object->id; ?>" />
    <input type="hidden" name="limitstart" value="<?php echo $this->input->getInt('limitstart'); ?>" />
<?php
foreach ($this->fields as $field) {
    if ($this->$field) {
?>
    <input type="hidden" name="<?php echo $field; ?>" value="<?php echo $this->escape($this->$field); ?>" />
<?php
    }
}
?>
</form>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
