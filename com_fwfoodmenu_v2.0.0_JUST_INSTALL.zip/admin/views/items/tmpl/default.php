<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));

JToolBarHelper::addNew();
JToolBarHelper::custom('quick', 'upload', 'upload', 'FWFM_QUICK_MEALS', false);
JToolBarHelper::publish();
JToolBarHelper::unpublish();
JToolBarHelper::editList();
JToolBarHelper::custom('copy', 'copy', 'copy', 'FWFM_COPY');
JToolBarHelper::deleteList(JText::_('FWFM_MENU_ARE_YOU_SURE'));

JHTML::_('formbehavior.chosen');

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-utensils mr-1"></i> '.JText::_('FWFM_MENU_MENU'),
    'title_hint' => JText::_('FWFM_MENU_MENU_ITEMS_HINT'),
	'view' => $this
), JPATH_COMPONENT);
?>
<form id="adminForm" name="adminForm" method="post" action="index.php?option=com_fwfoodmenu&view=items">
    <div class="fwa-filter-bar p-3 clearfix">
        <div class="float-left">
            <div class="input-group">
                <?php echo JHTML::_('fwfCategory.parent', (object)array('category'=>$this->category), 'category', 'class="form-control form-control-sm advancedSelect" onchange="with(this.form){limitstart.value=0;submit();}"', 'FWFM_SELECT_CATEGORY'); ?>
            </div>
        </div>
        <div class="float-left w-25 ml-3">
            <div class="input-group">
                <input class="form-control" placeholder="<?php echo JText::_('FWFM_SEARCH_NAME'); ?>" type="text" name="search" value="<?php echo $this->escape($this->search); ?>" />
                <span class="input-group-btn">
                    <button class="btn btn-secondary" type="button" onclick="with(this.form){limitstart.value=0;search.value='';submit();}"><i class="fal fa-times"></i></button>
                </span>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="submit"><i class="fal fa-search"></i></button>
                </span>
            </div>
        </div>
    </div>
	<table class="table table-striped">
		<thead>
			<tr>
				<th style="width:20px;"><input name="toggle" value="" onclick="Joomla.checkAll(this);" type="checkbox"></th>
<?php
$this->app->triggerEvent('showMenuListBeginExtraHeaders', array('com_fwfoodmenu', $this));
?>
				<th><?php echo JText::_('FWFM_MENU_Name'); ?></th>
				<th><?php echo JText::_('FWFM_MENU_Category'); ?></th>
				<th><?php echo JText::_('FWFM_MENU_Price'); ?></th>
<?php
$this->app->triggerEvent('showMenuListEndExtraHeaders', array('com_fwfoodmenu', $this));
?>
				<th><?php echo JText::_('FWFM_MENU_Order'); ?> <a href="javascript:saveorder(<?php echo count((array)$this->list) - 1; ?>, 'saveorder')" rel="tooltip" class="saveorder btn btn-sm" title="<?php echo $this->escape(JText::_('FWFM_MENU_Save_Order')); ?>"><span class="fal fa-save"></span></a></th>
				<th><?php echo JText::_('FWFM_MENU_Published'); ?></th>
			</tr>
		</thead>
		<tbody>
<?php
if ($this->list) {
	foreach ($this->list as $num=>$row) {
		$price_col = '';
		$this->app->triggerEvent('getMenuListPriceColumn', array('com_fwfoodmenu', $this, $row, $num, &$price_col));
?>
			<tr>
				<td><?php echo JHTML :: _('grid.id', $num, $row->id); ?></td>
<?php
		$this->app->triggerEvent('showMenuListBeginExtraColumns', array('com_fwfoodmenu', $this, $row, $num));
?>
				<td>
					<a href="index.php?option=com_fwfoodmenu&amp;view=items&amp;task=edit&amp;cid[]=<?php echo $row->id.$this->add_url; ?>">
						<?php echo $row->name; ?>
					</a>
				</td>
				<td><?php echo $row->_category_name; ?></td>
				<td>
<?php
		if ($price_col) {
			echo $price_col;
		} elseif (!empty($row->_prices[0]->price)) {
			echo fwFoodMenuHelper::formatPrice($row->_prices[0]->price);
		}
?>
                </td>
<?php
		$this->app->triggerEvent('showMenuListEndExtraColumns', array('com_fwfoodmenu', $this, $row, $num));
?>
				<td class="order">
					<?php echo JHTMLfwView::orderingListLinks(array(
						'num' => $num,
						'value' => $row->ordering,
						'display_up' => ($num > 0),
						'display_down' => (($num + 1) < count($this->list))
					)); ?>
				</td>
				<td>
					<?php echo JHTMLfwView::booleanListLink(array(
						'num' => $num,
						'value' => $row->published,
						'task_on' => 'publish',
						'task_off' => 'unpublish',
						'title_on' => JText::_('FWFM_MENU_PUBLISH'),
						'title_off' => JText::_('FWFM_MENU_UNPUBLISH')
					)); ?>
				</td>
			</tr>
<?php
	}
} else {

}
?>
		</tbody>
	</table>
	<div class="row">
		<div class="col-md-9">
			<?php echo $this->pagination->getListFooter(); ?>
		</div>
		<div class="col-md-3 mt-4">
			<?php echo $this->pagination->getLimitBox(); ?>
		</div>
	</div>
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="task" value="" />
</form>
<div id="fwfm-quick-meals" class="modal fade">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo JText::_('FWFM_QUICK_meals'); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<?php echo JHTML::_('fwfCategory.parent', (object)array('category'=>$this->category), 'category', 'class="form-control form-control-sm advancedSelect"', 'FWFM_SELECT_CATEGORY'); ?>
		<br />
		<textarea name="quick_meals" class="form-control" placeholder="<?php echo $this->escape(JText::_('FWFM_QUICK_MEALS_HINT')); ?>"></textarea>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary"><?php echo JText::_('FWFM_SAVE'); ?></button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo JText::_('FWFM_CLOSE'); ?></button>
      </div>
    </div>
  </div>
</div>
<script>
Joomla.submitbutton = function(pressbutton) {
	if (pressbutton == 'quick') {
		jQuery('#fwfm-quick-meals').modal('show');
		return;
	}
	document.adminForm.task.value=pressbutton;
	document.adminForm.submit();
}

jQuery(function($) {
	$('#fwfm-quick-meals').on('show', function() {
		$(this).addClass('show');
		$(this).find('textarea').val('');
	}).on('hide', function() {
		$(this).removeClass('show');
	});
	$('#toolbar-upload button').addClass('btn-primary');
	$('#fwfm-quick-meals button.btn-primary').click(function() {
		var $btn = $(this).attr('disabled', true);
		var $popup = $('#fwfm-quick-meals');
		$.ajax({
			dataType: 'json',
			data: {
				format: 'json',
				task: '',
				layout: 'quick_meals',
				category: $popup.find('select[name="category"]').val(),
				text: $popup.find('textarea').val()
			}
		}).done(function(data) {
			$btn.attr('disabled', false);
			if (data.msg) {
				alert(data.msg);
			}
			if (data.result) {
				location=location.toString().replace('#.*$', '')+'<?php echo str_replace('&amp;', '&', $this->add_url); ?>';
			}
		});
	});
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
