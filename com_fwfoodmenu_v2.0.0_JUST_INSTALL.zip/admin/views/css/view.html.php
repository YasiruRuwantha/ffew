<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class menuViewcss extends JViewLegacy {
	function display($tmpl=null) {
		$this->menu = 'css';
		$model = $this->getModel();
		$this->setLayout('default');
		$this->editor = $model->getEditor();
		$this->object = $model->loadObject();
		
		$this->path = JPATH_COMPONENT_SITE.'/assets/css/fwfm-design-styles.css';
		$this->content = file_get_contents($this->path);
		$this->contents = $model->getTmplPluginsCss();
		parent::display($tmpl);
	}
}
