<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));
JToolBarHelper::apply();

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-paint-brush-alt mr-1"></i> '.JText::_('FWFM_MENU_STYLES'),
    'title_hint' => JText::_('FWFM_MENU_STYLES_HINT'),
	'view' => $this
), JPATH_COMPONENT);
?>
				<form id="adminForm" name="adminForm" class="css-styles" method="post" action="index.php?option=com_fwfoodmenu&view=css" enctype="multipart/form-data">
                    <div class="fwa-filter-bar">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#fwfm-custom-css" role="tab"><?php echo JText::_('FWFM_CUSTOM_CSS') ?></a></li>
    						<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#fwfm-foodmenu-css" role="tab"><?php echo JText::_('FWFM_FOODMENU_CSS') ?></a></li>
<?php
if ($this->contents) {
	foreach ($this->contents as $row) {
?>
    						<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#fwfm-foodmenu-<?php echo $row->element; ?>" role="tab"><?php echo JText::_('FW_FOODMENU_'.$row->element); ?></a></li>
<?php
	}
}
?>
    					</ul>
                    </div>
					<div class="tab-content">
                        <div class="tab-pane active" id="fwfm-custom-css" role="tabpanel" aria-expanded="false">
							<div class="row fwa-mb-cardbox">
								<div class="col-12">
									<div class="card">
										<div class="card-header">
											<div class="card-subtitle"><?php echo JText::_('FWFM_CUSTOM_CSS_HINT'); ?></div>
										</div>
										<div class="card-block">
											<?php echo $this->editor->display('config[additional_css]', $this->object->params->get('additional_css'), 600, 400, 80, 7, false); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="fwfm-foodmenu-css" role="tabpanel" aria-expanded="true">
							<div class="row fwa-mb-cardbox">
								<div class="col-12">
									<div class="card">
										<div class="card-header">
											<div class="card-subtitle pb-2"><?php echo JText::sprintf('FWFM_FOODMENU_CSS_HINT'); ?></div>
                                            <div class="card-subtitle"><?php echo str_replace('\\', '/', $this->path); ?></div>
										</div>
										<div class="card-block">
											<?php echo $this->editor->display('none', $this->content, 600, 400, 80, 7, false, $id = null, $asset = null, $author = null, $params = array('readonly'=>true)); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
<?php
if ($this->contents) {
	foreach ($this->contents as $row) {
?>
						<div class="tab-pane" id="fwfm-foodmenu-<?php echo $row->element; ?>" role="tabpanel" aria-expanded="true">
							<div class="row fwa-mb-cardbox">
								<div class="col-12">
									<div class="card">
										<div class="card-header">
											<div class="card-subtitle pb-2"><?php echo JText::sprintf('FWFM_FOODMENU_CSS_HINT'); ?></div>
                                            <div class="card-subtitle"><?php echo str_replace('\\', '/', $row->path); ?></div>
										</div>
										<div class="card-block">
											<?php echo $this->editor->display($row->element, $row->content, 600, 400, 80, 7, false, $id = null, $asset = null, $author = null, $params = array('readonly'=>true)); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
<?php
	}
}
?>
					</div>
					<input type="hidden" name="task" value="" />
					<input type="hidden" name="id" value="1" />
				</form>
<script>
jQuery(function($) {
	$('a[data-toggle="tab"]').on('show', function() {
		var $link = $(this);
		$link.closest('ul').find('.active').removeClass('active');
		$link.addClass('active');
	});
	$('a[data-toggle="tab"]').click(function() {
		$('.CodeMirror').each(function(i, el){
			setTimeout(function() {
				el.CodeMirror.refresh();
			}, 100);
		});
	});
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
