<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

class menuViewAddon extends JViewLegacy {
    function display($tmpl = null) {
        $app = JFactory::getApplication();
        $model = $this->getModel();

        $data = new stdclass;
        switch ($this->getLayout()) {
			case 'get_cart' :
			$data->result = $model->loadCart();
			break;
			case 'buy' :
			$data->result = $model->addCart();
			break;
            case 'install' :
			$data->result = $model->install();
			break;
            case 'update' :
			$data->result = $model->install(true);
			break;
            case 'enable' :
			$data->result = $model->enable();
			break;
            case 'disable' :
            $data->result = $model->disable();
            break;
        }
        $data->msg = implode("\n", $model->getErrors());
        die(json_encode($data));
    }
}
