<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-puzzle-piece mr-1"></i> '.JText::_('FWFM_ADDONS'),
    'title_hint' => JText::_('FWFM_ADDONS_HINT'),
	'view' => $this
), JPATH_COMPONENT);
?>
<form action="index.php?option=com_fwfoodmenu&amp;view=addon" id="adminForm" name="adminForm" method="post">
<?php
if ($this->list) {
	foreach ($this->list as $row) {
		if (in_array($row->update_name, array('com_fwfoodmenu', 'FW Food Menu')) and $row->loc_version and $row->rem_version and $row->loc_version != 'x.x.x' and $row->loc_version != $row->rem_version) {
?>
	<div class="alert alert-notice">
		<?php echo JText::sprintf('FWFM_YOU_CAN_UPDATE_MAIN_COMPONENT_FROM_TO_VERSION', $row->loc_version, $row->rem_version); ?>
		<button class="btn fwfm-action" type="button" data-ext="com_fwfoodmenu" data-action="update">
			<i class="fal fa-sync-alt"></i>
		</button>
	</div>
<?php
			$loc_buff = explode('.', $row->loc_version, 3);
			$rem_buff = explode('.', $row->rem_version, 3);
			if ($loc_buff[0] != $rem_buff[0]) {
?>
	<div class="alert alert-danger">
		<?php echo JText::_('FWA_MAJOR_RELEASE_TITLE'); ?><br />
		<?php echo JText::_('FWA_MAJOR_RELEASE_IMPACT'); ?>
	</div>
<?php
			} elseif (isset($loc_buff[1]) and isset($rem_buff[1]) and $loc_buff[1] != $rem_buff[1]) {
?>
	<div class="alert alert-warning">
		<?php echo JText::_('FWA_MINOR_RELEASE_TITLE'); ?><br />
		<?php echo JText::_('FWA_MINOR_RELEASE_IMPACT'); ?>
	</div>
<?php
			} else {
?>
	<div class="alert alert-success">
		<?php echo JText::_('FWA_MAINTENACE_RELEASE_TITLE'); ?><br />
		<?php echo JText::_('FWA_MAINTENACE_RELEASE_IMPACT'); ?>
	</div>
<?php
			}
			break;
		}
	}
}
?>
	<div class="fwa-filter-bar fwa-filter-bar-addons row">
		<div class="col-md-8 col-lg-9">
            <div class="d-inline-block">
                <select class="frm-control" name="type">
                    <option value="all"><?php echo JText::_('FWFM_ANY_TYPE'); ?></option>
                    <option value="design"><?php echo JText::_('FWFM_DESIGN'); ?></option>
                    <option value="plugin"><?php echo JText::_('FWFM_PLUGIN'); ?></option>
                    <option value="module"><?php echo JText::_('FWFM_MODULE'); ?></option>
                    <option value="component"><?php echo JText::_('FWFM_COMPONENT'); ?></option>
<?php
if (!empty($this->deals)) {
?>
                    <option value="deal"><?php echo JText::_('FWFM_DEALS'); ?></option>
<?php
}
?>
                </select>
            </div>
            <div class="d-inline-block">
                <select class="frm-control" name="status">
                    <option value="all"><?php echo JText::_('FWFM_ANY_STATUS'); ?></option>
                    <option value="enabled"><?php echo JText::_('FWFM_ENABLED'); ?></option>
                    <option value="disabled"><?php echo JText::_('FWFM_DISABLED'); ?></option>
                </select>
            </div>
            <button type="button" class="btn btn-primary"><i class="fal fa-filter mr-2"></i> <?php echo JText::_('FWFM_FILTER'); ?></button>
<?php
if ($this->have_not_installed) {
?>
            <button type="button" class="btn btn-success"><i class="fal fa-download mr-2"></i> <?php echo JText::_('FWFM_INSTALL_ALL'); ?></button>
<?php
}
if ($this->have_not_updated) {
?>
            <button type="button" class="btn btn-warning ml-4"><i class="fal fa-sync-alt mr-2"></i> <?php echo JText::_('FWFM_UPDATE_ALL'); ?></button>
<?php
}
?>
		</div>
		<div class="col-md-4 col-lg-3 text-center" style="display:none;">
			<i class="fal fa-shopping-cart"></i>
			<span class="fw-cart-total">$0 USD</span>
			<span class="fw-cart-items">(0 items)</span>
			<a class="btn btn-success ml-2" href="<?php echo FWA_UPDATE_SERVER; ?>?access_code=<?php echo urlencode($this->params->get('update_code')) ?>#cart" target="_blank"><?php echo JText::_('FWFM_CHECKOUT'); ?></a>
		</div>
<script>
jQuery(function($) {
	$.ajax({
		dataType: 'json',
		data: {
			format: 'json',
			layout: 'get_cart'
		}
	}).done(function(data) {
		var $total = $('.fw-cart-total').html('');
		var $qty = $('.fw-cart-items').html('');
		var $wrp = $total.parent().hide();
		if (data.result && data.result.list) {
			$total.html(data.result.total_formatted);
			$qty.html('('+data.result.list.length+')');
			$wrp.show();
		}
		if (data.msg) {
			alert(data.msg);
		}
	});
});
</script>
	</div>
    <div class="fwshop-items-wrapper">
		<div class="row fwa-mb-cardbox fwshop-items">
<?php
if ($this->list) {
	foreach ($this->list as $row) {
		if (in_array($row->update_name, array('com_fwfoodmenu', 'FW Food Menu'))) {
			continue;
		}
		$classes = array('col-md-6 col-lg-3 fwshop-item filtr-item');
		$classes[] = strtolower($row->subtype);

		$image = $row->image?$row->image:(JURI::root(true).'/administrator/components/com_fwfoodmenu/assets/images/'.$row->update_name.'.jpg');

		$action = $action_button = '';
		$category = array($row->subtype);
		if ($row->installed) {
			$category[] = 'installed';
			if ($row->loc_version and $row->rem_version and $row->loc_version != 'x.x.x' and $row->loc_version != $row->rem_version) {
				$category[] = 'update';
				$action = 'update';
				$action_button = 'fa-sync-alt';
			} elseif ($row->enabled) {
				$category[] = 'enabled';
				$action = 'disable';
				$action_button = 'fa-trash-alt';
			} else {
				$category[] = 'disabled';
				$action = 'enable';
				$action_button = 'fa-check';
			}
		} else {
			if (!empty($row->installable)) {
				$category[] = 'available';
				$action = 'install';
				$action_button = 'fa-download';
			} else {
				$category[] = 'buy';
				$action = 'buy';
				$action_button = 'fa-shopping-cart';
			}
		}
?>
			<div class="<?php echo implode(' ', $classes); ?> type-<?php echo str_replace('datatype', 'data-type', $row->subtype); ?>" data-category="<?php echo implode(',', $category) ?>">
				<div class="card">
					<div class="card-img-top">
						<img class="card-img-top" src="<?php echo $image; ?>">
						<div class="fwshop-item-type">
							<?php echo JText::_('FWFM_'.$row->subtype); ?>
						</div>
						<div class="fwshop-item-hover">
							<div>
								<?php echo $row->description; ?>
							</div>
<?php
		if (!empty($row->frontend_demo_link)) {
?>
							<a class="btn btn-secondary" href="<?php echo $row->frontend_demo_link; ?>"><?php echo JText::_('FWFM_DEMO'); ?></a>
<?php
		}
?>
						</div>

					</div>
					<div class="card-block">
						<div class="col-9">
							<div class="card-title">
								<?php echo JText::_($row->name); ?>
							</div>
							<div class="card-hint">
								<?php echo ltrim(strip_tags($row->description)," \t\n"); ?>
							</div>
						</div>
						<div class="col-3">
							<button class="btn fwfm-action fwfm-action-<?php echo $action; ?>" type="button" data-ext="<?php echo $row->update_name; ?>" data-action="<?php echo $action; ?>">
<?php
		if ($action == 'buy') {
			?>$<?php
			echo number_format($row->price, 2);
		} else {
?>
								<i class="fal <?php echo $action_button; ?>"></i>
<?php
		}
?>
							</button>
							<div class="fwfm-action-text">
								<?php echo JText::_('FWFM_ADDONS_STATUS_'.$action);  ?>
							</div>
						</div>
					</div>

				</div>
			</div>
<?php
	}
}
if (!empty($this->deals)) {
	foreach ($this->deals as $deal) {
		$price = $deal->_price;
		if ($deal->amount != 0) {
			if ($deal->is_percent) {
				$price = round(($price * (100 - $deal->amount))/100, 2);
			} else {
				$price = max(0, $price - $deal->amount);
			}
		}
?>
			<div class="col-md-6 col-lg-3 fwshop-item filtr-item type-deal" data-category="buy">
				<div class="card">
					<div class="card-img-top">
						<img class="card-img-top" src="<?php echo $deal->image; ?>" />
						<div class="fwshop-item-type">
							<?php echo JText::_('FWFM_DEAL'); ?>
						</div>
						<div class="fwshop-item-hover">
							<div>
								<?php echo $deal->description; ?>
							</div>
						</div>
					</div>
					<div class="card-block">
						<div class="col-9">
							<div class="card-title">
								<?php echo JText::_($deal->name); ?>
							</div>
							<div class="card-hint">
								<?php echo ltrim(strip_tags($deal->description)," \t\n"); ?>
							</div>
						</div>
						<div class="col-3">
							<button class="btn fwfm-action fwfm-action-buy" type="button" data-ext="deal-<?php echo $deal->id; ?>" data-action="buy">
								$<?php echo number_format($price, 2); ?>
							</button>
							<div class="fwfm-action-text">
								<?php echo JText::_('FWFM_ADDONS_STATUS_BUY');  ?>
							</div>
						</div>
					</div>
				</div>
			</div>

<?php
	}
}
?>
		</div>
    </div>
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="" />
</form>
<script>
jQuery(function($) {
	$('button.fwfm-action').click(function() {
		var $btn = $(this);
		if ($btn.attr('disabled')) return;

		var action = $btn.data('action');
		if (action == 'buy') {
			$btn.attr('disabled', true);
			var $img = $('<img/>', {
				'src' : '<?php echo JURI::root(true); ?>/components/com_fwfoodmenu/assets/images/ajax-loader.gif',
				'style': 'height:auto;width:auto;position:absolute;margin:9px -65px;'
			});
			$btn.after($img);
			$.ajax({
				dataType: 'json',
				data: {
					format: 'json',
					layout: action,
					ext: [$btn.data('ext')]
				}
			}).done(function(data) {
				$img.remove();
				$btn.attr('disabled', false);

				var $total = $('.fw-cart-total').html('');
				var $qty = $('.fw-cart-items').html('');
				var $wrp = $total.parent().hide();
				if (data.result && data.result.list) {
					$total.html(data.result.total_formatted);
					$qty.html('('+data.result.list.length+')');
					$wrp.show();
				}
				if (data.msg) {
					alert(data.msg);
				}

			});
			return;
		} else if (action == 'disable') {
			var $wrapper = $btn.closest('.card-block');
			var name = $wrapper.find('.card-title').html().trim();
			if (!confirm('<?php echo JText::_('FWFM_DO_YOU_REALLY_WANT_REMOVE', true); ?> "'+name+'"')) return;
		}

		$btn.attr('disabled', true);
		var $img = $('<img/>', {
			'src' : '<?php echo JURI::root(true); ?>/components/com_fwfoodmenu/assets/images/ajax-loader.gif',
			'style': 'height:auto;width:auto;position:absolute;margin:9px -65px;'
		});
		$btn.after($img);
		$.ajax({
			dataType: 'json',
			data: {
				format: 'json',
				layout: action,
				ext: [$btn.data('ext')]
			}
		}).done(function(data) {
			$btn.attr('disabled', false);
			$img.remove();
			if (data.result) {
				var row = data.result;
				$btn.data('action', row.action);
				$btn.parent().find('.fwfm-action-text').html(row.title);
				$btn.find('i').attr('class', 'fal fa-'+row.icon);
			}
		});
	});
	$('.fwa-filter-bar-addons button').click(function() {
		var filters = [];

		$('.fwa-filter-bar-addons select').each(function() {
			if (this.value != 'all') filters.push(this.value);
		});
		if (filters) {
			$('.fwshop-items .fwshop-item').each(function() {
				var $el = $(this);
				var cats = $el.data('category').split(',');
				var hide_el = false;
				for (var i = 0; i < filters.length; i++) {
					if (cats.indexOf(filters[i]) == -1) {
						hide_el = true;
						break;
					}
				}
				if (hide_el) {
					$el.hide(300);
				} else {
					$el.show(300);
				}
			});
		} else {
			$('.fwshop-items .fwshop-item').show(300);
		}
	});
	$('.fwa-filter-bar-addons').on('click', 'button:has(".fa-download")', function() {
		$('button.fwfm-action[data-action="install"]').click();
	});
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
