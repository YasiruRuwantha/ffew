<?php
/**
 * FW Food menu 2.0.0
 * @copyright C 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

class menuViewAddon extends JViewLegacy {
    function display($tmpl = null) {
        $this->menu = 'addon';
        $model = $this->getModel();

        JHTML::_('behavior.core');
        $this->app = JFactory::getApplication();
		$this->params = JComponentHelper::getParams('com_fwfoodmenu');

		$this->list = $model->getPluginsData();
		$this->deals = $model->getDeals();
		$this->have_not_installed = $model->checkNotInstalled($this->list);
		$this->have_not_updated = $model->checkNotUpdated($this->list);
        parent::display();
    }
}
