<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

class menuViewData extends JViewLegacy {
    function display($tmpl=null) {
		$this->menu = 'data';
		$model = $this->getModel();

		if ($this->getLayout() == 'edit') {
			if ($plugin = $model->getPlugin()) {
				if (!headers_sent()) {
					header("Expires: Tue, 1 Jul 2003 05:00:00 GMT");
					header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
					header("Cache-Control: no-store, no-cache, must-revalidate");
					header("Pragma: no-cache");
				}
				ob_implicit_flush();
				$model->processPlugin($plugin);
			}
		} else {
			$this->backups = $model->getBackupsList();
			$this->plugins = $model->getPlugins();
			parent:: display($tmpl);
		}
	}
}
