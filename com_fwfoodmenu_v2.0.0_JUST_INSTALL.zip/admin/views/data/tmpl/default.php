<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-database mr-1"></i> '.JText::_('FWFM_DATA_MANAGEMENT'),
    'title_hint' => JText::_('FWFM_DATA_MANAGEMENT_HINT'),
	'view' => $this
), JPATH_COMPONENT);
?>
<div class="fwa-filter-bar">
    <ul class="nav nav-tabs" role="tablist">
    	<li class="nav-item">
    		<a class="nav-link active" data-toggle="tab" href="#fwfm-restore" role="tab"><?php echo JText::_('FWFM_RESTORE'); ?></a>
    	</li>
    	<li class="nav-item">
    		<a class="nav-link" data-toggle="tab" href="#fwfm-backup" role="tab"><?php echo JText::_('FWFM_BACKUP'); ?></a>
    	</li>
<?php
if ($this->plugins) {
?>
    	<li class="nav-item">
    		<a class="nav-link" data-toggle="tab" href="#fwfm-data" role="tab"><?php echo JText::_('FWFM_DATA_IMPORT_PLUGINS'); ?></a>
    	</li>
<?php
}
?>
    </ul>
</div>
<div class="tab-content">
	<div class="tab-pane active" id="fwfm-restore" role="tabpanel">
		<div class="container-fluid fwa-main-body">
			<form action="index.php?option=com_fwfoodmenu&amp;view=data" method="post" name="adminForm">
				<div class="row fwa-mb-cardbox">
					<div class="col-lg-6 col-sm-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title"><?php echo JText::_('FWFM_RESTORE'); ?></h4>
								<div class="card-subtitle"><?php echo JText::_('FWFM_RESTORE_HINT'); ?> <?php echo str_replace('\\', '/', JPATH_SITE); ?>media/com_fwfoodmenu/backups</div>
							</div>
							<div class="card-block">
								<table class="table">
									<tbody id="fwfm-import-files">
<?php
if ($this->backups) {
	foreach ($this->backups as $file) {
?>
										<tr>
											<td><a href="<?php echo JURI::root(true); ?>/media/com_fwfoodmenu/backups/<?php echo $file; ?>"><?php echo $file; ?></a></td>
											<td>
												<button type="button" class="btn btn-primary"><?php echo JText::_('FWFM_RESTORE'); ?></button>
												<button type="button" class="btn btn-danger"><?php echo JText::_('FWFM_DELETE'); ?></button>
											</td>
										</tr>
<?php
	}
}
?>
									</tbody>
								</table>

								<div class="mt-5"><?php echo JText::_('FWFM_IMPORT_UPLOAD_HINT'); ?></div>
								<label class="custom-file">
									<span>
										<input class="custom-file-input" type="file" id="fwfm-input-import" name="upload">
									</span>
									<span class="custom-file-control"></span>
								</label>
								<button type="button" class="btn btn-success" id="fwfm-import-upload"><i class="fa fa-upload mr-2"></i><?php echo JText::_('FWFM_UPLOAD'); ?></button>
								<div class="mt-2 fwfm-data-import-result"></div>
								<?php echo JHTML::_('fwView.handleUploadButton', array(
									'button' => '#fwfm-import-upload',
									'input' => '#fwfm-input-import',
									'image' => '',
									'exts' => array('zip'),
									'layout' => 'backup_upload',
									'callback' => 'function(html) {
	$progress_bar.remove();
	$button.attr(\'disabled\', false);
	$input.next().html(\''.JText::_('FWFM_CHOOSE_FILE', false).'\');

	var $parent = $input.parent();
	var input_html = $parent.html();
	$parent.html(input_html);

	var $cont = $(\'#fwfm-import-files\');
	var data = $.parseJSON(html);
	if (data) {
		if (data.result) {
			$(\'.fwfm-data-import-result\').html(\''.JText::_('FWFM_EXPORT_FILE_CREATED', true).'\'+data.result);
			var $row = $(\'<tr>\\
	<td><a href="'.JURI::root(true).'/media/com_fwfoodmenu/backups/\'+data.result+\'">\'+data.result+\'</a></td>\\
	<td>\\
		<button type="button" class="btn btn-primary">'.JText::_('FWFM_RESTORE', true).'</button>\\
		<button type="button" class="btn btn-danger">'.JText::_('FWFM_DELETE', true).'</button>\\
	</td>\\
</tr>\');
			$(\'#fwfm-import-files\').append($row);
		}
		if (data.msg) alert(data.msg);
	}
}'
								)); ?>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="tab-pane" id="fwfm-backup" role="tabpanel">
		<div class="container-fluid fwa-main-body">
			<form action="index.php?option=com_fwfoodmenu&amp;view=data" method="post" name="adminForm">
				<div class="row fwa-mb-cardbox">
					<div class="col-lg-6 col-sm-12">
						<div class="card">
							<div class="card-header">
								<h4 class="card-title"><?php echo JText::_('FWFM_BACKUP'); ?></h4>
								<div class="card-subtitle"><?php echo JText::_('FWFM_BACKUP_HINT'); ?> <?php echo str_replace('\\', '/', JPATH_SITE); ?>media/com_fwfoodmenu/backups</div>
							</div>
							<div class="card-block">
								<div class="form-group row">
									<label class="col-sm-5 col-form-label clearfix">
										<?php echo JText::_('FWFM_CHOOSE_WHAT_BACKUP'); ?>
										<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" title="<?php echo $this->escape(JText::_('FWFM_CHOOSE_WHAT_BACKUP_TITLE')); ?>" data-content="<?php echo $this->escape(JText::_('FWFM_CHOOSE_WHAT_BACKUP_HINT')); ?>"></i>
									</label>
									<div class="col-sm-7">
										<div class="form-group">
											<input type="checkbox" id="fwfm-pdata" name="pdata" value="1" checked="checked" disabled="disabled" />
											<label for="fwfm-pdata"><?php echo JText::_('FWFM_MENU_DATA'); ?></label>
										</div>
										<div class="form-group">
											<input type="checkbox" id="fwfm-pimages" name="pimages" value="1" checked="checked" />
											<label for="fwfm-pimages"><?php echo JText::_('FWFM_MENU_FILES'); ?></label>
										</div>
									</div>
								</div>
								<button type="button" id="fwfm-data-export" class="btn btn-success"><i class="fa fa-upload mr-2"></i><?php echo JText::_('FWFM_BACKUP'); ?></button>
								<div class="mt-2 fwfm-data-export-result"></div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
<?php
if ($this->plugins) {
?>
	<div class="tab-pane" id="fwfm-data" role="tabpanel">
		<div class="container-fluid fwa-main-body fwa-mb-cardbox">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title"><?php echo JText::_('FWFM_DATA_IMPORT_PLUGINS'); ?></h4>
					<div class="card-subtitle"><?php echo JText::_('FWFM_DATA_IMPORT_PLUGINS_HINT'); ?></div>
				</div>
				<div class="card-block">
					<div class="row">
						<div class="col-lg-6 col-sm-12">
<?php
	$qty = count($this->plugins);
	$half = round($qty/2);
	foreach ($this->plugins as $i=>$plugin) {
		if ($i and $i%2 == 0) {
?>
						</div>
						<div class="col-lg-6 col-sm-12">
<?php
		}
		if ($plugin) {
?>
							<fieldset class="adminform">
								<?php echo $plugin; ?>
							</fieldset>
<?php
		}
	}
?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
}
?>
</div>
<script>
jQuery(function($) {
	$('#fwfm-import-files').on('click', '.btn-primary', function() {
		var $row = $(this).closest('tr');
		var file = $(this).closest('td').prev().html();
		var $output = $('.fwfm-data-import-result').html('');
		if (confirm('<?php echo JText::_('FWFM_ARE_YOU_SURE_BACKUP_RESTORE', true); ?> '+file)) {
			$('#fwfm-import-files').find('button').attr('disabled', true);
			$output.html('<?php echo JText::_('FWFM_BACKUP_UNPACKING_AND_APPLYING', true); ?>');
			$.ajax({
				dataType: 'json',
				data: {
					format: 'json',
					layout: 'backup_restore',
					filename: file
				}
			}).done(function (data) {
				$('#fwfm-import-files').find('button').attr('disabled', false);
				if (data.result) {
					$output.html('<?php echo JText::_('FWFM_BACKUP_SUCCESFULLY_INSTALLED', true); ?>');
				}
				if (data.msg) {
					$output.html(data.msg);
				}
			});
		}
	}).on('click', '.btn-danger', function() {
		var $row = $(this).closest('tr');
		var file = $(this).closest('td').prev().find('a').html();
		var $output = $('.fwfm-data-import-result').html('');
		if (confirm('<?php echo JText::_('FWFM_ARE_YOU_SURE_BACKUP_DELETE', true); ?> '+file)) {
			$row.find('button').attr('disabled', true);
			$.ajax({
				dataType: 'json',
				data: {
					format: 'json',
					layout: 'backup_delete',
					filename: file
				}
			}).done(function (data) {
				$row.find('button').attr('disabled', false);
				if (data.result) {
					$row.remove();
				}
				if (data.msg) {
					$output.html(data.msg);
				}
			});
		}
	});
	$('#fwfm-data-export').click(function() {
		var $btn = $(this);
		var $form = $(this.form);

		var $output = $('.fwfm-data-export-result').html('');
		if ($form.find('input:checked').length) {
			$btn.attr('disabled', true);
			$output.html('<?php echo JText::_('FWFM_EXPORT_DATABASE_DATA', true); ?>');
			$.ajax({
				dataType: 'json',
				data: {
					format: 'json',
					layout: 'export_data'
				}
			}).done(function(data) {
				if (data.result) {
					var images = $form.find('input[name="pimages"]:checked').length;
					$output.html(images?'<?php echo JText::_('FWFM_ZIPPING_DATA_IMAGES', true); ?>':'<?php echo JText::_('FWFM_ZIPPING_DATA', true); ?>');
					$.ajax({
						dataType: 'json',
						data: {
							format: 'json',
							layout: 'store_export_data',
							images: images,
							folder: data.result
						}
					}).done(function(data) {
						$btn.attr('disabled', false);
						if (data.result) {
							$output.html('<?php echo JText::_('FWFM_EXPORT_FILE_CREATED', true); ?> <a href="<?php echo JURI::root(true); ?>/media/com_fwfoodmenu/backups/'+data.result+'">'+data.result+'</a>');
							var $raw = $('<tr>\
	<td><a href="<?php echo JURI::root(true); ?>/media/com_fwfoodmenu/backups/'+data.result+'">'+data.result+'</a></td>\
	<td>\
		<button type="button" class="btn btn-primary"><?php echo JText::_('FWFM_RESTORE', true); ?></button>\
		<button type="button" class="btn btn-danger"><?php echo JText::_('FWFM_DELETE', true); ?></button>\
	</td>\
</tr>');
							$('#fwfm-import-files').append($raw);
						}
						if (data.msg) {
							$output.html(data.msg);
						}
					});
				}
				if (data.msg) {
					$output.html(data.msg);
				}
			});
		} else {
			$output.html('<?php echo JText::_('FWFM_SELECT_WHAT_TO_EXPORT', true); ?>');
		}
	});
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
