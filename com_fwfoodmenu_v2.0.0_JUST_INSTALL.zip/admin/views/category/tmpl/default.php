<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

JHTML::_('formbehavior.chosen');

JToolBarHelper::title(JText::_('FWFM_CATEGORY_FW_FOOD_MENU'));

JToolBarHelper::addNew();
JToolBarHelper::custom('quick', 'upload', 'upload', 'FWFM_QUICK_CATEGORIES', false);
JToolBarHelper::publish();
JToolBarHelper::unpublish();
JToolBarHelper::editList();
JToolBarHelper::custom('copy', 'copy', 'copy', 'FWFM_COPY');
JToolBarHelper::deleteList(JText::_('FWFM_CATEGORY_ARE_YOU_SURE'));

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-folder mr-1"></i> '.JText::_('FWFM_CATEGORY_CATEGORY'),
    'title_hint' => JText::_('FWFM_CATEGORY_CATEGORY_HINT'),
	'view' => $this
), JPATH_COMPONENT);
?>
<form id="adminForm" name="adminForm" method="post" action="index.php?option=com_fwfoodmenu&view=category">
    <div class="fwa-filter-bar p-3 clearfix">
        <div class="float-right">
            <div class="input-group">
            </div>
        </div>
        <div class="float-left">
            <div class="input-group">
                <?php echo
                JHTML::_('fwfCategory.getCategories', 'category', $this->category, 'class="form-control form-control-sm advancedSelect" onchange="with(this.form){limitstart.value=0;submit();}"', false, 'FWFM_SELECT_PARENT_CATEGORY', true); ?>
            </div>
        </div>
        <div class="float-left w-25 ml-3">
            <div class="input-group">
                <input class="form-control" placeholder="<?php echo JText::_('FWFM_SEARCH_CATEGORY_NAME_DESCRIPTION'); ?>" type="text" name="search" value="<?php echo $this->escape($this->search); ?>" />
                <span class="input-group-btn">
                    <button class="btn btn-secondary" type="button" onclick="with(this.form){limitstart.value=0;search.value='';submit();}"><i class="fal fa-times"></i></button>
                </span>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="submit"><i class="fal fa-search"></i></button>
                </span>
            </div>
        </div>
        <div class="float-left ml-3">
			<?php echo JHTML::_('select.genericlist', array(
				JHTML::_('select.option', '', JText::_('FWFM_ANY_STATE'), 'id', 'name'),
				JHTML::_('select.option', 'published', JText::_('FWFM_PUBLISHED'), 'id', 'name'),
				JHTML::_('select.option', 'unpublished', JText::_('FWFM_UNPUBLISHED'), 'id', 'name'),
			), 'state', 'class="form-control form-control-sm" onchange="with(this.form){limitstart.value=0;submit();}"', 'id', 'name', $this->state); ?>
        </div>
    </div>

	<table class="table table-striped">
		<thead>
			<tr>
				<th style="width:20px;"><input name="toggle" value="" onclick="Joomla.checkAll(this);" type="checkbox"></th>
                <th class="text-center"><?php echo JText::_('FWFM_CATEGORY_MENU_ITEMS'); ?></th>
<?php
$this->app->triggerEvent('showCategoryListBeginExtraHeaders', array('com_fwfoodmenu', $this));
?>
				<th><?php echo JText::_('FWFM_CATEGORY_Name'); ?></th>
				<th><?php echo JText::_('FWFM_CATEGORY_Order'); ?><a href="javascript:saveorder(<?php echo count((array)$this->list) - 1; ?>, 'saveorder')" rel="tooltip" class="saveorder btn btn-sm" title="<?php echo $this->escape(JText::_('FWFM_CATEGORY_Save_Order')); ?>"><span class="fa fa-save"></span></a></th>
				<th><?php echo JText::_('FWFM_CATEGORY_Published'); ?></th>
			</tr>
		</thead>
		<tbody>
<?php
if ($this->list) {
	foreach ($this->list as $num=>$row) {
?>
			<tr>
				<td><?php echo JHTML :: _('grid.id', $num, $row->id); ?></td>
                <td class="text-center"><?php
                    // if ($row->_menu_qty) echo '<i class="fal fa-utensils mr-1"></i>';
                    echo fwFoodMenuHelper::countMealsQty($row->id); ?>
				</td>
<?php
		$this->app->triggerEvent('showCategoryListBeginExtraColumns', array('com_fwfoodmenu', $this, $row, $num));
?>
				<td>
					<a href="index.php?option=com_fwfoodmenu&amp;view=category&amp;task=edit&amp;cid[]=<?php echo $row->id.$this->extra_link; ?>">
						<?php echo $row->treename; ?>
					</a>
                    <div>
                    <?php
                        $description = strip_tags($row->description);
                        $total = strlen($description);
                        if ($total > 200) $description = substr($description, 0, 196).'...('.$total.')';
                        echo $description;
                    ?>
                    </div>
				</td>
				<td class="order">
					<?php echo JHTMLfwView::orderingListLinks(array(
						'num' => $num,
						'value' => $row->ordering,
						'display_up' => fwFoodMenuHelper::checkPrevCategory($row),
						'display_down' => fwFoodMenuHelper::checkNextCategory($row)
					)); ?>
				</td>
				<td>
					<?php echo JHTMLfwView::booleanListLink(array(
						'num' => $num,
						'value' => $row->published,
						'task_on' => 'publish',
						'task_off' => 'unpublish',
						'title_on' => JText::_('FWFM_CATEGORY_PUBLISH'),
						'title_off' => JText::_('FWFM_CATEGORY_UNPUBLISH')
					)); ?>
				</td>
			</tr>
<?php
	}
} else {

}
?>
		</tbody>
	</table>
	<div class="row">
		<div class="col-md-9">
			<?php echo $this->pagination->getListFooter(); ?>
		</div>
		<div class="col-md-3 mt-4 text-right pagination-limit">
			<div class="d-inline-block mr-3">
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>
		</div>
	</div>
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="task" value="" />
</form>
<div id="fwfm-quick-categories" class="modal fade">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo JText::_('FWFM_QUICK_CATEGORIES'); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
		<textarea name="quick_categories" class="form-control" placeholder="<?php echo $this->escape(JText::_('FWFM_QUICK_CATEGORIES_HINT')); ?>"></textarea>
	  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary"><?php echo JText::_('FWFM_SAVE'); ?></button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo JText::_('FWFM_CLOSE'); ?></button>
      </div>
    </div>
  </div>
</div>
<script>
Joomla.submitbutton = function(pressbutton) {
	if (pressbutton == 'quick') {
		jQuery('#fwfm-quick-categories').modal('show');
		return;
	}
	document.adminForm.task.value=pressbutton;
	document.adminForm.submit();
}

jQuery(function($) {
	$('#fwfm-quick-categories').on('show', function() {
		$(this).addClass('show');
		$(this).find('textarea').val('');
	}).on('hide', function() {
		$(this).removeClass('show');
	});
	$('#toolbar-upload button').addClass('btn-primary');
	$('#fwfm-quick-categories button.btn-primary').click(function() {
		var $btn = $(this).attr('disabled', true);
		var $popup = $('#fwfm-quick-categories');
		$.ajax({
			dataType: 'json',
			data: {
				format: 'json',
				task: '',
				layout: 'quick_categories',
				text: $popup.find('textarea').val()
			}
		}).done(function(data) {
			$btn.attr('disabled', false);
			if (data.msg) {
				alert(data.msg);
			}
			if (data.result) {
				location=location.toString().replace('#.*$', '')+'<?php echo str_replace('&amp;', '&', $this->extra_link); ?>';
			}
		});
	});
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
