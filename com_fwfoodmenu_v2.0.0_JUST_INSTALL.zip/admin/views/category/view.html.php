<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class menuViewCategory extends JViewLegacy {
	function display($tmpl=null) {
		$this->menu = 'category';
		$model = $this->getModel();
		$this->app = JFactory::getApplication();
		$this->input = $this->app->input;
		$this->params = JComponentHelper::getParams('com_fwfoodmenu');
		$this->fields = array('search', 'user', 'state', 'category', 'limit', 'limitstart');
		switch ($this->getLayout()) {
			case 'edit' :
			$this->object = $model->loadObject();
            foreach ($this->fields as $field) {
                $this->$field = $this->app->input->getString($field);
            }
			break;
			default :
			$this->list = $model->loadList();
			$this->pagination = $model->getPagination();
			$this->extra_link = '';
            foreach ($this->fields as $field) {
                $this->$field = $this->app->input->getString($field);
				if ($this->$field) {
					$this->extra_link .= '&amp;'.$field.'='.urlencode($this->$field);
    				$this->pagination->setAdditionalUrlParam($field, $this->$field);
    			}
            }
		}
		parent::display($tmpl);
	}
}
