<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

class menuViewTranslation extends JViewLegacy {
    function display($tmpl = null) {
        $this->menu = 'translation';
        $app = JFactory::getApplication();
        $model = $this->getModel();

        $this->type = (int)$model->getUserState('type', 0, 'int');
        $this->search = $model->getUserState('search', '', 'string');
        $this->language = fwFoodMenuHelper::getLanguage();
        $this->languages = fwFoodMenuHelper::getInstalledLanguages();
        $this->data = $model->getLanguageData();
        parent::display($tmpl);
    }
}
