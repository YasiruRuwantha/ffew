<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2019 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined('_JEXEC') or die('Restricted access');

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));
JToolBarHelper::apply();

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-globe mr-1"></i> '.JText::_('FWFM_TRANSLATIONS'),
    'title_hint' => JText::_('FWFM_TRANSLATIONS_HINT'),
	'view' => $this
), JPATH_COMPONENT);
?>
<form action="<?php echo JRoute :: _('index.php?option=com_fwfoodmenu&view=translation'); ?>" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
    <div class="fwa-filter-bar fwa-filter-bar-float clearfix">
        <div class="float-left mr-3">
            <div class="input-group">
                <?php echo JHTML :: _('select.genericlist', $this->languages, 'lang', 'onchange="this.form.task.value=\'\';this.form.submit();" style="float:none;"', 'id', 'name', $this->language); ?>
            </div>
        </div>
        <div class="float-left mr-3">
            <?php echo JHTMLfwView::radioGroup('type', $this->type, array(
                'wrapper_class' => 'mr-2',
                'buttons' => array(array(
                    'active_class' => 'btn-success',
                    'title' => JText::_('FWFM_FRONTEND'),
                    'value' => 1
                ), array(
                    'active_class' => 'btn-success',
                    'title' => JText::_('FWFM_BACKEND'),
                    'value' => 0
                ))
            )); ?>
        </div>
        <div class="float-left mr-3">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="<?php echo JText::_('FWFM_SEARCH_TRANSLATION'); ?>" name="search" value="<?php echo $this->escape($this->search); ?>" />
                <span class="input-group-btn">
                    <button class="btn btn-secondary" type="button" onclick="with(this.form){search.value='';submit();}"><i class="fa fa-times"></i></button>
                </span>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
                </span>
            </div>
        </div>
    </div>
    <table class="table table-striped fwfm-translations-table">
        <thead>
            <tr>
                <th><?php echo JText::_('FWFM_DEFAULT'); ?> en-GB</th>
                <th><?php echo JText::_('FWFM_TARGET'); ?> <?php echo $this->languages[$this->language]->tag; ?></th>
            </tr>
        </thead>
        <tbody>
<?php
foreach ($this->data as $const=>$row) {
?>
            <tr>
                <td width="30%">
                    <?php echo $row['src']; ?>
<?php
	if (!$row['src']) {
?>                    <div><small><?php echo $const; ?></small></div>
<?php
	}
?>
                </td>
                <td><input type="text" class="form-control" name="lang_data[<?php echo $const; ?>]" value="<?php echo str_replace('"', '&quot;', $row['trg']); ?>" placeholder="<?php echo JText::_('FWFM_NO_TRANSLATION'); ?>" /></td>
            </tr>
<?php
}
?>
        </tbody>
    </table>
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
</form>
<script>
jQuery(function($) {
    $('input[name="type"]').change(function() {
        with (this.form) {
            task.value = '';
            submit();
        }
    });
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
