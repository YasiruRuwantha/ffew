<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-tachometer-alt mr-1"></i> '.JText::_('FWFM_MENU_DASHBOARD'),
    'title_hint' => JText::_('FWFM_MENU_DASHBOARD_HINT'),
	'view' => $this
), JPATH_COMPONENT);
$update_code = $this->obj->params->get('update_code');
$verified_code = $this->obj->params->get('verified_code');
?>
<form id="adminForm" name="adminForm" method="post" action="index.php?option=com_fwfoodmenu&view=menu" enctype="multipart/form-data">
	<div class="row fwa-mb-cardbox">
		<div class="col-lg-6 col-sm-12">
            <div class="card">
    			<div class="card-header">
    				<h4 class="card-title"><?php echo JText::_('FWFM_CATEGORY_FW_FOOD_MENU'); ?></h4>
    			</div>
    			<div class="card-block">
    				<div class="row no-gutters fwa-product-info">
    					<div class="col-4 pt-2 pr-3">
    						<img class="" src="<?php echo JURI :: root(true) ?>/administrator/components/com_fwfoodmenu/assets/images/icon_fw_food_menu_200.png" alt="FW Food Menu Logo" />

    					</div>
    					<div class="col-8">
    						<table class="table table-striped">
    							<tbody><tr>
    								<td><?php echo JText::_('FWFM_VERSION'); ?>:</td>
    								<td><?php echo $this->qch->version; ?></td>
    							</tr>
    							<tr>
    								<td><?php echo JText::_('FWFM_AUTHOR'); ?>:</td>
    								<td><a href="https://fastw3b.net" target="_blank">https://fastw3b.net</a></td>
    							</tr>
    							<tr>
    								<td><?php echo JText::_('FWFM_COPYRIGHT'); ?>:</td>
    								<td>&copy; Fastw3b LLC. All rights reserved.</td>
    							</tr>
    							<tr>
    								<td><?php echo JText::_('FWFM_LICENSE'); ?>:</td>
    								<td>GPL v2.0</td>
    							</tr>
    							<tr>
    								<td><?php echo JText::_('FWFM_MORE_INFO'); ?>:</td>
    								<td><a href="https://fastw3b.net/terms-conditions" target="_blank"><?php echo JText::_('FWFM_TERMS_CONDITIONS'); ?></a></td>
    							</tr>
    						</tbody></table>
							<div class="mt-3 text-right">
								<button type="button" class="btn btn-secondary mr-4">
									<i class="fal fa-file-alt mr-1"></i>
									<?php echo JText::_('FWFM_CHANGELOG'); ?></button>
								<a class="btn btn-warning" target="_blank" href="https://fastw3b.net/documentation/fw-food-menu">
									<i class="fal fa-book mr-1"></i>
									<?php echo JText::_('FWFM_DOCUMENTATION'); ?></a>
							</div>
    					</div>
    				</div>
    			</div>
    		</div>
    		<div class="card fwa-check check-<?php if ($this->qch->test_passed) { ?>success<?php } else { ?>fail<?php } ?>">
    			<div class="card-header">
    				<h4 class="card-title"><?php echo JText::_('FWFM_QUICK_CHECK'); ?> - <?php echo JText::_($this->qch->test_passed?'FWFM_PASSED':'FWFM_FAILED'); ?></h4>
    				<div class="card-subtitle"><?php echo JText::_('FWFM_QUICK_CHECK_HINT'); ?></div>
    			</div>
    			<div class="card-block">
    				<table class="table table-striped">
    					<tbody><tr>
    						<td><?php echo JText::_('FWFM_JOOMLA_MEDIA_FOLDER'); ?></td>
    						<td>
<?php
if ($this->qch->media_folder_exists) {
?>
    							<i class="fa fa-check-circle"></i> <?php echo JText::_('FWFM_EXISTS_SMALL'); ?>
<?php
} else {
?>
    							<i class="fa fa-times-circle"></i> <?php echo JText::_('FWFM_NOT_EXISTS_SMALL'); ?>
<?php
}
?>
    						</td>
    					</tr>
    					<tr>
    						<td><?php echo JText::_('FWFM_IMAGES_FOLDER'); ?></td>
    						<td>
<?php
if ($this->qch->gallery_folder_exists) {
?>
    							<i class="fa fa-check-circle"></i> <?php echo JText::_('FWFM_EXISTS_SMALL'); ?>
<?php
} else {
?>
    							<i class="fa fa-times-circle"></i> <?php echo JText::_('FWFM_NOT_EXISTS_SMALL'); ?>
<?php
}
?>
    						</td>
    					</tr>
    					<tr>
    						<td><?php echo JText::_('FWFM_IMAGES_FOLDER'); ?></td>
    						<td>
<?php
if ($this->qch->gallery_folder_writeable) {
?>
    							<i class="fa fa-check-circle"></i> <?php echo JText::_('FWFM_WRITABLE_SMALL'); ?>
<?php
} else {
?>
    							<i class="fa fa-times-circle"></i> <?php echo JText::_('FWFM_NOT_WRITABLE_SMALL'); ?>
<?php
}
?>
    						</td>
    					</tr>
    					<tr>
    						<td><?php echo JText::_('FWFM_MAX_TOTAL_POST_SIZE'); ?></td>
    						<td><?php echo fwFoodMenuHelper::humanFileSize(fwFoodMenuHelper::getIniSize('post_max_size')); ?></td>
    					</tr>
    					<tr>
    						<td><?php echo JText::_('FWFM_MAX_FILE_SIZE'); ?></td>
    						<td><?php echo fwFoodMenuHelper::humanFileSize(fwFoodMenuHelper::getIniSize('upload_max_filesize')); ?></td>
    					</tr>
    					<tr>
    						<td><?php echo JText::_('FWFM_MAX_FILES_PER_POST'); ?></td>
    						<td><?php echo ini_get('max_file_uploads'); ?></td>
    					</tr>
    				</tbody></table>
    			</div>
    		</div>
		</div>
		<div class="col-lg-6 col-sm-12">
<?php
if ($update_code and $update_code == $verified_code and $this->addons) {
?>
        <div class="card">
			<div class="card-header">
				<h4 class="card-title"><?php echo JText::_('FWFM_ADDONS'); ?></h4>
			</div>
			<div class="card-block">
				<span id="fwfm-latest-version"></span>
				<table class="table table-striped fwa-product-addons">
					<thead>
						<tr>
							<th><?php echo JText::_('FWFM_ADDON'); ?></th>
                            <th><?php echo JText::_('FWFM_TOTAL'); ?></th>
							<th><?php echo JText::_('FWFM_INSTALLED'); ?></th>
                            <th><?php echo JText::_('FWFM_AVAILABLE'); ?></th>
							<th><?php echo JText::_('FWFM_NEED_UPDATE'); ?></th>
						</tr>
					</thead>
					<tbody>
<?php
$total = $installed = $available = $update = 0;
foreach ($this->addons as $addon) {
	if ($addon->subtype == 'module') {
		if ($addon->installed) {
			$installed++;
			if ($addon->loc_version and $addon->rem_version and $addon->loc_version != 'x.x.x' and $addon->loc_version != $addon->rem_version) {
				$update++;
			}
//		} elseif ($addon->installable) {
//			$available++;
		}
		$total ++;
	}
}
$available = $total - $installed;
?>
						<tr>
							<td><a href="index.php?option=com_fwfoodmenu&amp;view=addon#filter=module"><?php echo JText::_('FWFM_MODULES'); ?></a></td>
                            <td><span class="badge badge-default"><?php if ($total) echo $total; ?></span></td>
							<td><span class="badge badge-success"><?php if ($installed) echo $installed; ?></span></td>
                            <td><span class="badge badge-info"><?php if ($available) echo $available; ?></span></td>
							<td><span class="badge badge-warning"><?php if ($update) echo $update; ?></span></td>
						</tr>
<?php
$total = $installed = $available = $update = 0;
foreach ($this->addons as $addon) {
	if ($addon->subtype == 'plugin' and $addon->update_name != 'com_fwfoodmenu') {
		if ($addon->installed) {
			$installed++;
			if ($addon->loc_version and $addon->rem_version and $addon->loc_version != 'x.x.x' and $addon->loc_version != $addon->rem_version) {
				$update++;
			}
//		} elseif ($addon->installable) {
//			$available++;
		}
		$total ++;
	}
}
$available = $total - $installed;
?>
						<tr>
							<td><a href="index.php?option=com_fwfoodmenu&amp;view=addon#filter=plugin"><?php echo JText::_('FWFM_PLUGINS'); ?></a></td>
                            <td><span class="badge badge-default"><?php if ($total) echo $total; ?></span></td>
							<td><span class="badge badge-success"><?php if ($installed) echo $installed; ?></span></td>
                            <td><span class="badge badge-info"><?php if ($available) echo $available; ?></span></td>
							<td><span class="badge badge-warning"><?php if ($update) echo $update; ?></span></td>
						</tr>
<?php
$total = $installed = $available = $update = 0;
foreach ($this->addons as $addon) {
	if ($addon->subtype == 'design') {
		if ($addon->installed) {
			$installed++;
			if ($addon->loc_version and $addon->rem_version and $addon->loc_version != 'x.x.x' and $addon->loc_version != $addon->rem_version) {
				$update++;
			}
//		} elseif ($addon->installable) {
//			$available++;
		}
		$total ++;
	}
}
$available = $total - $installed;
?>
						<tr>
							<td><a href="index.php?option=com_fwfoodmenu&amp;view=addon#filter=design"><?php echo JText::_('FWFM_THEMES'); ?></a></td>
                            <td><span class="badge badge-default"><?php if ($total) echo $total; ?></span></td>
							<td><span class="badge badge-success"><?php if ($installed) echo $installed; ?></span></td>
                            <td><span class="badge badge-info"><?php if ($available) echo $available; ?></span></td>
							<td><span class="badge badge-warning"><?php if ($update) echo $update; ?></span></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
<?php
}
?>
    		<div class="card fwa-stats">
    			<div class="card-header">
    				<h4 class="card-title"><?php echo JText::_('FWFM_STATISTICS'); ?></h4>
    			</div>
    			<div class="card-block">
    				<div class="row">
    					<div class="col text-center">
    						<i class="fal fa-folders fa-3x"></i>
    						<br><a href="index.php?option=com_fwfoodmenu&view=category"><?php echo JText::_('FWFM_CATEGORIES'); ?></a>
    						<br> <?php echo $this->locstat->cp; ?> / <?php echo $this->locstat->ct; ?>
    					</div>
    					<div class="col text-center">
    						<i class="fal fa-image fa-3x"></i>
    						<br><a href="index.php?option=com_fwfoodmenu&view=items"><?php echo JText::_('FWFM_MENU_ITEMS'); ?></a>
    						<br> <?php echo $this->locstat->mp; ?> / <?php echo $this->locstat->mt; ?>
    					</div>
    					<div class="col text-center">
    						<i class="fal fa-hdd fa-3x"></i>
    						<br><?php echo JText::_('FWFM_FILES_TOTAL'); ?>
    						<br><?php echo fwFoodMenuHelper::humanFileSize($this->locstat->fs); ?>
    					</div>
    				</div>
    			</div>
    		</div>
    		<!-- Statistics -->
    		<div class="card">
    			<div class="card-header">
    				<h4 class="card-title"><?php echo JText::_('FWFM_SPREAD_THE_LOVE'); ?></h4>
    			</div>
    			<div class="card-block">
    				<p><?php echo JText::_('FWFM_SPREAD_THE_LOVE_HINT'); ?></p>
    				<div class="text-center">
    					<a href="https://extensions.joomla.org/extensions/extension/vertical-markets/food-a-beverage/fw-food-menu/" target="_blank" class="btn btn-success text-center"><i class="fa fa-heart mr-1"></i> <?php echo JText::_('FWFM_VOTE'); ?></a>
    				</div>
    			</div>
    		</div>
		</div>
	</div>
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="id" value="1" />
</form>
<div class="modal" tabindex="-1" role="dialog" id="fwfm-changelog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo JText::_('FWFM_CHANGELOG'); ?></h5>
        <button type="button" class="close" data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo JText::_('FWFM_CLOSE'); ?></button>
      </div>
    </div>
  </div>
</div>
<script>
jQuery(function($) {
	$('#fwfm-changelog').on('show', function() {
		$(this).addClass('show');
	}).on('hide', function() {
		$(this).removeClass('show');
	});
	$('.fwa-product-info button:has(".fa-file-alt")').click(function() {
		var $btn = $(this).attr('disabled', true);
		$.ajax({
			'url': '',
			'method': 'post',
			dataType: 'json',
			'data': {
				'format': 'json',
				'view': 'menu',
				'layout': 'get_changelog'
			}
		}).done(function(data) {
			$btn.attr('disabled', false);
			var $popup = $('#fwfm-changelog');
			$popup.find('.modal-body').html(data.result?data.result:data.msg?data.msg:'<?php echo JText::_('FWFM_NO_CHANGELOG', true); ?>');
			$popup.modal('show');
		});
	});
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
