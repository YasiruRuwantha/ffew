<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

JToolBarHelper::title(JText::_('FWFM_MENU_FW_FOOD_MENU'));
JToolBarHelper::apply();
JHtml::_('behavior.colorpicker');

echo JLayoutHelper::render('common.menu_begin', array(
    'title' => '<i class="fal fa-sliders-h mr-1"></i> '.JText::_('FWFM_SETTINGS_SETTINGS'),
    'title_hint' => JText::_('FWFM_SETTINGS_SETTINGS_HINT'),
	'view' => $this
), JPATH_COMPONENT);
?>
<form id="adminForm" name="adminForm" method="post" action="index.php?option=com_fwfoodmenu&view=settings" enctype="multipart/form-data">
	<div class="row fwa-mb-cardbox">
		<div class="col-lg-6 col-sm-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title"><?php echo JText::_('FWFM_CATEGORY_LAYOUT'); ?></h4>
					<div class="card-subtitle"><?php echo JText::_('FWFM_CATEGORY_LAYOUT_HINT'); ?></div>
				</div>
				<div class="card-block">
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_THEME'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" title="<?php echo $this->escape(JText::_('FWFM_THEME_TITLE')); ?>" data-content="<?php echo $this->escape(JText::_('FWFM_THEME_CONTENT')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTML::_('select.genericlist', fwFoodMenuHelper::getThemesList(), 'config[template]', '', 'id', 'name', $this->object->params->get('template')); ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_SHOW_CATEGORY_TITLE'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_SHOW_CATEGORY_TITLE_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_SHOW_CATEGORY_TITLE_TITLE')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTMLfwView::radioGroup('config[display_category_title]', $this->object->params->get('display_category_title', '1'), array(
								'wrapper_class' => 'mr-2',
								'buttons' => array(array(
									'active_class' => 'btn-success',
									'title' => JText::_('JYES'),
									'value' => '1'
								), array(
									'active_class' => 'btn-success',
									'title' => JText::_('JNO'),
									'value' => '0'
								))
							)); ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_CATEGORY_DESCRIPTION_POSITION'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_CATEGORY_DESCRIPTION_POSITION_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_CATEGORY_DESCRIPTION_POSITION_TITLE')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTMLfwView::radioGroup('config[category_descr_position]', $this->object->params->get('category_descr_position', 'top'), array(
								'wrapper_class' => 'mr-2',
								'buttons' => array(array(
									'active_class' => 'btn-success',
									'title' => JText::_('FWFM_TOP'),
									'value' => 'top'
								), array(
									'active_class' => 'btn-success',
									'title' => JText::_('FWFM_LEFT'),
									'value' => 'left'
								), array(
									'active_class' => 'btn-success',
									'title' => JText::_('FWFM_RIGHT'),
									'value' => 'right'
								), array(
									'active_class' => 'btn-success',
									'title' => JText::_('FWFM_BOTTOM'),
									'value' => 'bottom'
								))
							)); ?>
						</div>
					</div>
<?php
$this->app->triggerEvent('showSettingsCategoryExtraFields', array('com_fwfoodmenu', $this));
?>
				</div>
			</div>
			<div class="card">
				<div class="card-header">
					<h4 class="card-title"><?php echo JText::_('FWFM_MEAL_LAYOUT'); ?></h4>
					<div class="card-subtitle"><?php echo JText::_('FWFM_MEAL_LAYOUT_HINT'); ?></div>
				</div>
				<div class="card-block">
<?php
$this->app->triggerEvent('showSettingsMenuExtraFields', array('com_fwfoodmenu', $this));
?>
<?php /*
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_ALIGN_BY'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_ALIGN_BY_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_ALIGN_BY_TITLE')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTMLfwView::radioGroup('config[align_by]', $this->object->params->get('align_by', 'meal'), array(
								'wrapper_class' => 'mr-2',
								'buttons' => array(array(
									'active_class' => 'btn-success',
									'title' => 'meal',
									'value' => JText::_('FWFM_MEALS')
								), array(
									'active_class' => 'btn-success',
									'title' => 'category',
									'value' => JText::_('FWFM_CATEGORIES')
								))
							)); ?>
						</div>
					</div>
*/ ?>
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-sm-12">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title"><?php echo JText::_('FWFM_COMMON_SETTINGS'); ?></h4>
					<div class="card-subtitle"><?php echo JText::_('FWFM_COMMON_SETTINGS_HINT'); ?></div>
				</div>
				<div class="card-block">
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_LOAD_BOOTSTRAP'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" title="<?php echo $this->escape(JText::_('FWFM_LOAD_BOOTSTRAP_TITLE')); ?>" data-content="<?php echo $this->escape(JText::_('FWFM_LOAD_BOOTSTRAP_DESCR')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTMLfwView::radioGroup('config[do_not_load_bootstrap]', (int)$this->object->params->get('do_not_load_bootstrap'), array(
								'wrapper_class' => 'mr-2',
								'buttons' => array(array(
									'active_class' => 'btn-success',
									'title' => JText::_('JYES'),
									'value' => 0
								), array(
									'active_class' => 'btn-success',
									'title' => JText::_('JNO'),
									'value' => 1
								))
							)); ?>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_LOAD_FONT_AWESOME'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" title="<?php echo $this->escape(JText::_('FWFM_LOAD_FONT_AWESOME_TITLE')); ?>" data-content="<?php echo $this->escape(JText::_('FWFM_LOAD_FONT_AWESOME_DESCR')); ?>"></i>
						</label>
						<div class="col-sm-7">
							<?php echo JHTMLfwView::radioGroup('config[do_not_load_awesome]', (int)$this->object->params->get('do_not_load_awesome'), array(
								'wrapper_class' => 'mr-2',
								'buttons' => array(array(
									'active_class' => 'btn-success',
									'title' => JText::_('JYES'),
									'value' => 0
								), array(
									'active_class' => 'btn-success',
									'title' => JText::_('JNO'),
									'value' => 1
								))
							)); ?>
						</div>
					</div>
				</div>
			</div>

			<div class="card">
				<div class="card-header">
					<h4 class="card-title"><?php echo JText::_('FWFM_SETTINGS_LOCALIZATION'); ?></h4>
					<div class="card-subtitle"><?php echo JText::_('FWFM_SETTINGS_LOCALIZATION_HINT'); ?></div>
				</div>
				<div class="card-block">
					<div class="form-group row">
						<label for="fwfm-currency" class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_SETTINGS_Price_Currency'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_SETTINGS_Price_Currency_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_SETTINGS_Price_Currency_TITLE')); ?>"></i>
						</label>
						<div class="col-3">
							<input class="form-control" value="<?php echo $this->object->params->get('currency'); ?>" id="fwfm-currency" type="text" name="config[currency]">
						</div>
						<div class="col-4">
							<?php echo JHTMLfwView::radioGroup('config[currency_after]', $this->object->params->get('currency_after'), array(
								'wrapper_class' => 'mr-2',
								'buttons' => array(array(
									'active_class' => 'btn-info',
									'title' => JText::_('FWFM_SETTINGS_Before'),
									'value' => 0
								), array(
									'active_class' => 'btn-default btn-warning',
									'title' => JText::_('FWFM_SETTINGS_After'),
									'value' => 1
								))
							)); ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="fwfm-currency_code" class="col-sm-5 col-form-label clearfix">
							<?php echo JText::_('FWFM_SETTINGS_PRICE_CURRENCY_CODE'); ?>
							<i class="pull-right fa fa-question-circle" data-container="body" data-trigger="hover" data-toggle="popover" data-placement="top" data-content="<?php echo $this->escape(JText::_('FWFM_SETTINGS_PRICE_CURRENCY_CODE_DESCR')); ?>" title="<?php echo $this->escape(JText::_('FWFM_SETTINGS_PRICE_CURRENCY_CODE_TITLE')); ?>"></i>
						</label>
						<div class="col-3">
							<input class="form-control" value="<?php echo $this->object->params->get('currency_code'); ?>" id="fwfm-currency_code" type="text" name="config[currency_code]">
						</div>
					</div>
				</div>
			</div>
<?php
$this->app->triggerEvent('showSettingsExtraCardsRight', array('com_fwfoodmenu', $this));
?>
		</div>
	</div>
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="id" value="1" />
</form>
<script>
jQuery(function($) {
    $('button.btn-secondary:has(".fa-paint-brush")').click(function() {
        $(this).parent().prev().find('input').focus();
    });
});
</script>
<?php
echo JLayoutHelper::render('common.menu_end', array(), JPATH_COMPONENT);
