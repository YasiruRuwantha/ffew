<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

class menuViewsettings extends JViewLegacy {
	function display($tmpl=null) {
		$this->menu = 'settings';
		$model = $this->getModel();
		$this->setLayout('default');
		$this->app = JFactory::getApplication();
		$this->object = $model->loadObject();
		$this->description = $model->getDescription();
		parent::display($tmpl);
	}
}
