<?php
/**
 * FW Food menu 2.0.0
 * @copyright (C) 2017 Fastw3b
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @link http://www.fastw3b.net/ Official website
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

JHTML::stylesheet('components/com_fwfoodmenu/assets/css/bootstrap.css');
JHTML::stylesheet('components/com_fwfoodmenu/assets/css/all.min.css');
JHTML::stylesheet('administrator/components/com_fwfoodmenu/assets/css/fw-back-end.css', array('version'=>101));
JHTML::stylesheet('administrator/components/com_fwfoodmenu/assets/css/fwfm-admin.css', array('version'=>101));

JHTML::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.'/helpers');
JTable::addIncludePath(JPATH_COMPONENT_ADMINISTRATOR.'/tables');

require_once(JPATH_COMPONENT_SITE.'/helpers/helper.php');
require_once(JPATH_COMPONENT.'/controller.php');

$input = JFactory::getApplication()->input;
$controller = JControllerLegacy :: getInstance('menu');
$controller->execute($input->getCmd('task'));
$controller->redirect();
